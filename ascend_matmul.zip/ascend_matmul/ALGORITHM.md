# 搜尋算法與硬體模型

## 1. 問題定義

輸入：

```text
M, N, K
dtype
transA, transB
可用 AI Core 數
CANN/SoC
搜尋預算
```

輸出不是任意整數組，而是安裝中的官方
`MultiCoreMatmulTiling::GetTiling()` 接受、`GetCoreNum()` 一致、且本工程
kernel 能執行的 `TCubeTiling` Top-K。

Rank-1 是指定模型與預算下的 best-known candidate，不是未窮舉空間的數學證明。

## 2. 離散參數與硬限制

### 2.1 Cube 對齊

```text
baseM % 16 == 0
baseN % 16 == 0
baseK % K0 == 0
K0 = (32 / input_bit_width) * 8
```

因此：

```text
FP16/BF16: K0=16
FP32:      K0=8
INT8:      K0=32
```

尾塊的 `singleCoreK` 可以未對齊，例如 K=65；合法的 `baseK` 上限是
`alignUp(singleCoreK,K0)=80`，不是未對齊的 65。

### 2.2 必要容量

候選生成階段先剪枝：

```text
baseM * baseK * input_bytes <= L0A
baseN * baseK * input_bytes <= L0B
baseM * baseN * accumulator_bytes <= L0C
```

官方 API 回傳後，再用最終 DB 檢查：

```text
L0A = baseM * baseK * input_bytes * input_ping_pong
L0B = baseN * baseK * input_bytes * input_ping_pong
L0C = baseM * baseN * accumulator_bytes * dbL0C
```

並檢查：

```text
depthA1 = stepM * stepKa * A1_buffer_count
depthB1 = stepN * stepKb * B1_buffer_count
A1/B1_buffer_count in [1,2]
A1_bytes + B1_bytes <= L1
shareL1/L0C/UB <= platform capacity
```

必要條件只負責提前剪枝。官方 API 與 kernel template 契約才是最終判定。

## 3. 核心切分不是核心數相等

候選先決定：

```text
singleCoreM
singleCoreN
singleCoreK
```

一般 M/N 模式：

```text
mParts = ceil(M / singleCoreM)
nParts = ceil(N / singleCoreN)
logicalTiles = mParts * nParts
usedCoreNum <= logicalTiles
rounds = ceil(logicalTiles / usedCoreNum)
```

同一核心可以處理多個連續 tile。實測官方 API 例子：

```text
M=4096, N=11008
singleCoreM=512, singleCoreN=1840
GetCoreNum: mDim=8, nDim=6
TCubeTiling.usedCoreNum=24

logicalTiles=48, rounds=2
```

舊版要求 `logicalTiles == usedCoreNum`，會錯誤排除這類官方合法結果。

### 3.1 跨核心 split-K

```text
kParts = ceil(K / singleCoreK)
```

`kParts=1` 使用 `base_iterate_all`；`baseK<K` 仍然完整參與核心內 K tiling。

`kParts>1` 需要跨核心 reduction。本工程只啟用與官方直接模板一致的：

```text
dtype=FP32
transA=false
transB=true
mParts * nParts * kParts == usedCoreNum
```

這個直接 atomic 模式要求單輪。FP16/BF16/INT8 需要另一套 workspace reduction，
不能只因 `GetTiling()` 成功就送進直接 atomic kernel。

## 4. 官方 API 適配

每個完整候選執行：

```cpp
MultiCoreMatmulTiling tiler(platform);
tiler.SetDim(coreLimit);
tiler.SetAType(...);
tiler.SetBType(...);
tiler.SetCType(...);
tiler.SetShape(M, N, K);
tiler.SetOrgShape(M, N, K);
tiler.SetBufferSpace(L1, L0C, UB);
tiler.SetBias(false);
tiler.SetSingleShape(singleM, singleN, singleK);
tiler.SetFixSplit(baseM, baseN, baseK);
tiler.SetDoubleBuffer(...);
tiler.SetTraverse(...);
tiler.EnableMultiCoreSplitK(...);
tiler.GetTiling(tiling);
tiler.GetCoreNum(coreNum, mDim, nDim);
```

要求：

```text
coreNum == tiling.usedCoreNum
mDim == ceil(M / tiling.singleCoreM)
nDim == ceil(N / tiling.singleCoreN)
```

不同 hint 可能被官方 API 映射成同一 `TCubeTiling`，因此最後按官方字段去重。

## 5. 約束感知 Beam Search

分層順序：

```text
合法 singleCoreM/N/K 組
        ->
baseM
        ->
baseN
        ->
baseK
        ->
traverse + DB
```

`singleCore` 集合由對齊後的 M/N/K 分區數生成。一般 M/N 模式最多保留
`maxCoreRounds * coreLimit` 個邏輯 tile；直接 split-K 只生成單輪組合。

每一層：

1. 立即刪除對齊、容量、模板或 round 上限不合法的狀態。
2. 用低成本 rough score 排序。
3. 依完整 candidate key 去重。
4. 只保留 `beamWidth` 個。

完整候選才調官方 API，避免把成本花在顯然非法的組合。

Rough score 使用：

- 核心利用率
- M/N/K tail efficiency
- 邏輯 tile rounds
- A/B 重複 GM traffic
- base tile arithmetic intensity
- L0 使用率
- MMAD loop 數

## 6. Tabu 與 Large Neighborhood Search

Beam Top 種子進入離散 Tabu：

```text
移到相鄰合法 singleCoreM/N/K 組
baseM/baseN/baseK 移到相鄰合法值
切換 traverse
切換 DB
```

split-K 不能以單一 Boolean 任意切換；它必須連同合法 `singleCoreK` 整組移動。

Tabu 表記錄最近 32 個 candidate key。只有 aspiration，即新候選優於該 seed
目前最佳時，才允許打破 Tabu。

LNS 依序重建四類鄰域：

```text
1. 固定 base/DB，重搜完整 singleCore 組
2. 固定核心切分，重搜 baseM/baseN
3. 固定 M/N，重搜 baseK/DB
4. 重搜局部 baseM/baseN + traverse
```

所有鄰域仍必須經過硬限制和官方 API。

## 7. 逐核 V220 靜態代理模型

模型不執行 kernel。輸入都是 launch 前可得：

```text
workload
最終 TCubeTiling
kernel 多輪/尾塊映射
PlatformAscendC 容量與 Byte/cycle
V220 Cube/MTE/FixPipe pipeline 結構
```

### 7.1 每核心成本

kernel 與模型使用同一個平衡 round 分配。每個邏輯 tile 展開：

```text
mIter = ceil(coreM / baseM)
nIter = ceil(coreN / baseN)
kIter = ceil(coreK / baseK)
mmadCount = mIter * nIter * kIter
```

最終 latency 以 critical core 為主：

```text
criticalCoreCycles = max(coreCycles[i])
balancePenalty = criticalCoreCycles - average(coreCycles[i])
```

### 7.2 Cube

與本地重建的官方 block cycle 公式一致：

```text
MAC_per_cycle = (256 / input_bit_width) * 256
cubeCycles = alignedM * alignedN * alignedK / MAC_per_cycle
```

另計 MMAD 發射成本，避免不同 base block 數得到相同分數。

### 7.3 GM、L1 與轉置

GM segment 以 32-byte 對齊。轉置會改變連續軸：

```text
A(N): M rows * align(K tile bytes, 32)
A(T): K rows * align(M tile bytes, 32)
B(N): K rows * align(N tile bytes, 32)
B(T): N rows * align(K tile bytes, 32)
```

`depthA1/B1`、`stepM/N/Ka/Kb` 與 iterate order 用來估算 L1 full-load、
partial cache 和 streaming ping-pong 的重用。

### 7.4 Pipeline overlap

模型分別計算：

```text
MTE2: GM -> L1
MTE1: L1 -> L0A/L0B
M:    MMAD
FixPipe: L0C -> GM
Scalar: loop/event issue
```

只有最終 buffer 設定允許時才重疊：

```text
dbL0A==2 && dbL0B==2
dbL0C==2
A1/B1 buffer_count==2
```

總分：

```text
globalHbmCycles = totalGmBytes / (HBM_Bpc_per_core * usedCores)
predictedCycles = max(criticalCoreCycles, globalHbmCycles)
                + fixedLaunchCycles
                + splitKSyncCycles
```

公開 API 沒有提供的發射/MTE1/FixPipe 常數保持為具名可校準參數，不當成已公開
硬體真值。

## 8. 為什麼不用普通 GA/PSO 作為主搜索

空間是離散且條件式：

- K0 依 dtype 改變。
- split-K 合法性依 dtype/layout/template 改變。
- base、single-core、DB 與 L0/L1 容量強耦合。
- 官方 API 可能把多個 hint 映射到同一結果。

普通 PSO 的連續速度與取整會產生大量重複/非法點。普通 GA 可使用離散編碼，
但交叉操作容易破壞耦合約束；需要專門的 constraint-preserving operator 後才適合
作基線。

Beam 能在每層立即剪枝；Tabu/LNS 能對合法離散組做局部與大鄰域改進，且結果
可重現、可解釋。

相關研究脈絡：

- [ROLLER, OSDI 2022](https://www.usenix.org/conference/osdi22/presentation/zhu)：
  以硬體/張量 shape 約束建構高效 schedule，而不是盲目嘗試所有組合。
- [Ansor](https://arxiv.org/abs/2006.06762)：階層式搜索與學習成本模型。
- [Learning to Optimize Tensor Programs / AutoTVM](https://arxiv.org/abs/1805.08166)：
  用測量校準成本模型和選擇後續候選。

本工程沒有直接複製這些系統；採用的是適合 CANN 條件式 API 的
constraint-first Beam + Tabu/LNS。

## 9. 評價方法

執行前：

- 相對 API 自動 tiling 的 predicted-cycle 改善
- critical/average core、tail efficiency、core utilization
- GM bytes、L1 hit estimate、arithmetic intensity
- 搜尋評估數、官方拒絕率、唯一 tiling 數

目前 6 組大型 validation 上，最佳代理分數相對可用的 API 自動 tiling 改善
`0.49%` 到 `58.31%`。這是模型結果，不是真機加速聲明。

真機後：

- correctness preflight
- median/p95/stddev latency
- TFLOPS
- Spearman/Kendall rank correlation
- top-k regret
- 相對同 kernel API 自動 tiling 的真實改善
- 相對安裝版 `aclnnMatmul/MatMulV3` 的端到端真實改善

若 Rank-1 真機不是最快，應用 NPU 資料校準模型，再搜索下一批；不應把一次
CPU proxy 排名包裝成已證明的全域最優。

## 10. 實作依據

- CANN `bmm_tiling.h`：`SetSingleShape`、`GetCoreNum`、split-K API 契約。
- CANN MatMul high-level API：`IterateAll`、L1 cache、L0 buffer 與 scheduler。
- 官方 MatMulV3 `mat_mul_base_block.h`：多 round 與尾核負載平衡。
- 官方 MatMulV3 `mat_mul_multi_core_splitk_kernel.h`：clear、barrier、atomic
  `GetTensorC` 的直接 split-K 順序。
- 官方 [`aclnnMatmul`](https://gitcode.com/cann/ops-nn/blob/master/matmul/mat_mul_v3/docs/aclnnMatmul.md)
  文件與 MatMulV3 README：兩段式 API、支援 dtype，以及該 API 對 MatMulV3 的
  正式呼叫入口。
- 本地 `MultiCoreMatmulTiling.cpp` 可讀重建：核心因子、block cycle、
  memory traffic、L0/L1 更新流程。逆向重建只作交叉證據，不冒充官方原始碼。
- `DaVinci_AIC_V220_ISA_User_Guide2-910B.pdf`：Cube 分形、MTE1/MTE2/M/FixPipe
  pipeline 與事件依賴。

# 驗證狀態

更新日期：2026-07-25

## 已完成

- CANN 8.3 RC2 Host 搜尋器單進程編譯
- 官方 `MultiCoreMatmulTiling::GetTiling/GetCoreNum` 實際執行
- `singleCoreM/N/K -> baseM/N/K -> traverse/DB` 約束感知 Beam Search
- 合法整組 single-core 鄰域的 Tabu + 四類 LNS
- 最終 M0/N0/K0、L0/L1、DB、shared memory 與 execution-mode 契約
- 一般 M/N 多 round 映射，不再要求 logical tile 數等於核心數
- FP32 NT 單輪直接 atomic split-K
- 8 組 validation workload：
  - 54 個合法一般候選
  - 3 個多 round Top 候選
  - 2 個直接 split-K Top 候選
  - 2 個未對齊 workload 的全部試探都在 host execution contract 拒絕
- CANN CPU Debug 非零逐元素數值驗證：
  - FP16 NN `256x256x256`，24 核
  - FP16 NN `144x272x80`，single-core output 跨多個 base tile
  - FP16 TN/NT/TT `144x272x80`
  - FP32 NT split-K `16x16x4096`，24 核
- `Ascend910B3` 正式 NPU kernel/stub/ACL runner 編譯
- 16 個正式入口：FP16/BF16/FP32/INT8 x NN/TN/NT/TT
- 小型 NPU 候選 numeric-ones preflight 實作
- 大型候選 poisoned-C zero-coverage preflight 實作
- 每個受支援 workload 強制輸出 API 自動 tiling `rank=0`，不占搜尋 Top-K 名額
- 安裝版 `aclnnMatmul/MatMulV3` 端到端基線 runner
- API 自動基線與官方 operator 兩組 speedup、latency change、噪聲門檻及判定
- 官方 MatMulV3 不支援的 INT8 workload 明確標記 unsupported
- 獨立候選 timeout、錯誤定位與失敗隔離；保留其他成功候選
- CPU Debug 中間 `cceprint/npuchk/stub_reg.log` 自動清理

本機驗證命令：

```bash
SKIP_BUILD=1 ./scripts/validate_cpu.sh
./scripts/run_cpu_kernel_smoke.sh --mode smoke
./scripts/run_cpu_kernel_smoke.sh --mode full
ASCENDC_SOC_VERSION=Ascend910B3 BUILD_JOBS=1 ./scripts/build_all.sh
```

## 尚待 910B3 真機確認

本工作區沒有 NPU。最新 kernel 仍需在遠端執行：

```bash
./run_npu.sh --mode smoke
```

Smoke 必須生成：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv
```

`npu_smoke_candidates.csv` 必須包含：

```text
rank=0, candidate_role=api_auto_baseline, success=1, preflight_passed=1
rank=1, candidate_role=searched, success=1, preflight_passed=1
preflight_mode=numeric_ones
```

官方 profile 還必須滿足：

```text
rank=-1, candidate_role=official_operator_baseline
source=installed_aclnn_matmul, success=1, preflight_passed=1
```

Smoke 通過後才執行：

```bash
./run_npu.sh --mode full
```

## 先前真機問題與目前狀態

先前版本曾出現：

- `aclInit rc=507008`：CANN runtime/driver/SoC host-stub 路徑不一致。
- `aclrtSynchronizeStream rc=507015`：kernel/template 契約錯配。
- `C index=4096` 未覆蓋：舊 wrapper 只執行一個 base tile。
- `odd_tail_1` 卡在 warmup：錯把 FP16 `singleCoreK<K` 送進直接 atomic split-K。

目前已改為：

- 每次從 ACL/npu-smi 偵測精確 910B 子型號並建立 SoC 專屬 build 目錄。
- 一般模式使用顯式 M/N 多 round 映射及 `IterateAll`。
- 直接 split-K 僅允許 FP32 NT，並使用官方 clear -> Iterate -> barrier ->
  atomic `GetTensorC` 順序。
- FP16/BF16/INT8 跨核心 split-K 在搜尋階段即拒絕。
- runner 在計時前做數值或覆蓋 preflight。

CPU Debug 已證明上述 kernel 控制流與數值結果；只有真機 smoke 能關閉最新版本的
NPU 驗證項目。

## 最優性邊界

目前可以聲明：

> 在指定 CANN、SoC、搜尋參數與代理模型下，找到已通過官方 API 和 kernel
> 契約的 best-known tiling。

真機 full 完成前不能聲明：

- 全部合法 tiling 的數學全域最優
- 真機 latency/TFLOPS 改善比例
- 代理模型在所有 workload 的排名準確度

真機結果需以 median、p95、stddev、rank correlation 與 top-k regret 報告。

## 系統影響

所有改動與輸出限制在專案目錄。腳本不修改：

- `/usr/local/Ascend/ascend-toolkit` symlink
- driver/firmware
- shell profile
- 系統全域 `PATH`/`LD_LIBRARY_PATH`
- NPU 系統設定

環境變數只存在於 `run_npu.sh` 及其子行程。

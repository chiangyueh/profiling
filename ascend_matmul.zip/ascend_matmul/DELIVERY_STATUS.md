# 驗證狀態

## 已完成

- CANN 8.3 RC2 Host 編譯：通過
- 官方 `MultiCoreMatmulTiling::GetTiling()` 實際執行：通過
- 約束感知 Beam Search + Tabu/LNS：通過
- 大型、極瘦、轉置、尾塊與多資料型別工作負載 Host 搜索：通過
- 最終 `TCubeTiling` 容量、核心映射與 kernel execution-mode 契約：通過
- AscendC `dav-c220-cube` Kernel 編譯：通過
- FP16/BF16/FP32/INT8 × NN/TN/NT/TT 共 16 個 Kernel 入口：通過
- ACL Event NPU profiling Runner 編譯：通過
- CANN `tikicpulib::Ascend910B1` V220 CPU Debug FP16 MatMul Kernel：執行與零矩陣結果檢查通過
- CSV 與原始 `TCubeTiling` 二進位輸出：通過
- FP16/BF16/INT8 候選不再輸出不匹配的直接原子 Split-K：通過
- FP32 NT 單輪直接原子 Split-K 分類與 AscendC 編譯：通過

## 目前未在交付工作區執行

- 修正 execution-mode 契約後的完整 Ascend 910B profiling
- 真機最終延遲、吞吐與 msprof 指標

本工作區沒有昇騰 NPU 和驅動。先前版本已由使用者在 Ascend 910B3 上完成
smoke，但 full run 暴露了 FP16 Split-K 模板錯配；本版已在 Host/AscendC 編譯與
CPU 模擬驗證契約，仍需在同一台 910B3 重新執行 smoke。最終排名以真機
`median_ms` 為準。

## 執行後會生成的輸出

```text
results/candidates.csv             可執行且去重後的 Top-K 候選
results/all_evaluated.csv          內部評估與拒絕原因
results/tilings/*.bin              candidates.csv 對應的官方 TCubeTiling
results/npu_*_profile.csv          NPU 聚合統計與 preflight 狀態
results/npu_*_samples.csv          每次 ACL Event 延遲樣本
```

交付包不包含 `build/` 或 `results/`，這些目錄由 `run_npu.sh` 在目標機器上重新生成。

# NPU 快速執行

```bash
cd ascend_matmul
chmod +x run_npu.sh scripts/*.sh
./run_npu.sh --mode smoke
```

正常階段：

```text
[0/4] Setup CANN environment ... ok
[1/4] Detect NPU SoC ... ok
[2/4] Build tiling host/official runner ... ok
[3/4] Search tiling candidates ... ok
[4/4] Run NPU ACL Event profiling ... ok
```

第 3 階段必須顯示實際平台 AIC 數。第 4 階段會先顯示：

```text
bank_verified: soc=Ascend910B3 aic=<實際值> input_bytes=183 fields=23
bank_candidates_validated: 1
```

這代表候選已由 CANN runtime-bank API 接受，之後才會啟動官方 MatMulV3。
Smoke 量測一個官方自動 baseline 和一個搜尋 rank-1；兩者都使用
`aclnnMatmul`，沒有自製 kernel 或 CPU fallback。

成功後 terminal 會輸出：

```text
NPU_RESULT_BEGIN
...
NPU_RESULT_END
```

並留下：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv
```

確認 smoke 成功後：

```bash
./run_npu.sh --mode full
```

第一次可縮小 NPU 測量量：

```bash
TOP_K=5 RANK_LIMIT=5 WARMUP=5 REPEAT=20 SAMPLES=5 \
./run_npu.sh --mode full
```

Full 預設先在 host 端驗證全部候選 bank，全部通過後才開始 NPU；每個候選在
獨立 process 執行，預設 60 秒 timeout。發生錯誤時 terminal 直接顯示
workload、rank、階段與 CANN/ACL 訊息，不會繼續產生大量相同失敗。

查看伺服器與 linked official runner 的 ACL 狀態：

```bash
./run_npu.sh --check-server
```

完整輸出：

```bash
RUN_VERBOSE=1 ./run_npu.sh --mode smoke
```

腳本只設定自身和子行程環境，且只寫專案的 `build/`、`results/`；不修改
系統 CANN 路徑、symlink、driver、firmware 或 shell profile。

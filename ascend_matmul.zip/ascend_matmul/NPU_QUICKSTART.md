# NPU 快速執行

```bash
cd ascend_matmul
chmod +x run_npu.sh scripts/*.sh
./run_npu.sh --mode smoke
```

正常階段：

```text
[0/4] Setup CANN environment ... ok
[1/4] Detect NPU SoC ... ok
[2/4] Build tiling host/official runner ... ok
[3/4] Search tiling candidates ... ok
[4/4] Run NPU ACL Event profiling ... ok
```

第 3 階段必須顯示實際平台 AIC 數。第 4 階段會先顯示：

```text
bank_schema: soc=Ascend910B3 aic=<實際值> input_bytes=183 knowledge_fields=23
bank_lookup: [1/2] npu_smoke_fp16 role=bank_seed_control rank=0
bank_records_prepared: 2 lookup=runtime_kb(found=1) execution_check=NPU_preflight
```

這只代表候選的 runtime-bank 格式與索引可被 CANN 找到，不代表 kernel
一定可執行。之後每個候選仍須通過官方 MatMulV3 的 NPU preflight，確認
沒有 AICore 例外且輸出頭、尾與抽樣位置都被寫入。
Smoke 量測一個官方自動 baseline、一個 bank roundtrip control 與一個
官方 seed 附近的單變因候選；全部使用 `aclnnMatmul`，沒有自製 kernel 或
CPU fallback。

量測期間會顯示：

```text
WORKLOAD [1/1] npu_smoke_fp16 shape=256x256x256 dtype=fp16 official_ms=...
bank_control_start ... tpl=BASE T=... S=... C=... G=... L2=...
bank_control_done ... ms=... official_ms=... status=...
candidate_done ... rank=1 ... speedup_vs_official=...
WORKLOAD_RESULT ... best_rank=1 ... optimization_result=...
```

`speedup=official_ms/searched_ms`，大於 `1` 才表示搜尋結果較快。`T` 是
base MNK，`S` 是 kernel 實際 single-core MNK，`G` 是輸出 tile 網格，
`L2` 是 L2 排程的 tile 數與每個 tile 涵蓋的 block 數；`I/L1/DB`
用來區分 base tile 相同但 traversal、L1 depth 或 double buffer 不同的候選。
`optimization=improved` 只會在 searched 同時勝過官方 baseline 與
bank-path control，且改善超過噪聲門檻時出現。否則會明確顯示
`no_proven_improvement`，官方數據只作比較基準。

成功後 terminal 會輸出：

```text
NPU_RESULT_BEGIN
...
NPU_RESULT_END
```

並留下：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv
```

確認 smoke 成功後：

```bash
./run_npu.sh --mode full
```

Full 預設讀取 `config/workloads.csv` 的 40 組 workload。39 組支援的
MatMulV3 形狀共有 39 個 bank controls 與 94 個 searched candidates；
INT8 是明確 unsupported 的負向對照。一般形狀只測官方 seed 的兩個
traversal 單變因候選；已知 anchor 與 3 個未見 skinny-N holdout 各有
6 個候選。

程式會讀取 `results/npu_full_ocr_measurements.csv`，以 SoC、shape、dtype、
模板及完整排程指紋逐筆重用已完成量測。最後會分別輸出：

```text
GENERALIZATION_RESULT skinny_n ...
PRIOR_FAILURE_RESULT ...
BROAD_VALIDATION_RESULT ...
MATMUL_WIDE_RESULT ...
```

已知 anchor 成功不計為泛化。3 個 unseen holdout 必須全部改善，skinny-N
才顯示 `supported`；6 個先前退化 workload 必須全部改善，舊退化修復才顯示
`supported`。任何缺失或未改善都會使整體顯示 `not_proven`。
另外 28 個一般支援 workload 必須全部改善，才可能顯示
`MATMUL_WIDE_RESULT status=supported`。INT8 負向對照會單列為
`unsupported_control`，不會被當成 searched failure。

第一次可縮小 NPU 測量量：

```bash
TOP_K=5 RANK_LIMIT=5 WARMUP=5 REPEAT=20 SAMPLES=5 \
./run_npu.sh --mode full
```

Full 預設先完成所有候選的靜態契約與 runtime-bank lookup，再開始 NPU；
每個候選在獨立 process 執行，預設 60 秒 timeout。發生錯誤時 terminal
只輸出一個 `TILING_ERROR_BEGIN/END` 區塊，包含 workload、rank、模板、
`T/S/C/G/L2`、L1 深度、失敗階段、C 的 row/column/poison 值及三層驗證
狀態，隨即停止，不會把後續候選全部標成相同失敗。

查看伺服器與 linked official runner 的 ACL 狀態：

```bash
./run_npu.sh --check-server
```

完整輸出：

```bash
RUN_VERBOSE=1 ./run_npu.sh --mode smoke
```

腳本只設定自身和子行程環境，且只寫專案的 `build/`、`results/`；不修改
系統 CANN 路徑、symlink、driver、firmware 或 shell profile。

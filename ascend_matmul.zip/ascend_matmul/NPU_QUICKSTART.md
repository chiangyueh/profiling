# NPU 快速執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
```

Smoke 模式只跑一個小型 NPU workload，少量候選和少量 ACL Event samples，用來確認：

- CANN 路徑正確
- Host tiling search 可執行
- AscendC host-stub kernel 可 register/launch
- ACL launch/profiling 可執行
- CSV 與 tiling binary 契約一致，poisoned-output preflight 通過

執行時會自動寫日誌到：

```text
results/logs/run_npu_*.log
```

預設終端只顯示階段狀態和錯誤摘要。需要完整中間輸出時使用：

```bash
RUN_VERBOSE=1 ./run_npu.sh --mode smoke
```

`[0/4] Setup CANN environment` 會優先使用官方
`/usr/local/Ascend/ascend-toolkit/set_env.sh`，並設定本工程需要的
`CANN_ROOT`、`CANN_PLATFORM_ROOT` 和 `ASCEND_LATEST_INSTALL_PATH`。腳本會把
真實 driver library 放在 toolkit `devlib` 前面，避免 runtime 誤載開發期 stub。

`[1/4] Detect NPU SoC` 會從 `npu-smi`、`ascend-dmi` 或 ACL probe 查實際
SoC，並強制驗證同一個 runtime 下 `aclInit + aclrtGetSocName` 可執行。NPU build
必須拿到具體型號，例如 `Ascend910B1/B2/B2C/B3/B4/B4-1`；只拿到泛化
`Ascend910B`，或 ACL probe 報錯時，會直接停止，不會再默認改成 `Ascend910B1`。

如果失敗但終端輸出太少，直接查看最後一個日誌：

```bash
ls -t results/logs/run_npu_*.log | head -1
tail -120 "$(ls -t results/logs/run_npu_*.log | head -1)"
```

如果 `[1/4]` 或 `[4/4]` 發生 ACL/runtime 失敗，腳本會額外生成
`results/logs/runtime_diag_*.log`，其中包含實際 `CANN_ROOT`、`ASCEND_HOME_PATH`、
`LD_LIBRARY_PATH` 里的 Ascend 路徑、`libascendcl.so` 候選，以及
`build/npu_profile_runner` 的 `ldd` 結果。這個 log 用來判斷是否載錯 CANN
runtime 或 driver 動態庫。

確認 smoke 可跑後，再執行完整 NPU profiling：

```bash
./run_npu.sh --mode full
```

若任何候選在 preflight 或同步時失敗，runner 會在第一個失敗候選立即停止，輸出
workload、rank、execution mode 與 stage；不會在已發生 AI Core 例外的 context
繼續測量後續候選。

腳本會按執行機器架構和 ACL probe 結果自動選擇類似下面的 CANN platform root：

```text
/usr/local/Ascend/ascend-toolkit/<working-version>/$(uname -m)-linux
```

如果看到：

```text
aclInit failed, rc=507008
```

`507008` 是 `ACL_ERROR_RT_SOC_VERSION`，代表 runtime 判斷 SoC 版本不匹配。
請看同一次 run log 裡的 `detect_soc_*`、`build_*` 和 `profile_*` phase log。
`build_*` 會打印 runner 裡嵌入的 AscendC kernel SoC marker，例如：

```text
__ascend_kernel_ascend910b2_matmul_search_kernel
```

這個 marker 必須和實際 NPU 子型號一致。

AscendC host-stub 編譯需要具體 910B 型號。腳本會自動偵測
`Ascend910B1/B2/B2C/B3/B4/B4-1` 並傳給 build。硬體查詢只能回報泛化
`Ascend910B` 時會停止，因為錯編成其他子型號會導致 NPU runtime/二進制不匹配。

第一輪對每個工作負載測量前 12 個候選：

```bash
RANK_LIMIT=12 WARMUP=10 REPEAT=50 SAMPLES=15 \
./scripts/profile_npu.sh results/candidates.csv results/npu_round1
```

輸出：

```text
results/npu_round1_profile.csv
results/npu_round1_samples.csv
results/npu_round1_ranked.csv
results/npu_round1_best.csv
results/npu_round1_proxy_comparison.csv
```

精測前 3 名：

```bash
RANK_LIMIT=3 WARMUP=30 REPEAT=200 SAMPLES=30 \
./scripts/profile_npu.sh results/candidates.csv results/npu_precise
```

單一候選取得 msprof：

```bash
./scripts/profile_one_msprof.sh llm_full_4096_ffn_up 1 results/candidates.csv
```

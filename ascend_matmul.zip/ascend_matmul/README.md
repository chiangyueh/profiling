# Ascend 910B MatMul Tiling Search

這是一個獨立的二維 ND MatMul tiling 搜尋與驗證工程。搜尋器提出離散提示，
最終 `TCubeTiling` 必須由安裝中的官方
`matmul_tiling::MultiCoreMatmulTiling` 產生並通過 kernel 契約。

```text
API 自動 tiling 種子
        +
singleCoreM/N/K 合法分核集合
        |
約束感知 Beam Search
        |
官方 MultiCoreMatmulTiling::GetTiling/GetCoreNum
        |
TCubeTiling 容量、對齊、分核與模板契約
        |
逐核 V220 pipeline 靜態代理模型
        |
Tabu Search + Large Neighborhood Search
        |
依官方 TCubeTiling 去重後的 Top-K
        |
API 自動 rank-0 + 搜尋 Top-K 的自訂 kernel 計時
        +
安裝版 aclnnMatmul/MatMulV3 端到端基線
```

搜尋維度包含：

- `singleCoreM/N/K`，即 M/N/K 核心切分提示
- `baseM/N/K`，即核心內 L0 Cube tiling 提示
- M/N 遍歷順序
- L0A/L0B 雙緩衝提示
- kernel 模板確實支援時的跨核心 split-K

提示值不是最終值。官方 API 可以調整提示，CSV 會同時保存候選提示與官方回傳值。

## 支援範圍

目前 kernel 支援二維、稠密、ND、無 Bias：

```text
FP16 / BF16 / FP32 / INT8
NN / TN / NT / TT
INT8 輸出 INT32
```

`baseK < K` 是每個核心內的 K 軸 blocking，所有 dtype 都會搜尋。
`singleCoreK < K` 才是跨核心 split-K：

- FP32、`transA=false`、`transB=true`：支援官方直接 atomic、單輪模板。
- FP16/BF16/INT8：不輸出直接 atomic split-K；這些模式需要完整
  deterministic/workspace reduction 與輸出 cast 模板。

Batch MatMul、NZ、Bias、量化尺度和稀疏矩陣不在目前介面內。

## 關鍵合法性

候選必須依序通過：

1. M0/N0/K0 對齊與 L0A/L0B/L0C 必要容量條件。
2. 官方 `SetSingleShape`、`SetFixSplit`、`GetTiling`。
3. 官方 `GetCoreNum` 與最終 `singleCoreM/N` 分區一致。
4. 最終 DB、L1 depth/step、shared L1/L0C/UB 容量檢查。
5. 本工程 kernel 的 execution-mode 契約。

一般 M/N 分核允許：

```text
logical M/N tiles > usedCoreNum
```

kernel 會把多個 tile 以平衡 round 分給同一核心。這不是放寬檢查：
官方 API 實際可回傳例如 `mDim=8,nDim=6,usedCoreNum=24`，即 48 個邏輯 tile
在 24 核執行兩輪。

## 已完成的本機證據

環境：

- CANN 8.3 RC2，x86_64
- 官方平台配置 `Ascend910B`
- 正式 NPU 編譯目標 `Ascend910B3`

已通過：

- 官方 `MultiCoreMatmulTiling::GetTiling/GetCoreNum` 實際調用
- 6 組大型 validation workload、48 個一般搜尋候選與 5 個 API 基線契約
- 9 個多輪 M/N 候選契約
- FP32 NT 直接 split-K 候選契約
- 16 個正式 NPU kernel 入口與 ACL runner 的 B3 單進程編譯
- CANN tikicpulib CPU Debug 非零逐元素數值比較：
  - FP16 NN `256x256x256`，24 核
  - FP16 NN `129x257x65`，27 個邏輯 tile / 24 核
  - FP16 TN/NT/TT `129x257x65`
  - FP32 NT split-K `16x16x4096`，24 核

本機沒有 NPU，因此最新版本的真機 correctness/latency 仍需在 910B3 執行
`run_npu.sh --mode smoke`。詳見 [DELIVERY_STATUS.md](DELIVERY_STATUS.md)。

## NPU 一鍵執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
./run_npu.sh --mode full
```

腳本只修改自身子行程的環境並在專案 `build/`、`results/` 寫檔；不修改 shell
profile、toolkit symlink、driver、firmware或系統路徑，也不會退回 CPU 假裝 NPU 成功。

### Smoke 規模

```text
workload: 1 個 FP16 256x256x256
profile:  安裝版 aclnnMatmul + API 自動 rank-0 + 搜尋 rank-1
warmup:   2
repeat:   5
samples:  3
call:     每個量測配置 1 次 preflight + 2 + 5*3 = 18 次，共 54 次
```

小矩陣 preflight 使用全 1 輸入，抽查輸出必須等於 `K=256`。

### Full 規模

```text
workload: 28 個
shape:    decode M=1 到 8192^3、LLM/attention/vision/skinny/odd/transpose
dtype:    FP16/BF16/FP32/INT8
Top-K:    每 workload 最多 20
warmup:   10
repeat:   50
samples:  15
```

每個 workload 都會額外量測 API 自動 tiling；官方 MatMulV3 支援的 workload
還會量測一次安裝版 `aclnnMatmul`。目前清單含 27 個官方支援的
FP16/BF16/FP32 workload 與 1 個官方不支援的 INT8 workload，因此完整上限為：

```text
搜尋候選              28 * 20 = 560
API 自動基線          27 * 1  = 27
官方 operator 基線    27 * 1  = 27
總量                           = 614 個量測配置
```

每個配置執行 `1 + 10 + 50*15 = 761` 次 operator call。自訂配置每次是一個
AscendC kernel；官方 `aclnnMatmul` 可包含其正式執行鏈。可先縮小：

```bash
TOP_K=5 RANK_LIMIT=5 WARMUP=5 REPEAT=20 SAMPLES=5 \
./run_npu.sh --mode full
```

候選以獨立 runner 行程執行。60 秒無進度會終止該行程並輸出 workload、rank、
stage 和 tiling；任何候選失敗會使整體命令回傳非零。

## CPU 驗證

快速：

```bash
./scripts/run_cpu_kernel_smoke.sh --mode smoke
```

完整 FP16 transpose 加 FP32 split-K：

```bash
./scripts/run_cpu_kernel_smoke.sh --mode full
```

Host 搜尋、代理模型與候選契約：

```bash
SKIP_BUILD=1 ./scripts/validate_cpu.sh
```

CPU Debug 固定 `-j1`，預設限制 640 MiB。模擬產生的 `cceprint/`、`npuchk/`
與 `stub_reg.log` 會自動清除。

## 單獨編譯與搜尋

在 NPU 主機，`run_npu.sh` 會先自動偵測精確 SoC。手動編譯時需提供子型號：

```bash
ASCENDC_SOC_VERSION=Ascend910B3 BUILD_JOBS=1 ./scripts/build_all.sh
```

單一 workload：

```bash
./build/matmul_tiling_search \
  --id ffn_up \
  --m 4096 --n 11008 --k 4096 \
  --dtype fp16 --trans-a 0 --trans-b 0 --cores 24 \
  --beam-width 64 --tabu-iters 64 --lns-rounds 8 \
  --max-core-rounds 4 --top-k 20 \
  --output results/ffn_up_candidates.csv \
  --all-output results/ffn_up_all.csv \
  --tiling-dir results/ffn_up_tilings
```

完整 workload CSV：

```bash
./scripts/run_search.sh config/workloads.csv
```

## 輸出

```text
results/candidates.csv
    rank-0 API 自動 tiling，以及按官方 TCubeTiling 去重後的搜尋 Top-K

results/all_evaluated.csv
    所有送入官方 API 的完整候選及拒絕原因

results/tilings/*.bin
    原始 TCubeTiling，供 kernel runner 使用

results/npu_*_profile.csv
    自訂 kernel 的 API 自動基線與搜尋候選聚合結果

results/npu_*_samples.csv
    自訂 kernel 每次 ACL Event 的 latency

results/npu_*_official_profile.csv / *_official_samples.csv
    安裝版 aclnnMatmul/MatMulV3 的端到端基線與樣本

results/npu_*_ranked.csv / *_best.csv / *_proxy_comparison.csv
    NPU 排名、每 workload 最佳值、代理模型誤差

results/npu_*_baseline_comparison.csv
    搜尋最佳值分別相對 API 自動基線與官方 operator 的改善/劣化判定
```

候選 CSV 包含：

- 候選與官方 `singleCoreM/N/K`
- 候選與官方 `baseM/N/K`
- `usedCoreNum` 與官方 `mDim/nDim`
- L1 depth/step、iterate order、DB、shared memory
- execution mode 與 M/N/K 邏輯分區數
- 最慢/平均核心、Cube/MTE/FixPipe/Scalar 週期
- A/B/C GM 流量、tail efficiency、core utilization、arithmetic intensity

## 「最佳」的準確含義

NPU 執行前輸出的 Rank-1 是：

> 在指定 CANN、SoC、搜尋邊界與靜態代理模型下，已調用官方 API 且通過契約的
> 候選中，搜尋器找到的最低預測成本。

Beam + Tabu/LNS 不是全空間窮舉，因此不能在真機前宣稱數學全域最優。NPU Top-K
資料用於報告：

- 搜尋最佳值相對 API 自動 tiling 的改善或劣化
- 自訂 kernel 相對安裝版 MatMulV3 operator 的改善或劣化
- 預測排名與真機排名的 Spearman/Kendall correlation
- top-k regret
- 相對兩種基線的 latency/TFLOPS 改善
- 重複樣本噪聲

這保留了 tiling 的預測性，也避免把「每個 tiling 全跑一次」誤稱為搜尋。

`rank=0` 的 `api_auto_baseline` 使用同一個自訂 kernel，只把 tiling 換成
`MultiCoreMatmulTiling` 無提示輸出，因此隔離的是搜尋 tiling 本身的效果。

`official_operator_baseline` 則呼叫安裝中的 `aclnnMatmul`，使用相同 shape、
dtype、transpose view、stream、warmup、repeat、samples 與 ACL Event 邊界。
`aclnnMatmulGetWorkspaceSize`、executor 建立、記憶體配置和 correctness preflight
都不計入 latency。這才是完整 CANN MatMulV3 的端到端原始版本比較；報表的
`primary_reference` 在它可用時固定選它。公開 MatMulV3 不支援 INT8，因此 INT8
會標記 `official_operator_unsupported`，不會宣稱優化或劣化。

更詳細的模型與研究依據見 [docs/algorithm.md](docs/algorithm.md)，真機流程見
[docs/npu_profiling.md](docs/npu_profiling.md)。

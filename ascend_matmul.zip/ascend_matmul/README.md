# Ascend MatMulV3 定向 Tiling 優化

本工程只研究 CANN `MatMulV3` 的 tiling。搜尋結果透過 CANN RuntimeKb
注入安裝版 `MatMulV3`，baseline 與 searched candidate 都由同一個
`aclnnMatmul`、同一套官方 kernel 執行；工程沒有自製 MatMul kernel，也不會
用 CPU 或其他算子替代失敗候選。

## 目前優化範圍

目前版本只優化一個已由 910B3 真機證明有收益的區域：

```text
layout       NN
dtype        FP16
shape family 16 < N <= 32、K >= 8192
target       M 方向可恰好分成 20 個對齊 output blocks
template     MatMulV3 BASE
```

這是刻意的研究收斂，不代表其他 shape 已完成優化。先前把通用
`MultiCoreMatmulTiling` 的候選平鋪到所有 MatMulV3 BASE workload，造成大型
矩陣最高接近 `2x` 的退化；該策略已停用。

專案仍保留 CANN 8.1.RC1、DAV C220 的 7 個模板族、12 個 suffix 契約，供
回歸驗證使用：

| 模板族 | kernel suffix |
|---|---|
| `BASE` | `0`, `1` |
| `SINGLE_CORE_SPLIT_K` | `20`, `21` |
| `DETERMINISTIC_SPLIT_K` | `30`, `31` |
| `AL1_FULL_LOAD` | `101` |
| `BL1_FULL_LOAD` | `200`, `201` |
| `BL1_FULL_LOAD_FIXPIPE` | `10200`, `10201` |
| `BL1_FULL_LOAD_VEC_NZ2ND` | `20201` |

`0/1` 等成對 suffix 分別覆蓋 unaligned/aligned kernel。程式不生成 CANN
8.1 kernel 中不存在的 split mode 4、5、6，也不把其他 CANN 版本的模板名稱
硬套進來。

支援 FP16、BF16、FP32。INT8 保留為負向 corpus，會明確標記 unsupported；
它不屬於這條公開 `MatMulV3` 輸入路徑。

## 目前工作流

```text
偵測精確 SoC 與 AIC/L0/L1/L2
  -> 官方 MatMulV3 callback 產生 BASE control
  -> 由 ceil_align(M/AIC,16) 建立窄 N 負載均衡候選
  -> 依官方 CalL1Tiling 建立「只改核心分工」消融
  -> 建立 A-heavy L1、L0C DB、L2 order 三個逐步消融
  -> constraint-aware Beam Search
  -> Tabu + Large Neighborhood Search
  -> 官方 MatMulV3 callback 回讀
  -> 要求模板族、suffix、23 個 knowledge 欄位完全一致
  -> RuntimeKb::InitBank + QueryBank(found=1)
  -> 官方 aclnnMatmul correctness preflight
  -> ACL Event latency
  -> 與空 bank 的官方自動 tiling、bank seed control 比較
```

搜尋不是「先產生大量錯誤 tiling 再碰運氣」。目前每個目標 workload 只產生
4 個具備單一變因意義的候選；只有官方 callback 保持原模板與全部 23 欄位的
候選才會輸出給 NPU。

## 執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
./run_npu.sh --mode full
```

腳本不修改 toolkit symlink、driver、firmware、shell profile 或系統
`LD_LIBRARY_PATH`。CANN 環境、`TUNE_BANK_PATH`、`ASCEND_CACHE_PATH` 只存在
於腳本子行程，暫存 bank 只建立在專案 `results/` 下。

### Smoke

Smoke 是 NPU 執行鏈快速檢查，不代表優化結果：

```text
workload       1 個 FP16 256x256x256
比較           官方自動 tiling + RuntimeKb bank roundtrip control
warmup         2
repeat         5
samples        3
```

### Full

Full 是目前窄 N/大 K 假設的正式消融：

```text
workload       4096x17x16384 FP16 NN
control        官方 128x32x64 bank seed
候選           4 個：core balance / L1 / L0C DB / L2 order
warmup         10
repeat         50
samples        15
```

預設輸入是 `config/workloads_skinny_n.csv`。完整 36 組 corpus 仍保存在
`config/workloads.csv`，但目前只作契約回歸，不宣稱其候選已優化。

## 本輪真正被優化的欄位

一筆 MatMulV3 RuntimeKb knowledge 有 23 個欄位。本輪固定模板、layout、
dtype 與 K 分法，只調整：

- `baseM/singleCoreM`: `128 -> 208`，令 4096 恰好形成 20 個 M blocks。
- `depthA1/B1`、`stepKa/Kb`: 官方式 `8/64, 4/32` 對比
  A-heavy `16/8, 8/4`。
- `dbL0C`: `1/2`。
- `l2IterateOrder`: `0/1`。

`baseN=32`、`baseK=64`、`usedCoreNum=20`、`tilingEnable=0` 與官方
四核 L2 分組保持固定。

一般 BASE 搜尋只接受一個 output task 對應一個 Cube base tile：
`singleCoreM <= baseM`、`singleCoreN <= baseN`，且兩者只能因 logical tail
小於 base。這與 CANN 8.1 `CalL1Tiling()` 將 `singleCoreM/N` 設為
`baseM/N` 的路徑及已安裝 RuntimeKb 記錄一致。可令 `singleCoreM/N` 大於
base 的排程屬於 Split-K 或 full-load 等獨立模板，不能把其語意套到一般
BASE。

`usedCoreNum` 也可以大於輸出 tile 數，多出的 core 會退出。這是合法但通常
低效，因此由 active-core 與 tail 模型懲罰，不再誤判成非法。

## 硬合法性

所有候選先檢查：

```text
baseM % 16 == 0
baseN % 16 == 0
FP32 NT: baseK % 8 == 0
其他 layout: baseK % 16 == 0

baseM * baseK * inputBytes * dbL0A <= L0A
baseN * baseK * inputBytes * dbL0B <= L0B
baseM * baseN * 4 * dbL0C         <= L0C

baseM * baseK * inputBytes * depthA1
+ baseN * baseK * inputBytes * depthB1 <= effective L1
```

另外逐模板檢查：

- BASE 的 `singleCoreK == K`、單一 output task 不跨越多個 base M/N
  tile，以及完整 M/N output grid 與 L2 schedule。
- Single-Core Split-K 的 MK33、NK33、MK24、MK14 pipeline、K loop、
  FP32 workspace/atomic accumulate 與 AIV cast。
- Deterministic Split-K 的 128x128 基本塊、MK33/NK33、
  `singleCoreK=3*baseK` 與 workspace reduction。
- AL1/BL1 full-load 的 operand 常駐條件與 L1 容量。
- Fixpipe 的 32-byte output boundary。
- Vec NZ2ND 的 FP32/layout/workspace 條件。
- aligned/unaligned logical shape 與 callback 選到的 suffix。

910B3 Platform API 回報 L1=524032 B，但官方 callback 可合法產生 524288 B
的 MatMul allocation。程式只在本身容量判斷中按 KiB allocation boundary
處理，不改任何系統設定。

## 搜尋算法

本輪先建立四個完整且硬合法的消融候選，再按以下欄位層次做 Beam：

```text
BASE + core partition + singleCoreMNK
  -> baseMNK
  -> L1 step/depth + iterateOrder
  -> L0 DB
  -> L2 schedule
```

每層只保留前 `BEAM_WIDTH` 個 prefix 的最佳合法 completion。Beam 前幾名再
進入 Tabu；LNS 每輪放鬆一組或兩組語義欄位，其他欄位固定。所有鄰居都來自
同一個硬合法池，不做浮點取整或事後 repair。

代理模型只負責這四個局部候選的排序。先前真機結果已證明它不能跨模板形狀
可靠排序，因此不再讓模型從 `176x176` 等通用 API 輸出擴張出大型 BASE
候選。cycle estimate 不會冒充 NPU latency。

算法與研究依據見 [docs/algorithm.md](docs/algorithm.md)。

## Baseline 與結果定義

每個支援 workload 比較三條路徑：

```text
official_operator  空的專案 bank，CANN 原始自動/內建 tiling
bank_seed_control  官方 23 欄 seed 經相同 RuntimeKb 路徑重放
searched           本搜索器選出的 23 欄候選
```

只有 searched 勝過同一 RuntimeKb 路徑的 bank control，並同時列出相對
official 的結果，且差值超過合併量測噪聲，
才能稱為 tiling optimization。官方比較較快時，結果必須寫
`no_proven_improvement`，不能把「選回官方」稱為我們的優化。

NPU 前只能稱候選為 host-ranked；NPU 後只能稱為指定 CANN、SoC、workload
與 profiling 預算下的 best measured candidate。Beam/LNS 不是數學全空間
窮舉，因此不宣稱全域最優。

## 輸出與續跑

終端會在執行中顯示：

```text
template / T(baseMNK) / S(singleCoreMNK) / cores
output grid / L2 / L1 / DB
median ms / stddev / speedup / delta / noise / verdict
```

並留下：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv
results/npu_full_summary.csv
results/npu_full_candidates.csv
```

已由封閉 NPU 機器轉錄的結果保存在
`results/npu_full_ocr_measurements.csv`。官方 baseline 可按 SoC、AIC、
shape 與 dtype 重用。候選只有在保存完整排程且標記
`preflight_contract=grid9_v1` 時才能重用；舊 OCR 候選缺少完整 23 欄排程，
而且只通過舊 5 點 coverage check，因此只保留為研究紀錄，不會冒充精確的
有效候選。`KEEP_DETAILS=1` 才保留 samples 與 all-evaluated 中間資料。

## Host 契約驗證

不啟動 NPU、不跑 CPU simulator：

```bash
BUILD_JOBS=1 ASCENDC_SOC_VERSION=Ascend910B3 \
SOC_VERSION=Ascend910B3 ./scripts/validate_cpu.sh
```

目前窄 N scope 的 CANN 8.1.RC1 驗證結果：

```text
bank control:    1
searched rows:   4
callback valid:  4/4
kernel family:   BASE
```

每個 searched row 都通過官方 callback 的模板、suffix、23 欄位 roundtrip。
這證明搜索與注入契約完整，不等於已證明 NPU 加速；後者必須執行 full。

NPU 計時與錯誤輸出見 [docs/npu_profiling.md](docs/npu_profiling.md)，先前
環境與執行問題見 [NPU_TILING_EXECUTION_HISTORY.txt](NPU_TILING_EXECUTION_HISTORY.txt)。

# Ascend MatMulV3 Tiling Search

本工程只研究 MatMulV3 tiling。它不再包含自製 MatMul kernel，也不以自製
host-stub runner 判斷 tiling 合法性。

完整路徑是：

```text
偵測實際 SoC
    -> 約束感知 Beam Search
    -> 官方 MultiCoreMatmulTiling::GetTiling/GetCoreNum
    -> L0/L1/DB/分核/模板契約
    -> Tabu + Large Neighborhood Search
    -> CANN MatMulV3 runtime tuning bank
    -> RuntimeKb::QueryBank 驗證
    -> 安裝版 aclnnMatmul / 官方 MatMulV3 kernel
    -> correctness preflight + ACL Event
```

搜尋器決定要嘗試哪些離散提示；CANN 產生完整 `TCubeTiling`；最後仍由安裝
中的官方 MatMulV3 kernel 執行。原始版本比較使用相同官方 operator，但不注入
搜尋候選。

## 一鍵執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
./run_npu.sh --mode full
```

腳本不會切換到 CPU 模式，也不會修改 toolkit symlink、driver、firmware、
shell profile 或全域路徑。`TUNE_BANK_PATH`、`ASCEND_CACHE_PATH` 與 CANN
環境只存在於腳本的子行程；所有暫存 bank 都在專案 `results/` 下並在結束時
刪除。

### Smoke

```text
workload       1 個 FP16 256x256x256
配置           官方自動 baseline + 搜尋 rank 1
warmup         2
repeat         5
samples        3
每配置呼叫數   1 preflight + 2 + 5*3 = 18
總配置         2
```

小矩陣使用全 1 輸入，抽查輸出必須等於 `K=256`。

### Full

```text
workload       28 個
範圍           M=1 decode 到 8192^3，含 attention、skinny、odd-tail、transpose
dtype          FP16、BF16、FP32；INT8 不屬於公開 MatMulV3 路徑
候選           每個受支援 workload 最多 Top-20
warmup         10
repeat         50
samples        15
```

目前有 27 個 MatMulV3 workload。上限是 27 個 baseline 加 540 個搜尋候選；
不同提示映射成相同官方 tiling 時，實際數量會較少。第一次可縮小：

```bash
TOP_K=5 RANK_LIMIT=5 WARMUP=5 REPEAT=20 SAMPLES=5 \
./run_npu.sh --mode full
```

## 搜尋變數

- `singleCoreM/N/K`：M/N/K 核心切分提示。
- `baseM/N/K`：核心內 L0 Cube tile。
- M/N traverse order。
- L0A/L0B double buffer。
- 僅在官方模板契約成立時的 multi-core split-K。

候選提示不是最終值。每個完整候選都必須呼叫：

```cpp
MultiCoreMatmulTiling::SetSingleShape(...)
MultiCoreMatmulTiling::SetFixSplit(...)
MultiCoreMatmulTiling::SetDoubleBuffer(...)
MultiCoreMatmulTiling::SetTraverse(...)
MultiCoreMatmulTiling::EnableMultiCoreSplitK(...)
MultiCoreMatmulTiling::GetTiling(...)
MultiCoreMatmulTiling::GetCoreNum(...)
```

CSV 同時保存提示與 CANN 最終回傳值，並以最終 tiling signature 去重。

## 合法性

基本 Cube 對齊：

```text
baseM % 16 == 0
baseN % 16 == 0
FP16/BF16: baseK % 16 == 0
FP32:      baseK % 8  == 0
```

還會檢查：

- 最終 `usedCoreNum` 不超過實際 SoC AIC 數。
- `GetCoreNum` 與 `singleCoreM/N` 分區一致。
- L0A/L0B/L0C 容量及 ping-pong buffer。
- `depthA1/B1` 與 `stepM/N/Ka/Kb`。
- L1、shared L1/L0C/UB。
- 一般 M/N 多輪覆蓋。
- split-K reduction 模板。

未對齊的 logical M/N/K 不是非法 tiling。官方 MatMulV3 會依原始 shape
產生 ND2NZ/NZ2ND 與 tail metadata，因此 odd-tail 候選保留並由官方 kernel
驗證。

`baseK < K` 是核心內 K blocking。`singleCoreK < K` 才是跨核心 split-K；
目前只映射官方 `MULTI_CORE_SPLIT_K`：

```text
dtype=FP32
transA=false
transB=true
M-parts * N-parts * K-parts <= 實際 AIC 數
```

## 官方 Tiling 注入

MatMulV3 的 host tiling 會先呼叫 `GetTilingFromRepo()`，用
`MatMulV3InputArgs` 查詢 runtime bank。候選被寫成 CANN 原生 23-field
`MatMulV3TunnerTiling`：

```text
usedCoreNum
singleCoreM/N/K
baseM/N/K
depthA1/B1
stepM/N/Ka/Kb
iterateOrder
dbL0A/B/C
L2 fields
tilingEnable
```

開始 NPU 測量前，工程會：

1. 依精確 SoC 和 AIC 數找到安裝中的 MatMulV3 bank schema。
2. 驗證 packed key 固定為 183 bytes。
3. 用 CANN `RuntimeKb::CommonHash` 重算內建記錄 ID。
4. 為每個候選建立獨立、專案內的 bank。
5. 用 `RuntimeKb::QueryBank` 確認每一筆可被 CANN 命中。

任一步失敗就停止，不會把 fallback operator latency 誤報成搜尋候選。

## Baseline 與計時

baseline 與搜尋候選都呼叫同一個 `aclnnMatmul`。差別只有：

```text
baseline   空的專案 TUNE_BANK_PATH -> CANN 原始自動/內建 bank
searched   單一搜尋候選 TUNE_BANK_PATH -> 官方 MatMulV3 使用指定 tiling
```

每個配置在獨立 process 建立 executor，避免 runtime-bank cache 互相污染。
workspace、executor、H2D/D2H 與 preflight 不計入 ACL Event latency。

## 輸出

預設只留下：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv

results/npu_full_summary.csv
results/npu_full_candidates.csv
```

成功後 terminal 同時輸出：

```text
NPU_RESULT_BEGIN
...
NPU_RESULT_END
```

封閉機器可直接轉貼這段。只有需要原始 samples 時才使用：

```bash
KEEP_DETAILS=1 ./run_npu.sh --mode full
```

## Host 驗證

不使用 NPU、也不執行模擬 kernel：

```bash
ASCENDC_SOC_VERSION=Ascend910B3 SOC_VERSION=Ascend910B3 \
./scripts/validate_cpu.sh
```

它會測試代理模型、一般/skinny/odd-tail/transpose/BF16 候選、FP32 NT
split-K，並要求每個候選通過 CANN runtime-bank 查詢。

本機 CANN 8.3 RC2 已通過：

```text
proxy model
21 個 validation CSV row
14 個一般搜尋候選 bank
2 個 FP32 NT split-K candidate bank
27 個 full workload 的代表 rank-1 bank
13 筆內建 Ascend910B3 bank hash ABI
```

本機沒有 NPU，因此真機 latency 與 speedup 必須以遠端 smoke/full 結果判定。

## 最佳值的定義

Beam + Tabu/LNS 不是全空間窮舉。NPU 前的 rank 只表示：

> 在指定 CANN、精確 SoC、合法模板集合與搜尋預算下，代理模型找到的
> best-known tiling。

真機只量 baseline 與搜尋得到的 Top-K，不是把所有 tiling 全部暴力執行。
最終最佳值是已通過官方 kernel correctness preflight 的實測 Top-K 中
`median_ms` 最低者；摘要同時報告相對官方自動 baseline 的改善或劣化。

詳細模型見 [docs/algorithm.md](docs/algorithm.md)，執行與統計見
[docs/npu_profiling.md](docs/npu_profiling.md)，先前錯誤原因見
[NPU_TILING_EXECUTION_HISTORY.txt](NPU_TILING_EXECUTION_HISTORY.txt)。

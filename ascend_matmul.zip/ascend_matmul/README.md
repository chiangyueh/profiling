# Ascend MatMulV3 全模板 Tiling 搜尋

本工程只研究 CANN `MatMulV3` 的 tiling。搜尋結果透過 CANN RuntimeKb
注入安裝版 `MatMulV3`，baseline 與 searched candidate 都由同一個
`aclnnMatmul`、同一套官方 kernel 執行；工程沒有自製 MatMul kernel，也不會
用 CPU 或其他算子替代失敗候選。

## 實際涵蓋範圍

「全模板」是指本機 CANN 8.1.RC1、DAV C220 的
`mat_mul_v3.cpp` 真正 dispatch 的全部 7 個模板族、12 個 suffix：

| 模板族 | kernel suffix |
|---|---|
| `BASE` | `0`, `1` |
| `SINGLE_CORE_SPLIT_K` | `20`, `21` |
| `DETERMINISTIC_SPLIT_K` | `30`, `31` |
| `AL1_FULL_LOAD` | `101` |
| `BL1_FULL_LOAD` | `200`, `201` |
| `BL1_FULL_LOAD_FIXPIPE` | `10200`, `10201` |
| `BL1_FULL_LOAD_VEC_NZ2ND` | `20201` |

`0/1` 等成對 suffix 分別覆蓋 unaligned/aligned kernel。程式不生成 CANN
8.1 kernel 中不存在的 split mode 4、5、6，也不把其他 CANN 版本的模板名稱
硬套進來。

支援 FP16、BF16、FP32。INT8 保留為負向 corpus，會明確標記 unsupported；
它不屬於這條公開 `MatMulV3` 輸入路徑。

## 完整工作流

```text
偵測精確 SoC 與 AIC/L0/L1/L2
  -> 官方 MultiCoreMatmulTiling 產生 BASE seeds
  -> 依 CANN 8.1 kernel 契約構造七個模板族的合法離散空間
  -> constraint-aware Beam Search
  -> Tabu + Large Neighborhood Search
  -> 官方 MatMulV3 callback 回讀
  -> 要求模板族、suffix、23 個 knowledge 欄位完全一致
  -> RuntimeKb::InitBank + QueryBank(found=1)
  -> 官方 aclnnMatmul correctness preflight
  -> ACL Event latency
  -> 與空 bank 的官方自動 tiling、bank seed control 比較
```

搜尋不是「先產生大量錯誤 tiling 再碰運氣」。只有已通過靜態模板契約的完整
候選才會進入 Beam/Tabu/LNS；只有官方 callback 保持原模板與全部 23 欄位的
候選才會輸出給 NPU。

## 執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
./run_npu.sh --mode full
```

腳本不修改 toolkit symlink、driver、firmware、shell profile 或系統
`LD_LIBRARY_PATH`。CANN 環境、`TUNE_BANK_PATH`、`ASCEND_CACHE_PATH` 只存在
於腳本子行程，暫存 bank 只建立在專案 `results/` 下。

### Smoke

Smoke 是 NPU 執行鏈快速檢查，不代表完整研究：

```text
workload       1 個 FP16 256x256x256
比較           官方自動 tiling + 1 個 searched candidate
warmup         2
repeat         5
samples        3
```

### Full

Full 才是正式搜索與比較：

```text
workload       36 組，其中 35 組為 MatMulV3 支援形狀，1 組 INT8 負向檢查
範圍           decode、prefill、large-K、odd-tail、transpose、全 12 suffix
候選           每個 workload 最多 Top-20，先保留每個適用模板族的 leader
warmup         10
repeat         50
samples        15
```

`config/workloads.csv` 已含會觸發所有 12 個 suffix 的對齊與非對齊形狀。Full
不是每個 tiling 都上 NPU：host 端先在合法集合中搜索，NPU 只量官方 baseline、
bank control 與 Top-K。

## 真正被優化的欄位

一筆 MatMulV3 RuntimeKb knowledge 有 23 個欄位。搜索器實際調整：

- kernel family 與 `tilingEnable`。
- `usedCoreNum`、`singleCoreM/N/K`：AIC 分工與尾輪。
- `baseM/N/K`：L0A/L0B/L0C 中的 Cube 基本塊。
- `stepM/N/Ka/Kb`、`depthA1/B1`：L1 reuse window 與 pipeline 深度。
- `dbL0A/B/C`：輸入與輸出 ping-pong。
- `iterateOrder`：核心內 M/N 遍歷。
- `l2MTileCnt/NTileCnt`、`l2MTileBlock/NTileBlock`、
  `l2IterateOrder`：L2 工作集與輸出 grid 遍歷。

BASE 的 `singleCoreM/N` 可以大於 `baseM/N`。官方 CANN 8.1
`mat_mul_base_block.h` 先以 `singleCoreM/N` 分配 AIC 工作，再在核心內由
Matmul API 迭代 `baseM/N/K`；舊版強迫兩者相等正是大矩陣嚴重退化的原因。

`usedCoreNum` 也可以大於輸出 tile 數，多出的 core 會退出。這是合法但通常
低效，因此由 active-core 與 tail 模型懲罰，不再誤判成非法。

## 硬合法性

所有候選先檢查：

```text
baseM % 16 == 0
baseN % 16 == 0
FP32 NT: baseK % 8 == 0
其他 layout: baseK % 16 == 0

baseM * baseK * inputBytes * dbL0A <= L0A
baseN * baseK * inputBytes * dbL0B <= L0B
baseM * baseN * 4 * dbL0C         <= L0C

baseM * baseK * inputBytes * depthA1
+ baseN * baseK * inputBytes * depthB1 <= effective L1
```

另外逐模板檢查：

- BASE 的完整 K 覆蓋、M/N output grid 與 L2 schedule。
- Single-Core Split-K 的 MK33、NK33、MK24、MK14 pipeline、K loop、
  FP32 workspace/atomic accumulate 與 AIV cast。
- Deterministic Split-K 的 128x128 基本塊、MK33/NK33、
  `singleCoreK=3*baseK` 與 workspace reduction。
- AL1/BL1 full-load 的 operand 常駐條件與 L1 容量。
- Fixpipe 的 32-byte output boundary。
- Vec NZ2ND 的 FP32/layout/workspace 條件。
- aligned/unaligned logical shape 與 callback 選到的 suffix。

910B3 Platform API 回報 L1=524032 B，但官方 callback 可合法產生 524288 B
的 MatMul allocation。程式只在本身容量判斷中按 KiB allocation boundary
處理，不改任何系統設定。

## 搜尋算法

每個適用模板先建立有限、完整且硬合法的候選池，再按以下五層做 Beam：

```text
template + core partition + singleCoreMNK
  -> baseMNK
  -> L1 step/depth + iterateOrder
  -> L0 DB
  -> L2 schedule
```

每層只保留前 `BEAM_WIDTH` 個 prefix 的最佳合法 completion。Beam 前幾名再
進入 Tabu；LNS 每輪放鬆一組或兩組語義欄位，其他欄位固定。所有鄰居都來自
同一個硬合法池，不做浮點取整或事後 repair。

代理模型同時計算 Cube、MTE2、MTE1、Fixpipe/Vec、L2/HBM、ND2NZ、
active-core、尾輪與 workspace/reduction。它只用於排序，不會把 cycle estimate
冒充 NPU latency。`MODEL_RATIO_LIMIT` 是優先級，不是把其他模板全部刪除的
硬門檻。

算法與研究依據見 [docs/algorithm.md](docs/algorithm.md)。

## Baseline 與結果定義

每個支援 workload 比較三條路徑：

```text
official_operator  空的專案 bank，CANN 原始自動/內建 tiling
bank_seed_control  官方 23 欄 seed 經相同 RuntimeKb 路徑重放
searched           本搜索器選出的 23 欄候選
```

只有 searched 同時勝過 official 與 bank control，且差值超過合併量測噪聲，
才能稱為 tiling optimization。官方比較較快時，結果必須寫
`no_proven_improvement`，不能把「選回官方」稱為我們的優化。

NPU 前只能稱候選為 host-ranked；NPU 後只能稱為指定 CANN、SoC、workload
與 profiling 預算下的 best measured candidate。Beam/LNS 不是數學全空間
窮舉，因此不宣稱全域最優。

## 輸出與續跑

終端會在執行中顯示：

```text
template / T(baseMNK) / S(singleCoreMNK) / cores
output grid / L2 / L1 / DB
median ms / stddev / speedup / delta / noise / verdict
```

並留下：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv
results/npu_full_summary.csv
results/npu_full_candidates.csv
```

已由封閉 NPU 機器轉錄的結果保存在
`results/npu_full_ocr_measurements.csv`。只有 SoC、AIC、shape、dtype、
模板與完整 tiling fingerprint 全部相同才重用；已成功量測的相同候選不會
再次執行。`KEEP_DETAILS=1` 才保留 samples 與 all-evaluated 中間資料。

## Host 契約驗證

不啟動 NPU、不跑 CPU simulator：

```bash
BUILD_JOBS=1 ASCENDC_SOC_VERSION=Ascend910B3 \
SOC_VERSION=Ascend910B3 ./scripts/validate_cpu.sh
```

目前 CANN 8.1.RC1 驗證結果：

```text
一般 corpus:     45 records，全部 RuntimeKb found=1
模板 corpus:     96 records，全部 RuntimeKb found=1
searched rows:   85
kernel suffix:   12/12
template family: 7/7
正式 full corpus: 311 records，全部 RuntimeKb found=1
```

每個 searched row 都通過官方 callback 的模板、suffix、23 欄位 roundtrip。
這證明搜索與注入契約完整，不等於已證明 NPU 加速；後者必須執行 full。

NPU 計時與錯誤輸出見 [docs/npu_profiling.md](docs/npu_profiling.md)，先前
環境與執行問題見 [NPU_TILING_EXECUTION_HISTORY.txt](NPU_TILING_EXECUTION_HISTORY.txt)。

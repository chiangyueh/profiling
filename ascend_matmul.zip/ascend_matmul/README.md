# Ascend 910B MatMul Tiling Search

本工程使用 CANN 官方 `matmul_tiling::MultiCoreMatmulTiling` 產生最終 `TCubeTiling`，外部搜索器只提出離散提示：

- `baseM`
- `baseN`
- `baseK`
- M/N 遍歷順序
- L0A/L0B 雙緩衝開關
- 依 kernel 模板契約啟用的多核 Split-K 模式

搜索方法為：

```text
約束感知 Beam Search
        ↓
官方 MultiCoreMatmulTiling::GetTiling()
        ↓
TCubeTiling + MatMulV3 kernel 契約驗證
        ↓
CPU 架構代理評分
        ↓
Tabu Search + Large Neighborhood Search
        ↓
去除重複的官方 TCubeTiling
        ↓
Top-K 候選與 Tiling 二進位
        ↓
NPU ACL Event profiling + CSV
```

`singleCoreM/N/K`、實際 `baseM/N/K`、`depthA1/B1`、`stepM/N/Ka/Kb`、迭代順序、雙緩衝和核心數都由官方 API 決定，不由本工程重寫。

`baseK<K` 是一般核心內 K 軸 tiling，始終參與搜索；`singleCoreK<K` 才是跨核心
Split-K。現有跨核心直接原子模板只輸出官方允許的 FP32、NT、單輪核心映射候選。
FP16/BF16 跨核心 Split-K 需要 deterministic/workspace reduction 模板，未實作前
不會寫入 `candidates.csv`。


## 支援範圍

本版針對 **二維、稠密、ND 輸入、無 Bias 的 MatMul**，支援：

```text
FP16 / BF16 / FP32 / INT8
NN / TN / NT / TT
INT8 輸出 INT32
```

Batch MatMul、NZ 輸入、量化尺度、稀疏矩陣和 Bias 不在本版 Kernel 介面中；搜索器與官方 API 適配層可在後續按相同方式擴展。

## 目錄

```text
host/       官方 Tiling API 適配器、Beam、Tabu/LNS、CPU 代理模型
kernel/     AscendC MatMul Kernel，支援 FP16/BF16/FP32/INT8 與四種轉置
runner/     ACL Event NPU profiling Runner
cpu_smoke/  CANN tikicpulib CPU Debug smoke test
scripts/    編譯、搜索、NPU profiling、msprof
config/     工作負載 CSV
results/    執行時生成候選、TCubeTiling、NPU profiling CSV 與日誌
```

## 已驗證環境

- CANN 8.3 RC2
- x86_64 Host
- 目標架構：`dav-c220-cube`
- 官方平台配置：`Ascend910B`

目前交付環境沒有 NPU 驅動，因此已完成：

- 官方 `MultiCoreMatmulTiling::GetTiling()` 實際執行
- Host 搜索程序編譯與執行
- 16 個 AscendC Kernel 入口的 `bisheng` 編譯
- ACL NPU Runner 編譯
- CANN `tikicpulib` CPU Debug 執行 FP16 MatMul Kernel
- 28 組完整工作負載搜索與 CSV 生成

NPU Kernel 實際延遲需要在有驅動和 910B 的機器上執行。

## 一、NPU 一鍵執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
./run_npu.sh --mode full
```

所有輸出會同步寫入：

```text
results/logs/run_npu_*.log
```

此入口會優先使用官方 `/usr/local/Ascend/ascend-toolkit/set_env.sh` 初始化
CANN 環境，再從 NPU/driver 查具體 SoC 子型號，並用 ACL runtime probe 驗證
`aclInit + aclrtGetSocName` 可用。AscendC NPU build 必須拿到
`Ascend910B1/B2/B2C/B3/B4/B4-1` 這類具體型號；只拿到泛化 `Ascend910B` 或
ACL runtime 初始化失敗時會停止，不會默認改成 `Ascend910B1`。

## 二、編譯

```bash
cd ascend_matmul
./scripts/build_all.sh
```

輸出：

```text
build/matmul_tiling_search
build/npu_profile_runner
```

`npu_profile_runner` 已連結 AscendC host-stub kernel library，不再直接用
`aclrtBinaryLoadFromFile` 載入 relocatable `.o`。

## 三、執行 CANN Host 搜索

```bash
./scripts/run_search.sh config/workloads.csv
```

調整搜索規模：

```bash
BEAM_WIDTH=96 \
TABU_ITERS=96 \
LNS_ROUNDS=12 \
TOP_K=30 \
./scripts/run_search.sh config/workloads.csv
```

輸出：

```text
results/candidates.csv
results/all_evaluated.csv
results/tilings/*.bin
```

`candidates.csv` 同時記錄：

- 搜索器提示值
- 官方 API 最終值
- 完整單核形狀與 L0/L1 參數
- CPU 代理分數明細
- 對應 `TCubeTiling` 二進位路徑
- `execution_mode`、M/N/K 核心切分數與最終 shared-memory 使用量

提示值和官方值可以不同，這表示官方 API 根據硬體約束調整了候選。

## 四、單一形狀搜索

```bash
./build/matmul_tiling_search \
  --id ffn_up \
  --m 4096 --n 11008 --k 4096 \
  --dtype fp16 \
  --trans-a 0 --trans-b 0 \
  --cores 24 \
  --beam-width 64 \
  --tabu-iters 64 \
  --lns-rounds 8 \
  --top-k 20 \
  --output results/ffn_up_candidates.csv \
  --all-output results/ffn_up_all.csv \
  --tiling-dir results/ffn_up_tilings
```

## 五、CANN CPU Kernel smoke test

```bash
./scripts/run_cpu_kernel_smoke.sh
```

此測試會：

1. 調用官方 API 生成 `32×32×32` 的 `TCubeTiling`。
2. 使用 CANN `tikicpulib` 的 V220 CPU Debug 模式編譯同一份 Kernel。
3. 執行 FP16 MatMul。
4. 用零矩陣檢查輸出仍為零。

## 六、NPU profiling 與 CSV

先搜索，再執行：

```bash
RANK_LIMIT=20 \
WARMUP=10 \
REPEAT=50 \
SAMPLES=15 \
WORKSPACE_MIB=64 \
./scripts/profile_npu.sh results/candidates.csv results/npu
```

輸出：

```text
results/npu_profile.csv
results/npu_samples.csv
results/npu_ranked.csv
results/npu_best.csv
results/npu_proxy_comparison.csv
```

每個候選計時前會先核對 CSV/binary 契約，並以零 A/B、poisoned C 執行一次
首尾與核心邊界覆蓋檢查。`npu_profile.csv` 的 ACL Event 只測量後續 Kernel Launch，
不包含這個 preflight、進程啟動、Host 搜索與 H2D/D2H 時間。

一鍵完成編譯、搜索與 NPU profiling：

```bash
./scripts/run_all_npu.sh
```

## 七、針對單一候選執行 msprof

```bash
./scripts/profile_one_msprof.sh llm_full_4096_ffn_up 1 results/candidates.csv
```

參數依序為：

```text
WORKLOAD_ID  RANK  CANDIDATE_CSV  OUTPUT_DIR
```

## 八、工作負載 CSV

```csv
id,m,n,k,dtype,trans_a,trans_b,max_cores
ffn_up,4096,11008,4096,fp16,0,0,24
attention_score,1024,1024,128,fp16,0,1,24
```

支援資料型別：

```text
fp16
bf16
fp32
int8
```

INT8 輸出為 INT32。

## 九、重要限制

- CPU 代理分數用於挑選值得上 NPU 測量的候選，不代表真機全域最優。
- 最終排序以 `npu_profile.csv` 的 `median_ms` 為準。
- Kernel 目標為 V220 Cube Core；若實際 SoC 型號不是 910B/V220，需要修改編譯架構與平台字串。
- `WORKSPACE_MIB` 可依實際算子需求增大。
- `candidates.csv` 只包含目前 kernel 可執行的模式；內部被官方 API 或契約拒絕的嘗試保留在 `all_evaluated.csv` 供稽核。

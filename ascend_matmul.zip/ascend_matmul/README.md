# Ascend MatMulV3 約束式 Tiling 搜尋

本工程只研究 CANN `MatMulV3` 的 tiling。搜尋結果透過 CANN RuntimeKb
注入安裝版 `MatMulV3`，baseline 與 searched candidate 都由同一個
`aclnnMatmul`、同一套官方 kernel 執行；工程沒有自製 MatMul kernel，也不會
用 CPU 或其他算子替代失敗候選。

## 目前研究範圍

`skinny_n_large_k` 已在 910B3 真機量到 `1.52685x`，但它現在只作為已知
anchor 的回歸檢查，不能單獨構成算法成功。預設 `full` 已恢復廣泛驗證，
並把證據分為：

```text
known_anchor       已知可改善的 4096x17x16384
unseen_skinny_n    3 個未用於建立規則的 holdout
boundary_control   N=33，位於專用規則範圍外
prior_regression   6 個先前曾明顯退化的 workload
broad_validation  其餘一般形狀與模板契約 workload
unsupported_control INT8 負向對照，不計入 MatMulV3 改善率
```

先前把通用
`MultiCoreMatmulTiling` 的候選平鋪到所有 MatMulV3 BASE workload，造成大型
矩陣最高接近 `2x` 的退化；該策略已停用。一般 workload 現在只在官方
MatMulV3 seed 的 23 欄排程附近做單變因 traversal 消融。只有嚴格符合
FP16/NN、`16 < N <= 32`、`K >= 8192`、BASE 模板的 shape，才加入窄 N
專用的 core/L1/DB/L2 候選。

專案仍保留 CANN 8.1.RC1、DAV C220 的 7 個模板族、12 個 suffix 契約，供
回歸驗證使用：

| 模板族 | kernel suffix |
|---|---|
| `BASE` | `0`, `1` |
| `SINGLE_CORE_SPLIT_K` | `20`, `21` |
| `DETERMINISTIC_SPLIT_K` | `30`, `31` |
| `AL1_FULL_LOAD` | `101` |
| `BL1_FULL_LOAD` | `200`, `201` |
| `BL1_FULL_LOAD_FIXPIPE` | `10200`, `10201` |
| `BL1_FULL_LOAD_VEC_NZ2ND` | `20201` |

`0/1` 等成對 suffix 分別覆蓋 unaligned/aligned kernel。程式不生成 CANN
8.1 kernel 中不存在的 split mode 4、5、6，也不把其他 CANN 版本的模板名稱
硬套進來。

支援 FP16、BF16、FP32。INT8 保留為負向 corpus，會明確標記 unsupported；
它不屬於這條公開 `MatMulV3` 輸入路徑。

## 目前工作流

```text
偵測精確 SoC 與 AIC/L0/L1/L2
  -> 官方 MatMulV3 callback 產生精確 23 欄 seed/control
  -> 每個支援 workload 只翻轉 iterateOrder 或 l2IterateOrder
  -> 適用的窄 N workload 另建 core/L1/DB/L2 四個受控候選
  -> constraint-aware Beam 對完整合法候選排序
  -> 官方 MatMulV3 callback 回讀
  -> 要求模板族、suffix、23 個 knowledge 欄位完全一致
  -> RuntimeKb::InitBank + QueryBank(found=1)
  -> 官方 aclnnMatmul correctness preflight
  -> ACL Event latency
  -> 與空 bank 的官方自動 tiling、bank seed control 比較
```

搜尋不是「先產生大量錯誤 tiling 再碰運氣」。一般 workload 產生 2 個
官方 seed 單變因候選，窄 N 適用 workload 共產生 6 個候選；只有官方
callback 保持原模板、suffix 與全部 23 欄位的候選才會輸出給 NPU。
`official_local_v2` 不執行 Tabu/LNS，避免從局部對照再次擴張成無法解釋的
大範圍排程。

## 執行

```bash
cd ascend_matmul
./run_npu.sh --mode smoke
./run_npu.sh --mode full
```

腳本不修改 toolkit symlink、driver、firmware、shell profile 或系統
`LD_LIBRARY_PATH`。CANN 環境、`TUNE_BANK_PATH`、`ASCEND_CACHE_PATH` 只存在
於腳本子行程，暫存 bank 只建立在專案 `results/` 下。

### Smoke

Smoke 是 NPU 執行鏈快速檢查，不代表優化結果：

```text
workload       1 個 FP16 256x256x256
比較           官方自動 tiling + bank control + 1 個官方局部候選
warmup         2
repeat         5
samples        3
```

### Full

Full 是廣泛驗證，不會只執行已知成功案例：

```text
workload       40 組；39 組 MatMulV3 支援，1 組 INT8 負向對照
control        39 個官方 RuntimeKb bank seed
候選           94 個 callback-valid searched schedules
holdout        3 個未見 skinny-N 形狀，每個 6 個候選
舊退化案例     6 組，每組 2 個官方 seed 單變因候選
warmup         10
repeat         50
samples        15
```

預設輸入是 `config/workloads.csv`。已存在且完整 fingerprint 相同的真機
結果會從歷史 CSV 重用，其餘才送往 NPU。anchor 即使再次成功，也不會使
整體結論變成成功；3 個 unseen holdout 必須全部改善才標記 skinny-N
泛化成立，6 個 prior-regression 必須全部改善才標記舊退化已修復，另外
28 個一般支援 workload 也必須全部改善，才允許輸出廣域優化成立。

## 本輪搜索的欄位

一筆 MatMulV3 RuntimeKb knowledge 有 23 個欄位。一般 workload 固定官方
seed 的其餘 22 欄，每個候選只調整一項：

- `iterateOrder`: `0/1`。
- `l2IterateOrder`: `0/1`。

窄 N 專用 family 才額外比較 `baseM/singleCoreM` 的 20-core 負載平衡、
L1 depth/step、`dbL0C` 與 L2 order。已知 anchor 的最佳配置
`208x32x64` 是待跨形狀驗證的假設，不會硬套到 N=33 或其他一般矩陣。

一般 BASE 搜尋只接受一個 output task 對應一個 Cube base tile：
`singleCoreM <= baseM`、`singleCoreN <= baseN`，且兩者只能因 logical tail
小於 base。這與 CANN 8.1 `CalL1Tiling()` 將 `singleCoreM/N` 設為
`baseM/N` 的路徑及已安裝 RuntimeKb 記錄一致。可令 `singleCoreM/N` 大於
base 的排程屬於 Split-K 或 full-load 等獨立模板，不能把其語意套到一般
BASE。

`usedCoreNum` 也可以大於輸出 tile 數，多出的 core 會退出。這是合法但通常
低效，因此由 active-core 與 tail 模型懲罰，不再誤判成非法。

## 硬合法性

所有候選先檢查：

```text
baseM % 16 == 0
baseN % 16 == 0
FP32 NT: baseK % 8 == 0
其他 layout: baseK % 16 == 0

baseM * baseK * inputBytes * dbL0A <= L0A
baseN * baseK * inputBytes * dbL0B <= L0B
baseM * baseN * 4 * dbL0C         <= L0C

baseM * baseK * inputBytes * depthA1
+ baseN * baseK * inputBytes * depthB1 <= effective L1
```

另外逐模板檢查：

- BASE 的 `singleCoreK == K`、單一 output task 不跨越多個 base M/N
  tile，以及完整 M/N output grid 與 L2 schedule。
- Single-Core Split-K 的 MK33、NK33、MK24、MK14 pipeline、K loop、
  FP32 workspace/atomic accumulate 與 AIV cast。
- Deterministic Split-K 的 128x128 基本塊、MK33/NK33、
  `singleCoreK=3*baseK` 與 workspace reduction。
- AL1/BL1 full-load 的 operand 常駐條件與 L1 容量。
- Fixpipe 的 32-byte output boundary。
- Vec NZ2ND 的 FP32/layout/workspace 條件。
- aligned/unaligned logical shape 與 callback 選到的 suffix。

910B3 Platform API 回報 L1=524032 B，但官方 callback 可合法產生 524288 B
的 MatMul allocation。程式只在本身容量判斷中按 KiB allocation boundary
處理，不改任何系統設定。

## 搜尋算法

目前 `official_local_v2` 先建立完整且硬合法的局部候選，再按以下欄位層次
做 Beam：

```text
BASE + core partition + singleCoreMNK
  -> baseMNK
  -> L1 step/depth + iterateOrder
  -> L0 DB
  -> L2 schedule
```

每層只保留前 `BEAM_WIDTH` 個 prefix 的最佳合法 completion。active scope
不再執行 Tabu/LNS，代理模型也只負責局部候選排序。先前真機結果已證明模型
不能跨模板形狀可靠排序，因此不再讓它從 `176x176` 等通用 API 輸出擴張出
大型 BASE 候選。cycle estimate 不會冒充 NPU latency。

算法與研究依據見 [docs/algorithm.md](docs/algorithm.md)。

## Baseline 與結果定義

每個支援 workload 比較三條路徑：

```text
official_operator  空的專案 bank，CANN 原始自動/內建 tiling
bank_seed_control  官方 23 欄 seed 經相同 RuntimeKb 路徑重放
searched           本搜索器選出的 23 欄候選
```

只有 searched 勝過同一 RuntimeKb 路徑的 bank control，並同時列出相對
official 的結果，且差值超過合併量測噪聲，
才能稱為 tiling optimization。官方比較較快時，結果必須寫
`no_proven_improvement`，不能把「選回官方」稱為我們的優化。

NPU 前只能稱候選為 host-ranked；NPU 後只能稱為指定 CANN、SoC、workload
與 profiling 預算下的 best measured candidate。Beam/LNS 不是數學全空間
窮舉，因此不宣稱全域最優。

## 輸出與續跑

終端會在執行中顯示：

```text
template / T(baseMNK) / S(singleCoreMNK) / cores
output grid / L2 / L1 / DB
median ms / stddev / speedup / delta / noise / verdict
```

並留下：

```text
results/npu_smoke_summary.csv
results/npu_smoke_candidates.csv
results/npu_full_summary.csv
results/npu_full_candidates.csv
```

已由封閉 NPU 機器轉錄的結果保存在
`results/npu_full_ocr_measurements.csv`。官方 baseline 可按 SoC、AIC、
shape 與 dtype 重用。候選只有在保存完整排程且標記
`preflight_contract=grid9_v1` 時才能重用；舊 OCR 候選缺少完整 23 欄排程，
而且只通過舊 5 點 coverage check，因此只保留為研究紀錄，不會冒充精確的
有效候選。`KEEP_DETAILS=1` 才保留 samples 與 all-evaluated 中間資料。

## Host 契約驗證

不啟動 NPU、不跑 CPU simulator：

```bash
BUILD_JOBS=1 ASCENDC_SOC_VERSION=Ascend910B3 \
SOC_VERSION=Ascend910B3 ./scripts/validate_cpu.sh
```

目前 `official_local_v2`、CANN 8.1.RC1 的 host 驗證結果：

```text
workloads:                 40
bank controls:             39
searched rows:             94
callback valid:            94/94
RuntimeKb newly queried:   130/130 found
exact history reuse:       3
unseen skinny-N holdouts:  3 x 6 candidates
prior-regression cases:    6 x 2 candidates
```

每個 searched row 都通過官方 callback 的模板、suffix、23 欄位 roundtrip；
新記錄也通過 RuntimeKb lookup。
這證明搜索與注入契約完整，不等於已證明 NPU 加速；後者必須執行 full。

NPU 計時與錯誤輸出見 [docs/npu_profiling.md](docs/npu_profiling.md)，先前
環境與執行問題見 [NPU_TILING_EXECUTION_HISTORY.txt](NPU_TILING_EXECUTION_HISTORY.txt)。

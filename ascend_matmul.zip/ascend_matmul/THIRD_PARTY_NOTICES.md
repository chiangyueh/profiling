# Third-Party Notices

`compat/` 內的相容頭文件保留原始 Huawei CANN Open Software 版權與授權聲明。
其用途僅是補足 CANN 8.3 RC2 此安裝包中 Host Tiling 頭文件的相依項，使本工程能直接編譯。
其餘 `host/`、`kernel/`、`runner/`、`cpu_smoke/`、`scripts/` 與 `tools/` 為本工程實作。

`kernel/matmul_search_kernel.cpp` 的 FP32 NT direct multi-core Split-K 分支依照
CANN `ops-nn/matmul/mat_mul_v3` 公開的 `mat_mul_multi_core_splitk_kernel.h`
執行契約與核心映射實作；一般 base 分支的 M/N 分核、tail shape 與 ND GM
offset 則依照公開的 `mat_mul_base_block.h` 和 `mat_mul_base_kernel.h`。適用
CANN Open Software License Agreement Version 2.0：

https://gitcode.com/cann/ops-nn/tree/8.5.0/matmul/mat_mul_v3

#include "kernel_operator.h"
#include "tikicpulib.h"
#include <acl/acl_base.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#ifndef MATMUL_CPU_TRANS_A
#define MATMUL_CPU_TRANS_A 0
#endif
#ifndef MATMUL_CPU_TRANS_B
#define MATMUL_CPU_TRANS_B 0
#endif
#ifndef MATMUL_CPU_FP32
#define MATMUL_CPU_FP32 0
#endif

extern "C" void matmul_search_test(
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, GM_ADDR tiling);

namespace {

constexpr bool kTransA = MATMUL_CPU_TRANS_A != 0;
constexpr bool kTransB = MATMUL_CPU_TRANS_B != 0;
constexpr bool kFp32 = MATMUL_CPU_FP32 != 0;

std::vector<uint8_t> ReadBinary(const std::string &path)
{
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    if (!input) throw std::runtime_error("cannot open " + path);
    const std::streamsize size = input.tellg();
    if (size <= 0) throw std::runtime_error("empty binary " + path);
    input.seekg(0, std::ios::beg);
    std::vector<uint8_t> data(static_cast<size_t>(size));
    if (!input.read(reinterpret_cast<char *>(data.data()), size)) {
        throw std::runtime_error("cannot read " + path);
    }
    return data;
}

size_t AIndex(int32_t mIndex, int32_t kIndex, int32_t m, int32_t k)
{
    return kTransA ? static_cast<size_t>(kIndex) * m + mIndex
                   : static_cast<size_t>(mIndex) * k + kIndex;
}

size_t BIndex(int32_t kIndex, int32_t nIndex, int32_t n, int32_t k)
{
    return kTransB ? static_cast<size_t>(nIndex) * k + kIndex
                   : static_cast<size_t>(kIndex) * n + nIndex;
}

float StoreInput(uint8_t *buffer, size_t index, float value)
{
    if constexpr (kFp32) {
        reinterpret_cast<float *>(buffer)[index] = value;
        return value;
    } else {
        const aclFloat16 encoded = aclFloatToFloat16(value);
        reinterpret_cast<aclFloat16 *>(buffer)[index] = encoded;
        return aclFloat16ToFloat(encoded);
    }
}

float LoadOutput(const uint8_t *buffer, size_t index)
{
    if constexpr (kFp32) {
        return reinterpret_cast<const float *>(buffer)[index];
    } else {
        return aclFloat16ToFloat(reinterpret_cast<const aclFloat16 *>(buffer)[index]);
    }
}

float QuantizeExpected(float value)
{
    if constexpr (kFp32) {
        return value;
    } else {
        return aclFloat16ToFloat(aclFloatToFloat16(value));
    }
}

}  // namespace

int main(int argc, char **argv)
{
    try {
        if (argc != 6) {
            std::cerr << "usage: matmul_cpu_smoke TILING_BIN BLOCK_DIM M N K\n";
            return 2;
        }
        constexpr size_t elementBytes = kFp32 ? sizeof(float) : sizeof(uint16_t);
        const uint32_t blockDim = static_cast<uint32_t>(std::stoul(argv[2]));
        const int32_t m = std::stoi(argv[3]);
        const int32_t n = std::stoi(argv[4]);
        const int32_t k = std::stoi(argv[5]);
        if (blockDim <= 1 || m <= 0 || n <= 0 || k <= 0) {
            throw std::runtime_error("multi-core smoke requires blockDim > 1 and positive M/N/K");
        }
        const auto tilingHost = ReadBinary(argv[1]);

        const size_t aBytes = static_cast<size_t>(m) * k * elementBytes;
        const size_t bBytes = static_cast<size_t>(k) * n * elementBytes;
        const size_t cBytes = static_cast<size_t>(m) * n * elementBytes;
        const size_t workspaceBytes = 2 * 1024 * 1024;

        auto *a = static_cast<uint8_t *>(AscendC::GmAlloc(aBytes));
        auto *b = static_cast<uint8_t *>(AscendC::GmAlloc(bBytes));
        auto *c = static_cast<uint8_t *>(AscendC::GmAlloc(cBytes));
        auto *workspace = static_cast<uint8_t *>(AscendC::GmAlloc(workspaceBytes));
        auto *tiling = static_cast<uint8_t *>(AscendC::GmAlloc(tilingHost.size()));
        if (!a || !b || !c || !workspace || !tiling) {
            throw std::runtime_error("GmAlloc failed");
        }
        std::vector<float> logicalA(static_cast<size_t>(m) * k);
        std::vector<float> logicalB(static_cast<size_t>(k) * n);
        for (int32_t i = 0; i < m; ++i) {
            for (int32_t p = 0; p < k; ++p) {
                const float value = static_cast<float>((i % 7) - 3) * 0.125F +
                                    static_cast<float>((p % 5) - 2) * 0.0625F;
                logicalA[static_cast<size_t>(i) * k + p] =
                    StoreInput(a, AIndex(i, p, m, k), value);
            }
        }
        for (int32_t p = 0; p < k; ++p) {
            for (int32_t j = 0; j < n; ++j) {
                const float value = static_cast<float>((p % 7) - 3) * 0.0625F +
                                    static_cast<float>((j % 5) - 2) * 0.125F;
                logicalB[static_cast<size_t>(p) * n + j] =
                    StoreInput(b, BIndex(p, j, n, k), value);
            }
        }
        std::memset(c, 0x5a, cBytes);
        std::memset(workspace, 0, workspaceBytes);
        std::memcpy(tiling, tilingHost.data(), tilingHost.size());

        ICPU_RUN_KF(matmul_search_test, blockDim, a, b, c, workspace, tiling);

        bool correct = true;
        for (int32_t i = 0; i < m && correct; ++i) {
            for (int32_t j = 0; j < n; ++j) {
                float expected = 0.0F;
                for (int32_t p = 0; p < k; ++p) {
                    expected += logicalA[static_cast<size_t>(i) * k + p] *
                                logicalB[static_cast<size_t>(p) * n + j];
                }
                const float expectedOutput = QuantizeExpected(expected);
                const float actual = LoadOutput(c, static_cast<size_t>(i) * n + j);
                const float tolerance = kFp32 ? std::max(0.001F, std::abs(expectedOutput) * 0.0001F)
                                              : std::max(0.03F, std::abs(expectedOutput) * 0.005F);
                if (!std::isfinite(actual) || std::abs(actual - expectedOutput) > tolerance) {
                    correct = false;
                    std::cerr << "mismatch at C[" << i << ',' << j << "] actual=" << actual
                              << " expected=" << expectedOutput
                              << " tolerance=" << tolerance << '\n';
                    break;
                }
            }
        }

        AscendC::GmFree(a);
        AscendC::GmFree(b);
        AscendC::GmFree(c);
        AscendC::GmFree(workspace);
        AscendC::GmFree(tiling);

        if (!correct) return 1;
        std::cout << "CANN CPU kernel smoke passed: M=" << m << " N=" << n << " K=" << k
                  << " dtype=" << (kFp32 ? "fp32" : "fp16")
                  << " transA=" << kTransA << " transB=" << kTransB
                  << " blockDim=" << blockDim << '\n';
        return 0;
    } catch (const std::exception &ex) {
        std::cerr << "fatal: " << ex.what() << '\n';
        return 1;
    }
}

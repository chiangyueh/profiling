# MatMulV3 全模板 Tiling 搜尋算法

## 1. 問題定義

本專案要解的是：

> 在指定 CANN 8.1.RC1、Ascend910B3、合法 MatMulV3 kernel 模板集合與
> NPU profiling 預算下，找出相對官方自動 tiling 有統計顯著加速的 tiling。

這不是把任意 23 個整數寫入 RuntimeKb，再把崩潰與超時稱為搜索。候選先由
kernel 契約構造，再依序通過官方 callback、RuntimeKb 與 NPU correctness
preflight。

同樣也不能只靠 host 成本模型宣稱最優。最終結論只能是：

```text
指定 CANN + SoC + workload + 搜尋預算下，
已通過 correctness 的實測候選中 latency 最低者。
```

## 2. CANN 8.1 的完整 kernel 空間

安裝版來源：

```text
$CANN_ROOT/opp/built-in/op_impl/ai_core/tbe/impl/ascendc/
  mat_mul_v3/mat_mul_v3.cpp
```

DAV C220 分支有 12 個實際 dispatch key：

| suffix | variant | family |
|---:|---|---|
| 0 | BASE_UNALIGNED | BASE |
| 1 | BASE_ALIGNED | BASE |
| 20 | SINGLE_CORE_SPLIT_K_UNALIGNED | SINGLE_CORE_SPLIT_K |
| 21 | SINGLE_CORE_SPLIT_K_ALIGNED | SINGLE_CORE_SPLIT_K |
| 30 | DETERMINISTIC_SPLIT_K_UNALIGNED | DETERMINISTIC_SPLIT_K |
| 31 | DETERMINISTIC_SPLIT_K_ALIGNED | DETERMINISTIC_SPLIT_K |
| 101 | AL1_FULL_LOAD_ALIGNED | AL1_FULL_LOAD |
| 200 | BL1_FULL_LOAD_UNALIGNED | BL1_FULL_LOAD |
| 201 | BL1_FULL_LOAD_ALIGNED | BL1_FULL_LOAD |
| 10200 | BL1_FULL_LOAD_FIXPIPE_UNALIGNED | BL1_FULL_LOAD_FIXPIPE |
| 10201 | BL1_FULL_LOAD_FIXPIPE_ALIGNED | BL1_FULL_LOAD_FIXPIPE |
| 20201 | BL1_FULL_LOAD_VEC_NZ2ND | BL1_FULL_LOAD_VEC_NZ2ND |

Runtime bank 的 `tilingEnable` 由 suffix 解碼：

```text
split = suffix / 10    % 10
full  = suffix / 100   % 10
fix   = suffix / 10000 % 10

tilingEnable = split + 10*full + 1000*fix
```

這個版本沒有 suffix 40，也沒有可直接注入的 split mode 4。舊版程式曾建立
一條 FP32 NT mode-4 路徑；它不對應 CANN 8.1 的 kernel dispatch，已完全移除。

## 3. 23 維離散表示

RuntimeKb knowledge record 是：

```text
usedCoreNum
singleCoreM/N/K
baseM/N/K
depthA1/B1
stepM/N
iterateOrder
stepKa/Kb
dbL0A/B/C
l2MTileCnt/NTileCnt
l2MTileBlock/NTileBlock
l2IterateOrder
tilingEnable
```

欄位不是獨立變數。例如：

```text
L0A = baseM * baseK * inputBytes * dbL0A
L0B = baseN * baseK * inputBytes * dbL0B
L0C = baseM * baseN * 4          * dbL0C

A1 = baseM * baseK * inputBytes * depthA1
B1 = baseN * baseK * inputBytes * depthB1

depthA1 % (stepM * stepKa) == 0
depthB1 % (stepN * stepKb) == 0
```

因此普通 GA 的逐基因 crossover、普通 PSO 的連續座標取整都會產生大量沒有
模板語義的點。它們可以在特製 constraint-preserving encoding 下作為基線，
但不是本空間的首選。

## 4. 模板硬約束

### 4.1 共通容量與對齊

```text
baseM % 16 == 0
baseN % 16 == 0
```

FP32 `transA=false, transB=true` 可使用 K0=8；其他 dtype/layout 使用 K0=16。
L0A、L0B、L0C 分別使用自己的 DB，不能以單一 DB 值代替。

910B3 Platform API 回報 L1=524032 B，但官方 callback 會產生合法的
524288 B A1+B1 配置。程式以 MatMul allocator 的 KiB 邊界得到 effective
L1=524288 B；這只是候選檢查，不修改 CANN 或系統記憶體。

### 4.2 BASE

BASE 的 `singleCoreK` 覆蓋完整 K。`singleCoreM/N` 是一個 AIC 的輸出
partition，`baseM/N/K` 是該 AIC 內部 Matmul API 的 Cube blocking。

重要修正：

```text
singleCoreM/N 不需要等於 baseM/N
```

`mat_mul_base_block.h` 先以 `singleCoreM/N` 計算 M/N output grid 與 core
round，再由 `mat_mul_base_kernel.h` 的 Matmul API 在 partition 內迭代
base tile。舊版錯誤地令 `S=T`，導致 4096/8192 等大矩陣產生數千個很小的
output tile、L2 schedule 被切碎，這是舊候選普遍慢於官方的主要原因。

`usedCoreNum` 可以大於 output tile 數；多出的 AIC 退出。它是合法配置，但
成本模型只把實際工作的 core 計為 active core。

### 4.3 Single-Core Split-K

CANN 8.1 suffix 20/21 使用 `mat_mul_sc_splitk_kernel.h`。每個 output-owning
AIC 依序跑多個 K slice；後續 slice 對 FP32 workspace 做 atomic accumulate，
AIV 最後轉回輸出 dtype。

候選構造涵蓋來源中可接受的四種 pipeline：

```text
MK33  stepM=3 stepN=1 stepK=3 depthA/B=9/6
NK33  stepM=1 stepN=3 stepK=3 depthA/B=6/9
MK24  stepM=2 stepN=1 stepK=4 depthA/B=8/8
MK14  stepM=1 stepN=1 stepK=4 depthA/B=8/8
```

並要求：

```text
baseM=baseN=128
baseK=256/inputBytes
singleCoreK=stepK*baseK < K
stepKa=stepKb
K slice count >= 2
```

四種 pipeline 已分別以官方 callback 驗證 suffix 21 與 23 欄 roundtrip。
unaligned workload 另外驗證 suffix 20。

### 4.4 Deterministic Split-K

suffix 30/31 沿 K 把 partial C 寫入 FP32 workspace，再由 AIV 做固定順序
reduction/cast。候選要求：

```text
baseM=baseN=128
baseK=256/inputBytes
singleCoreK=3*baseK
MK33 或 NK33
usedCoreNum <= ceil(K/singleCoreK)
```

它適合 M/N 很小而 K 很大、BASE 無法使用足夠 AIC 的形狀。模型另計 partial
workspace、reduction bytes 與 AIV 工作，不把它當成 BASE。

### 4.5 AL1 Full Load

suffix 101 將完整 A 常駐每個 active AIC 的 L1，再重用於多個 N partition。
目前 CANN 8.1 可構造域為 FP32 NT、小 M、N 不超過 AIC 可分範圍、K 至少
4096 且滿足 full-load 對齊。候選同步搜索 `baseN/baseK`、N partition、
B1 depth 與 C DB。

### 4.6 BL1 Full Load

suffix 200/201 將完整 B 常駐 L1，適合 M 遠大於 K/N 且 B 可放入 L1 的形狀。
候選搜索：

```text
baseM/N/K
singleCoreM
A1 buffer count
dbL0C
aligned/unaligned callback branch
```

### 4.7 Fixpipe 與 Vec NZ2ND

suffix 10200/10201 處理普通 Fixpipe 無法直接覆蓋的短 N output boundary；
邊界依實際輸出 32-byte transaction 判斷，不是舊版錯用的 256-byte條件。

suffix 20201 使用 AIV 做 NZ2ND，並有額外 A/workspace movement。這兩類模板
的 `l2MTileBlock/l2NTileBlock=0` 是 kernel 契約的一部分，不能套用 BASE
「block 必須大於零」的規則。

## 5. 候選構造

搜索器先取得兩個 seed：

```text
default seed  不注入 runtime bank 的官方 callback 結果
bank seed     同一 23 欄經 RuntimeKb 路徑重放後的 callback 結果
```

BASE 另外使用 `MultiCoreMatmulTiling` 的輸出作為中心。七個模板族再按上述
契約建立有限離散池。候選池不是所有正整數的笛卡兒積，而是：

- Cube K0、L0/L1 allocation unit 對齊值。
- 接近官方 seed 的 base 值。
- 能形成 1 至數個完整 AIC round 的 M/N partition。
- kernel 來源定義的 Split-K pipeline。
- full-load operand 確實能常駐 L1 的值。
- 完整覆蓋 output grid 的 L2 schedule。

每個進入搜索的 state 已是完整且 hard-legal 的候選，沒有「搜尋後 repair」。

## 6. Constraint-Aware Beam Search

完整 state 按依賴分成五層 prefix：

```text
1. template + usedCore + singleCoreMNK
2. baseMNK
3. step/depth + iterateOrder
4. L0 DB
5. L2 schedule
```

對每個 prefix，程式取其所有合法 completion 中模型分數最低者作代表，每層
只保留前 `BEAM_WIDTH` 個 prefix。模板各自擁有 beam，避免數量大的 BASE
空間擠掉 Split-K/full-load。

這一做法採用 ROLLER 的 construction-based、hardware-aligned tile 思路：
先以執行單元、transaction 與 memory capacity 限定 shape，再做搜索，而不是
對完整整數空間盲抽樣。

## 7. Tabu 與 Large Neighborhood Search

Beam 前四個 seed 分別做離散鄰域搜索。語義欄位分成：

```text
core/singleCore
base/L1/DB
iterateOrder
L2 schedule
```

Tabu move 只改一組，32-entry tabu queue 防止反覆往返。LNS 每輪放鬆一組或
兩組，其餘組固定，可跨過單步鄰域的局部障礙。所有 move 都從已建立的
hard-legal pool 中取值。

這與 Ansor 的 hierarchical representation + fine-tuning 精神相同，但此處
不是生成任意程式，而是在 CANN 已編譯好的 MatMulV3 模板內搜索 23 欄
schedule。由於目前 NPU 資料不足，沒有假裝使用已訓練好的 learned model。

## 8. 模板感知代理模型

模型不配置大矩陣、不跑 CPU simulator，使用 closed-form axis sum，因此不會
因 8192/65536 形狀建立數百萬 tile 物件。

### 8.1 Active core 與尾輪

```text
logicalTiles = output partitions 或 split-K partitions
activeCores  = min(usedCoreNum, logicalTiles)
roundBalance = ceil(logicalTiles/activeCores)
               / (logicalTiles/activeCores)
critical(stage) = total(stage)/activeCores * roundBalance
```

HBM/L2 bandwidth 分母也使用 active core，不會讓空閒 core 虛構額外帶寬。

### 8.2 Pipeline stages

模型分別估算：

- Cube：M0=N0=16、dtype K0、base subtile 與 fill/drain。
- MTE2：L2->L1 bytes、L1 reuse window 與 transaction startup。
- MTE1：L1->L0 bytes、base subtile 數與 startup。
- Fixpipe：輸出 transaction、tail 與 `dbL0C` overlap。
- L2/HBM：operand 重讀、L2 tile 工作集與尾 tile parallelism。
- ND2NZ：callback blob 的 `baseAN/baseAD/baseBN/baseBD`。
- Split-K：workspace、atomic/reduction、AIV cast。
- AL1/BL1：完整 operand 每 active AIC 載入一次的 reuse。
- Vec NZ2ND：額外 workspace 與 vector movement。

輸入與 Cube 在雙緩衝時以 overlap critical path 建模；未雙緩衝時相加。
模型 cycle 只在同一 workload 內排序，不轉成虛假的毫秒。

### 8.3 模型可信度

現有 OCR 歷史資料共 63 筆，但只約 28 筆能以較粗 fingerprint 對上新空間；
log-latency Pearson 約 0.14，中位絕對百分比誤差約 8.9%。這說明舊代理模型
不足以證明最佳值。

所以目前策略是：

1. 用模型大幅減少 NPU 候選。
2. 每個適用模板至少保留一個 leader，避免模型偏差刪掉整個 family。
3. `MODEL_RATIO_LIMIT` 只決定優先順序，不是合法性或硬淘汰條件。
4. 最終只相信 correctness 後的 NPU latency。

當累積足夠 exact fingerprint 資料後，才適合加入 AutoTVM/Ansor 類 learned
cost model 或 TPE/SMAC 來選下一批真機候選。

## 9. 三層合法性證據

每個輸出到 NPU 的 searched candidate 必須通過：

### 層 1：硬約束

對齊、L0/L1、DB、step/depth、partition、L2 coverage 與各模板契約。

### 層 2：官方 callback

以 23 欄 knowledge 呼叫安裝版 MatMulV3 callback，要求：

```text
callback family == requested family
callback suffix 屬於 CANN 8.1 的 12 個 dispatch
callback 回傳的 23 欄 == 候選 23 欄
```

並保存完整 blob、tiling key、block dim、workspace 與 SHA-256。callback
在 bank lookup 後仍會產生 ND2NZ metadata，因此不能只保存 23 欄。

### 層 3：RuntimeKb 與 NPU

每筆候選建立獨立 runtime bank，`RuntimeKb::QueryBank` 必須 `found=1`。
這只證明 schema/hash/query 成立。真正可執行性由官方 `aclnnMatmul` 的輸出
coverage/numeric preflight 證明，通過後才允許 ACL Event 計時。

## 10. Baseline、歷史資料與決策

每個 workload 都有：

```text
official_operator
bank_seed_control
searched Top-K
```

bank control 用來隔離 RuntimeKb 路徑本身造成的 ND2NZ metadata 差異。只有
searched 同時顯著勝過兩個 reference 才標記 `improved`。

`results/npu_full_ocr_measurements.csv` 以以下 exact fingerprint 重用：

```text
SoC + AIC + workload + shape + dtype + transpose
+ family + baseMNK + singleCoreMNK + cores
+ L1/DB + output grid + L2 schedule
```

相同成功候選不重測。不同任何一個排程欄位都視為新候選，不能把舊時間複製
過去。bank seed control 每次在目前 CANN 重測。

## 11. 已完成驗證

`scripts/validate_cpu.sh` 不啟動 NPU或 simulator。CANN 8.1.RC1、
Ascend910B3 contract validation 結果：

```text
unit tests                         passed
一般 corpus RuntimeKb records      45/45 found
全模板 RuntimeKb records           96/96 found
全模板 searched candidates         85
kernel suffix                      12/12
template family                    7/7
callback 23-field roundtrip         all passed
正式 full corpus RuntimeKb records  311/311 found
```

這證明現在不是 BASE-only smoke，也不是只列出模板名字。正式 full corpus
另外包含對應 12 suffix 的 NPU workload；NPU 加速結果仍須由遠端 full
實測取得。

## 12. 研究依據

- 安裝版 CANN 8.1 `mat_mul_v3.cpp` 與同目錄 kernel headers：本版本實際
  dispatch、core mapping、Split-K、full-load、Fixpipe/Vec 的首要證據。
- [Ascend C MultiCoreMatmulTiling 使用說明](https://www.hiascend.com/document/detail/zh/canncommercial/700/operatordev/Ascendcopdevg/atlasascendc_api_07_0220.html)
- [Ascend C Matmul tiling API](https://www.hiascend.com/document/detail/en/canncommercial/850/API/ascendcopapi/atlasascendc_api_07_0671.html)
- [ROLLER: Fast and Efficient Tensor Compilation](https://www.usenix.org/conference/osdi22/presentation/zhu)
- [Ansor: Generating High-Performance Tensor Programs](https://www.usenix.org/system/files/osdi20-zheng.pdf)
- [Learning to Optimize Tensor Programs / AutoTVM](https://papers.nips.cc/paper/2018/file/8b5700012be65c9da25f49408d959ca0-Paper.pdf)
- `DaVinci_AIC_V220_ISA_User_Guide2-910B.pdf`：Cube/MTE/Vector/Fixpipe
  pipeline 與記憶體層級參照。
- 使用者提供的 `MultiCoreMatmulTiling.cpp`：API 行為旁證；若來源是反組譯
  或重建檔，不把它宣稱為華為官方原始碼。

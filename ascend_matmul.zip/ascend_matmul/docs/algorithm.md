# MatMulV3 Tiling 搜尋算法與證據

## 1. 目標

本專案解的不是「隨機產生 tiling 再看哪些不會壞」，而是：

> 在指定 CANN、SoC、MatMulV3 模板集合與 NPU 量測預算下，從符合
> kernel 契約的離散 tiling 中，找出相對於官方 operator 有統計顯著加速的
> tiling。

官方 operator 是 baseline，不是搜尋結果，也不是所謂 fallback optimization。
若 searched tiling 沒有超過噪聲門檻，結論只能是
`no_searched_tiling_beats_official_beyond_noise`。

目前實作的有效範圍為：

- CANN 8.1.RC1 的 `MatMulV3`
- Ascend910B3，執行期可用 20 個 AIC
- FP16、BF16、FP32
- BASE、CANN 已產生的 deterministic Split-K，以及 CANN 版本實際接受的
  direct Split-K

INT8 不屬於這條 MatMulV3 模板路徑，不會拿其他 operator 假裝是同一個搜尋。

## 2. 證據層級

合法性與模型依據依下列優先順序使用：

1. 目標機上 CANN 8.1 的 MatMulV3 callback、RuntimeKb 與 NPU preflight。
2. CANN 公開的 MatMulV3 8.5 源碼及官方 Ascend C API 文件。
3. `DaVinci_AIC_V220_ISA_User_Guide2-910B.pdf` 與 CCE Intrinsic 文件。
4. NPUMeter、ROLLER 與 DaVinci 離散事件模型等公開研究。
5. `/usr/local/Ascend/MultiCoreMatmulTiling.cpp` 僅作為從符號、header 與
   disassembly 重建的旁證，不宣稱它是華為原始碼。

任何代理模型都不能取代 NPU correctness preflight。相反地，`bank found=1`
也不能取代完整 tiling 與 kernel 契約驗證。

## 3. 搜尋空間

一筆 RuntimeKb knowledge record 包含 23 個離散欄位：

```text
usedCoreNum
singleCoreM/N/K
baseM/N/K
depthA1/B1
stepM/N
iterateOrder
stepKa/Kb
dbL0A/B/C
l2MTileCnt/NTileCnt
l2MTileBlock/NTileBlock
l2IterateOrder
tilingEnable
```

搜索器不直接任意拼出這 23 個值。`baseMNK`、L1 step/depth、DB 與
single-core shape 的初始組合必須先由官方
`MultiCoreMatmulTiling` 產生，再進入 MatMulV3 callback。

### 3.1 Cube 對齊

- `baseM`、`baseN` 必須為 16 的倍數。
- FP32 且 `transA=false, transB=true` 時，`baseK` 可按 C0=8 對齊。
- 其他 layout 的 `baseK` 必須按 16 對齊。

早期版本把所有 FP32 都按 8 對齊，會產生 callback 或 kernel 不接受的候選，
目前已修正。

### 3.2 L0/L1 容量

以輸入元素大小 `s`、累加器 4 B 計：

```text
L0A = baseM * baseK * s * effectiveDbA
L0B = baseN * baseK * s * effectiveDbB
L0C = baseM * baseN * 4 * dbL0C

A1 = baseM * baseK * s * depthA1
B1 = baseN * baseK * s * depthB1
A1 + B1 <= L1
```

`depthA1` 必須是 `stepM*stepKa` 的整數倍，`depthB1` 同理。官方合法
`K=11008` seed 證明，不能要求 `ceil(K/(baseK*stepKa))` 與
`ceil(K/(baseK*stepKb))` 互相整除，因為兩邊都允許最後一輪 tail；可驗證的
關係是 `stepKa` 與 `stepKb` 本身存在整數倍關係。

910B3 的 Platform API 回報 L1=524032 B，但官方 seed 可合法使用
524288 B 的 MatMul allocation boundary。因此 bank 靜態檢查按 512 B
配置單位向上對齊，不修改系統或 CANN 設定。

### 3.3 模板契約

- BASE：`singleCoreM=baseM`、`singleCoreN=baseN`、single core 覆蓋完整 K。
- deterministic Split-K：保留公開源碼定義的 MK33/NK33、128x128 基本塊、
  `singleCoreK=3*baseK` 及 workspace reduction 契約。
- direct multi-core Split-K：只在該 CANN callback 真正保留
  `tilingEnable` 且 dtype/layout 合法時使用。
- AL1/BL1 full-load：目前只允許官方 seed control；在沒有完成對應模板的
  constraint-preserving neighborhood 前，不把 BASE 欄位套上 full-load key。

## 4. 完整合法性管線

每個候選依序通過：

1. 對齊、正值、核心數、L0/L1、step/depth 與 L2 覆蓋靜態檢查。
2. 官方 `MultiCoreMatmulTiling` 產生可行 TCubeTiling。
3. 23 欄 knowledge 注入 MatMulV3 RuntimeKb。
4. `RuntimeKb::QueryBank` 必須回覆 `found=1`。
5. 再呼叫官方 MatMulV3 callback，23 欄必須逐欄保持一致。
6. 保存 callback 回傳的完整 tiling blob、tiling key、block dim、workspace
   與 SHA-256。
7. NPU 上執行輸出 coverage/numeric preflight，最後才允許計時。

### 4.1 為什麼要保存完整 blob

MatMulV3 callback 在 bank lookup 後還會計算 ND->NZ vector tiling。
公開源碼顯示預設路徑先填 `runInfo_`，而 bank
`TranslateAoeTiling()` 只複製 23 欄，再呼叫 ND->NZ tiling。

實測 host callback：

```text
skinny_n_large_k default baseBD=410
skinny_n_large_k bank    baseBD=1366
```

23 欄、tiling key、block dim 與 workspace 都相同，但完整 blob 不同。
odd-tail shape 也會改變 `baseAD/baseBN/baseBD`。因此每個 workload 額外加入
`bank_seed_control`：

```text
official operator (empty bank)
official 23-field seed through RuntimeKb
searched candidate through RuntimeKb
```

只有如此才能判斷加速來自 searched `baseMNK/L1/L2`，還是 bank 路徑本身的
ND->NZ 差異。control 不算 searched tiling。

## 5. Constraint-aware Beam Search

變數按依賴順序展開：

```text
kernel template / core partition
  -> baseK
  -> baseM
  -> baseN
  -> traverse / DB
  -> L1 fields returned by official API
  -> L2 schedule
```

先擴 K 的原因是 L0A/L0B 容量與 K pipeline 深度直接耦合；之後才以 M/N
交換 L0C reuse、tail 與核心負載。每層立即刪除違反硬限制的 partial state，
並對不同 kernel template 保留獨立 beam，避免 BASE 候選把 Split-K 模板全部
擠掉。

這比普通 GA/PSO 更適合目前空間：

- 欄位是離散、條件式且強耦合。
- 普通交叉容易破壞 L0/L1/模板契約。
- 連續 PSO 取整後會集中到重複或非法點。
- Beam 的每個剪枝理由、seed 與輸出可重現。

## 6. Tabu 與 Large Neighborhood Search

Beam 的合法結果再做：

- `baseM/N/K` 相鄰合法值移動。
- DB 與遍歷順序切換。
- 固定 M/N 重搜 K/DB。
- 固定 K 重搜 M/N。
- 固定大部分欄位，重搜 core partition。

Tabu queue 防止相鄰 tiling 往返；LNS 則跨越單步鄰域。所有鄰居仍須重新呼叫
官方 tiling API，不存在「修一修就當合法」的路徑。

## 7. 20-AIC 負載平衡

公開 MatMulV3 的 `OptimizeLoadBalanceBasicKernel()` 只在
`aicNum == 24` 啟用。目標 910B3 對此 operator 回報 20 AIC，因此搜索器不
硬編碼 24，而為每個輸出 grid 保留接近下列 slot 的候選：

```text
rounds * runtimeAic, rounds = 1..8
```

例如 `M=4096, N=17`：

```text
baseM=208 -> ceil(4096/208)=20 blocks
```

先前 NPU 數據中它相對官方 operator 為 1.494x，但該 workload 的
`baseBD` 在 bank 路徑同時改變。因此下一輪必須用 bank seed control 分離
20-core balance 與 ND->NZ 兩個效應，不能直接把 1.494x 全歸功於 baseM。

## 8. 模板感知分析模型

模型不配置矩陣，也不執行 CPU simulator。對每個候選以 full/tail
closed-form axis sum 計算，複雜度為 O(1)，不隨 tile 數建立座標陣列。

### 8.1 Critical core

```text
logicalTiles = mTiles * nTiles * kTiles
activeCores  = min(usedCoreNum, logicalTiles)
roundBalance = ceil(logicalTiles/activeCores)
               / (logicalTiles/activeCores)
critical(stage) = total(stage)/activeCores * roundBalance
```

這同時捕捉 idle core、最後一輪不足及 full/tail padding。

### 8.2 Cube

依 NPUMeter 的 block initiation 模型：

```text
Ltile = Lblock + IIblock * (blockCount - 1)
```

本實作以 M0=N0=16、FP16/BF16 K0=16、FP32 native K0=8 計算 MMAD block
數，並對每個獨立 output subtile加入 fill/drain。模型只比較同 workload
候選的 cycle ratio，不把估算 cycle 偽裝成實測毫秒。

### 8.3 MTE2、MTE1 與 L1 reuse

- MTE2 同時計算 bytes 與 transaction 數；skinny/large-K 不能只看總 bytes。
- `stepKa/stepKb` 決定一個 L1 packet 可覆蓋多少 K。
- `depthA1/B1` 與 DB 決定可否讓 MTE2/MTE1 與 Cube overlap。
- MTE1 以 L1->L0 bytes、base subtile 數及 transaction startup 建模。

### 8.4 FixPipe

輸出 row 按 512 B packet 對齊，模型加入 tail packet 與
`dbL0C` overlap。這是為什麼面積相近的 `144x224` 與 `128x256` 不應只按
FLOP 數視為相同。

### 8.5 L2/HBM

```text
HBM_A = M*K*sizeof(A) * l2NTileCnt
HBM_B = K*N*sizeof(B) * l2MTileCnt
HBM_C = M*N*sizeof(C)
```

L2 schedule 同時考慮：

- 以 192 MiB L2 對應 100 MiB 安全 working-set threshold。
- 最後一個 L2 tile 的 AIC parallelism。
- M/N tail smearing。
- 官方 seed 的 L2 footprint，而不是重新切成大量小 tile。

舊搜尋的已知退化例：

```text
8192 square: 舊 L2=15x8/16x7，新候選接近官方 5x3
vision:      舊 L2=5x5/7x4，新候選維持 1x1
```

因此新候選不是把舊的壞 tiling 改 rank 後重測。

### 8.6 ND->NZ

完整 callback blob 的 `baseAN/baseAD/baseBN/baseBD` 用來估算 vector
conversion bytes 與 tile transaction。值為 0 表示該 side/axis 不需要顯式
split，不會被當成 tile size 1。

## 9. 歷史資料與量測預算

`results/npu_full_ocr_measurements.csv` 是使用者已轉錄的 910B3/20-AIC
真機結果。重用條件為：

```text
workload + shape + dtype + template + baseMNK
+ singleCoreMNK + cores + output grid + L2 schedule
```

同 fingerprint 的多筆 l2 order 依順序一對一匹配，不會把一筆舊時間複製給
所有新候選。未匹配的新 L1/L2/baseMNK 仍須實測；bank seed control 永不從
舊資料假造。

對 bank path 不改 ND->NZ 的 workload，可用至少兩個相同歷史 schedule 的
residual 中位數校正附近候選。校正限制在 `[0.85, 1.15]`，避免少量舊資料
主導未知空間。bank path 有衍生欄位差異時完全不做此校正。

目前可比較資料很少：

- 5 個獨立、相同 schedule 且無 bank-path diff 的點。
- 其中 4 點可做 leave-one-schedule-out。
- 該 4 點 ratio MAE 約 2.18%。

這只是小樣本 sanity check，不是整個模型的準確率聲明。

完整 callback 後，預測比 bank seed 慢超過 3% 的候選不送 NPU。若所有其他
欄位都相同、只減少 `usedCoreNum`，候選視為被 bank seed 支配。預設上限可用
`MODEL_RATIO_LIMIT` 調整。

## 10. NPU 決策

每個 NPU 候選必須輸出：

```text
searched_ms
bank_seed_control_ms
official_operator_ms
speedup_vs_bank
speedup_vs_official
model_raw_ratio
history_calibration
noise threshold
```

判定：

```text
improved:
  searched 同時比 official 與 bank seed control 低，
  且兩個差值都超過各自合併 stddev 噪聲門檻

within_noise:
  差值未超過門檻

regressed:
  searched latency 顯著較高
```

只有 `improved` 才是已證明的 tiling optimization。Top-K 量測是昂貴 objective
的最後驗證，不是窮舉所有 tiling。

## 11. 目前 host 驗證

低記憶體模式 `BUILD_JOBS=1` 已通過：

- C++ proxy model unit test。
- Python closed-form model、callback blob 與 20-core balance unit test。
- 10 個 validation workload。
- 43 個 RuntimeKb records（含 9 個 bank seed controls）。
- 所有 record `found=1`，callback 23 欄保持一致。
- 完整 blob SHA-256、ND->NZ diff 與 model breakdown 均寫入候選 CSV。

這些證明 host 搜尋與注入契約成立，不等於新候選已在 NPU 上加速。下一個必要
證據是重新執行 `smoke`，再執行 full NPU profile。

## 12. 主要資料來源

- CANN MatMulV3 8.5 公開源碼：
  https://gitcode.com/cann/ops-nn/tree/8.5.0/matmul/mat_mul_v3
- TCubeTiling API 與容量/對齊約束：
  https://www.hiascend.com/document/detail/en/canncommercial/850/API/ascendcopapi/atlasascendc_api_07_0673.html
- 官方 Matmul tiling 最佳實踐：
  https://www.hiascend.com/document/detail/en/canncommercial/850/opdevg/Ascendcopdevg/atlas_ascendc_best_practices_10_0041.html
- 官方 MDL 模板：
  https://www.hiascend.com/document/detail/en/canncommercial/850/opdevg/Ascendcopdevg/atlas_ascendc_best_practices_10_10009.html
- 官方 L2 cache tiling：
  https://www.hiascend.com/document/detail/en/canncommercial/850/opdevg/Ascendcopdevg/atlas_ascendc_best_practices_10_10012.html
- NPUMeter, ACM TACO 2026：
  https://doi.org/10.1145/3820380
- ROLLER, OSDI 2022：
  https://www.usenix.org/conference/osdi22/presentation/zhu
- Performance Modeling for the Da Vinci AI Core：
  https://www.sciencedirect.com/science/article/pii/S074373152300014X

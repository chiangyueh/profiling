# 官方 MatMulV3 NPU 驗證與計時

## 1. 執行順序

```text
完整候選 CSV
  -> 驗證實際 SoC/AIC 與安裝 bank filename
  -> 驗證 CANN bank schema/hash ABI
  -> 每個候選建立獨立 runtime bank
  -> RuntimeKb::InitBank + QueryBank 預檢
  -> 官方自動 baseline
  -> 搜尋候選逐一呼叫 aclnnMatmul
  -> preflight
  -> warmup
  -> ACL Event
  -> NPU 排名與 baseline 比較
```

Runtime bank 查詢是 host 操作，不會啟動 NPU。probe 先以精確 SoC 的
`PlatFormInfos` 初始化 bank，再要求每個候選查詢結果為 `found=1`。這只驗證
bank schema、hash 與 lookup；真正的模板執行合法性仍由後續 NPU preflight
判定。

## 2. 相同官方 Kernel

baseline：

```text
TUNE_BANK_PATH=<空的專案目錄>
ASCEND_CACHE_PATH=<空的專案目錄>
aclnnMatmulGetWorkspaceSize(...)
aclnnMatmul(...)
```

searched：

```text
TUNE_BANK_PATH=<只含該候選的專案目錄>
ASCEND_CACHE_PATH=<該候選的專案目錄>
aclnnMatmulGetWorkspaceSize(...)
aclnnMatmul(...)
```

因此比較不包含自製 kernel 差異。每個候選在新 process 建立 executor，使
RuntimeBankManager cache 不會沿用上一個候選。

## 3. Correctness Preflight

若 A+B host buffer 不超過 `NUMERIC_PREFLIGHT_MAX_MIB`：

```text
A = 1
B = 1
C = poison
launch once
抽查 C 的 9 x 9 等距網格
expected = K
```

較大矩陣：

```text
A = 0
B = 0
C = poison
launch once
抽查 C 的 9 x 9 等距網格，所有位置必須被覆寫為 0
```

preflight、配置、H2D/D2H、workspace 與 executor 建立均不計入 latency。

## 4. ACL Event

每個配置：

```text
warmup 次 launch
synchronize stream

for sample:
    record start
    repeat 次 launch
    record end
    synchronize end
    latency_ms = elapsed_ms / repeat
```

記錄：

```text
min / mean / median / stddev / p95 / max
TFLOPS
preflight_passed
preflight_mode
```

最終以 `median_ms` 排序。改善判斷的噪聲門檻至少 1%，並納入 baseline 與
candidate 的 sample standard deviation。

## 5. Smoke 與 Full

Smoke：

```text
1 workload
1 baseline
1 bank roundtrip control
1 official-local searched candidate
warmup=2 repeat=5 samples=3
```

Full：

```text
40 組 workload
39 個 bank-path controls（INT8 為 unsupported 負向對照）
94 個 callback-valid searched candidates
3 個 unseen skinny-N holdout，各 6 個候選
6 個 prior-regression workload，各 2 個局部候選
warmup=10 repeat=50 samples=15
```

Full 預設使用 `config/workloads.csv`。歷史量測以 SoC、AIC 數、shape、dtype、
模板及完整可見排程指紋匹配；每筆舊 sample 最多指派給一個新候選。沒有精確
匹配的候選才送往 NPU。bank-path control 也只有在完整指紋匹配時才重用。

`skinny_n_large_k` 是 known anchor，只用來確認先前收益沒有消失。真正的
泛化判斷來自 3 個未見 holdout；三者必須全部顯著改善。另有 6 個先前退化
workload 作修復檢查。終端分組報告不允許 anchor 單獨讓整體顯示成功。
其餘 28 個一般支援 workload 也必須全部改善，廣域結論才可能是
`supported`；INT8 unsupported control 不計入這 28 組。

公開 MatMulV3 不接受本清單中的 INT8 input path，因此該 workload 明確標記
unsupported，不拿 MatMulV2 或量化算子結果冒充 MatMulV3 tiling。

## 6. Timeout 與錯誤

每個候選有獨立 process 和 timeout。若發生：

```text
RuntimeKb query failure
aclnnMatmulGetWorkspaceSize failure
preflight failure
ACL synchronization failure
timeout
```

baseline 或 bank seed control 失敗時，程式立即輸出真正失敗階段並停止，
因為此時無法建立可信比較。單一 searched candidate 在獨立 process 中被
preflight 拒絕時，則把 `success=0` 與完整錯誤寫入 candidates CSV，淘汰
該候選後繼續；這不會把失敗候選列入排名。

`aclInit`/`507008`、binary load/registration、dynamic linker 或 parent
process orchestration 錯誤均分類為 infrastructure failure，第一筆即停止，
不會把同一環境錯誤重複套到後續候選。

候選 process 的 stdout/stderr 直接寫入該候選的普通暫存檔，再由 parent
使用 `wait()` 管理 timeout。它不使用 `PIPE + communicate()`，避免 process
逾時且已關閉 stdout 時，第二次讀取 pipe 以 `I/O operation on closed file`
遮住真正的候選 timeout。

coverage failure 會額外列出 `T/S/C/G/L2`、L1 step/depth/DB、C 的線性 index
與 row/column，以及該位置是否仍為 `0x5a` poison，藉此區分「未寫輸出」和
單純數值偏差。若 profiler 本身失敗，shell 不再對不完整的 baseline CSV
執行排名，以免次要 traceback 遮住原始錯誤。

## 7. 輸出

預設：

```text
results/npu_<mode>_summary.csv
results/npu_<mode>_candidates.csv
```

`summary` 每個 workload 一列，包含最佳搜尋候選、bank-path control、官方
自動 baseline、speedup、latency change 與 verdict。只有 searched 同時勝過
兩個 reference 且超過合併噪聲門檻時，才標記為已證明的 tiling 優化；其他
情況標記 `no_proven_improvement`。`candidates` 保存所有成功量測與重用紀錄。

需要每次 sample：

```bash
KEEP_DETAILS=1 ./run_npu.sh --mode full
```

才會保留 `results/npu_full_details/`。其餘 profile 和 bank 暫存檔在成功或失敗
結束時清除。

## 8. 可聲明範圍

NPU 前只能聲明候選已通過：

- 精確 SoC/AIC 模型。
- 官方 `MultiCoreMatmulTiling`。
- 靜態容量與模板契約。
- CANN `RuntimeKb::InitBank + QueryBank` 查詢命中。

NPU 後才能聲明：

- 官方 kernel correctness preflight 通過。
- Top-K 內的實測最佳 latency。
- 相對原始官方自動 tiling 的改善或劣化。

Beam/LNS 不窮舉全部 tiling，因此不能把 Top-K 實測最佳描述為數學全域最優。
目前 active `official_local_v2` scope 只在官方 seed 周圍做受控候選，並不
執行 Tabu/LNS；後者僅保留在全模板契約研究程式中。

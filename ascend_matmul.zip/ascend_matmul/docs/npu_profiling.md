# NPU Correctness 與 Profiling

## 1. 執行順序

API 自動基線與搜尋候選使用同一個自訂 AscendC kernel。每個候選在計時前：

1. 比較 CSV 與 `TCubeTiling` binary 的 shape、single-core、base 與核心數。
2. 驗證一般多輪或直接 split-K execution-mode 契約。
3. 配置 A/B/C、workspace、tiling device memory。
4. 執行 correctness preflight。
5. preflight 成功後才 warmup 與 ACL Event 計時。

preflight、H2D/D2H、配置和進程啟動都不包含在 latency 中。

安裝版 `aclnnMatmul` 基線使用相同 tensor shape、dtype、transpose view 與
ACL Event 設定。`aclnnMatmulGetWorkspaceSize`、repeatable executor 建立與
workspace 配置在 event 外；event 內量到的是官方 MatMulV3 的完整 device 執行鏈。

## 2. Correctness preflight

若 A+B host buffer 不超過 `NUMERIC_PREFLIGHT_MAX_MIB`（預設 4 MiB）：

```text
A = 1
B = 1
C = poison
launch once
抽查 C 的首、尾、中點、singleCoreM/N 邊界
expected C[i,j] = K
preflight_mode = numeric_ones
```

較大矩陣不建立大型 host input：

```text
A = 0
B = 0
C = poison
launch once
相同邊界必須全部被覆寫成 0
preflight_mode = zero_coverage
```

完整逐元素數值與 transpose 驗證由 CANN CPU Debug `--mode full` 執行；NPU
preflight 是低成本的真機 launch/correctness gate。

## 3. ACL Event

每個候選：

```text
warmup 次 launch
synchronize stream

for sample:
    record start event
    repeat 次 launch
    record end event
    synchronize end event
    latency_ms = elapsed_ms / repeat
```

輸出：

```text
min_ms
mean_ms
median_ms
stddev_ms
p95_ms
max_ms
tflops
preflight_passed
preflight_mode
```

最終排序以 `median_ms` 為主，`stddev_ms` 用來辨識噪聲。

## 4. Smoke

```bash
./run_npu.sh --mode smoke
```

預設：

```text
1 個 FP16 256x256x256 workload
安裝版 aclnnMatmul + API 自動 rank-0 + 搜尋 rank-1
2 warmup
5 repeat
3 samples
每個量測配置 18 次 operator call，共 54 次（包含 preflight）
```

成功必須同時表示：

- 精確 SoC 偵測與 B3/Bx 編譯成功
- 兩個 runner 載入正確 CANN runtime
- 安裝版 aclnnMatmul preflight 與計時成功
- kernel register/launch 成功
- numeric-ones preflight 成功
- ACL Event 樣本與結果 CSV 已寫出

## 5. Full

```bash
./run_npu.sh --mode full
```

預設 28 workloads。其中 18 個符合自訂 raw-ND Cube 對齊契約，每個有最多
一個 API 自動基線加 Top-20 搜尋候選；原始 28 個 workload 都交給安裝版
`aclnnMatmul` baseline runner，27 個 FP16/BF16/FP32 workload 受支援。INT8
會明確標記 unsupported。設定為 10 warmup、50 repeat、15 samples。

未對齊的 10 個 workload 需要官方 MatMulV3 的 ND2NZ/NZ2ND extended template，
所以不產生自訂 tiling binary；它們仍保留官方 operator latency，摘要標記
`no_successful_searched_candidate`。
可先執行較小但仍有代表性的批次：

```bash
TOP_K=5 RANK_LIMIT=5 WARMUP=5 REPEAT=20 SAMPLES=5 \
./run_npu.sh --mode full
```

候選由獨立 runner 行程執行，避免一個 AI Core exception 污染後續 context。
預設 60 秒無 child output 視為 stall，終端會顯示：

```text
workload
rank
last stage
tiling binary/signature
```

單一候選失敗會記錄在 profile 結果，其他候選仍可完成與排名。只有全域
setup/baseline 失敗，或有候選但沒有任何自訂候選成功時，整體命令回傳非零。

## 6. 終端與日誌

預設終端只顯示階段、候選進度、完成狀態或錯誤。完整細節在：

```text
results/logs/run_npu_*.log
results/logs/*_runner_*.log
results/logs/*_runtime_diag_*.log
```

需要完整輸出：

```bash
RUN_VERBOSE=1 ./run_npu.sh --mode smoke
```

## 7. 排名與模型評價

成功後生成：

```text
*_summary.csv
*_candidates.csv
```

`*_summary.csv` 是每個 workload 一列的最終比較；`*_candidates.csv` 是成功
候選的實測明細。原始 profile、samples、官方 baseline 與代理模型比較是
內部資料，預設在排名完成後清理。

需要檢查每次量測時才啟用：

```bash
KEEP_DETAILS=1 ./run_npu.sh --mode full
```

中間資料會集中在 `results/npu_full_details/`。

應報告：

- API 自動基線、官方 operator 與搜尋候選的 median latency/TFLOPS
- `speedup_vs_api_auto = api_auto_ms / searched_ms`
- `speedup_vs_official_operator = official_operator_ms / searched_ms`
- 兩組 `latency_change_pct`，負值代表改善，正值代表劣化
- 兩組 `verdict = improved / regressed / within_noise`
- `primary_reference=official_operator` 表示最終端到端判定採官方 MatMulV3
- Spearman/Kendall 排名相關
- Top-1、Top-3、Top-5 regret
- 每個 workload 的樣本變異
- 失敗候選與 execution mode

不要對每個候選跑完整 `msprof`。先用 ACL Event 找出前幾名，再選 API 自動
基線、官方 operator、模型 Rank-1、真機 Rank-1 等代表配置：

```bash
./scripts/profile_one_msprof.sh llm_full_4096_ffn_up 1 results/candidates.csv
```

重點指標：

- Cube pipeline 使用率
- MTE pipeline 使用率
- AI Core task time
- Runtime API time

## 8. 精測

第一輪找到前 3 名後：

```bash
RANK_LIMIT=3 WARMUP=30 REPEAT=200 SAMPLES=30 \
./scripts/profile_npu.sh results/candidates.csv results/npu_precise
```

若需要增加小矩陣數值 preflight 上限：

```bash
NUMERIC_PREFLIGHT_MAX_MIB=16 ./run_npu.sh --mode full
```

這只增加該 runner 的暫時 host buffer，不修改系統設定。

#include "official_tiling.h"

#include <algorithm>
#include <cstdint>
#include <exception>
#include <sstream>

namespace matmul_search {
namespace {

matmul_tiling::DataType ToCannInputType(DType dtype)
{
    switch (dtype) {
        case DType::FP16: return matmul_tiling::DataType::DT_FLOAT16;
        case DType::BF16: return matmul_tiling::DataType::DT_BF16;
        case DType::FP32: return matmul_tiling::DataType::DT_FLOAT;
        case DType::INT8: return matmul_tiling::DataType::DT_INT8;
    }
    return matmul_tiling::DataType::DT_FLOAT16;
}

matmul_tiling::DataType ToCannOutputType(DType dtype)
{
    if (dtype == DType::INT8) {
        return matmul_tiling::DataType::DT_INT32;
    }
    return ToCannInputType(dtype);
}

void AppendSetterError(std::ostringstream &os, const char *name, int32_t rc)
{
    if (rc != 0) {
        if (os.tellp() > 0) {
            os << '|';
        }
        os << name << '=' << rc;
    }
}

template <typename T>
T CeilDiv(T x, T y)
{
    return y <= 0 ? 0 : (x + y - 1) / y;
}

std::string ContractError(const std::string &reason)
{
    return "tiling_contract:" + reason;
}

}  // namespace

bool SupportsDirectAtomicSplitK(const Workload &workload)
{
    // This is the MatMulV3 MULTI_CORE_SPLIT_K template contract, not a
    // heuristic. Other dtypes require workspace reduction/cast templates.
    return workload.dtype == DType::FP32 && !workload.transA && workload.transB;
}

std::string ValidateTilingContract(const Workload &workload, const TCubeTiling &tiling,
                                   const PlatformCaps &caps, ExecutionMode &mode)
{
    mode = ExecutionMode::NONE;
    if (tiling.M != workload.m || tiling.N != workload.n ||
        tiling.Ka != workload.k || tiling.Kb != workload.k) {
        return ContractError("official shape does not match workload");
    }
    if (tiling.usedCoreNum <= 0 || tiling.singleCoreM <= 0 || tiling.singleCoreN <= 0 ||
        tiling.singleCoreK <= 0 || tiling.baseM <= 0 || tiling.baseN <= 0 || tiling.baseK <= 0) {
        return ContractError("non-positive core or tile dimension");
    }

    const int32_t coreLimit = std::max(1, std::min(workload.maxCores, caps.coreNum));
    if (tiling.usedCoreNum > coreLimit) {
        return ContractError("usedCoreNum exceeds workload/platform limit");
    }

    const int32_t k0 = (32 / DTypeBits(workload.dtype)) * 8;
    if (tiling.baseM % 16 != 0 || tiling.baseN % 16 != 0 ||
        k0 <= 0 || tiling.baseK % k0 != 0) {
        return ContractError("baseMNK violates Cube M0/N0/K0 alignment");
    }
    if (tiling.stepM <= 0 || tiling.stepN <= 0 || tiling.stepKa <= 0 || tiling.stepKb <= 0 ||
        tiling.depthA1 <= 0 || tiling.depthB1 <= 0) {
        return ContractError("non-positive L1 depth or step");
    }
    if (tiling.stepM > tiling.depthA1 || tiling.stepN > tiling.depthB1) {
        return ContractError("L1 step exceeds depth");
    }
    if (tiling.dbL0A < 1 || tiling.dbL0A > 2 || tiling.dbL0B < 1 || tiling.dbL0B > 2 ||
        tiling.dbL0C < 1 || tiling.dbL0C > 2) {
        return ContractError("invalid final L0 buffer count");
    }

    const uint64_t inputBytes = static_cast<uint64_t>(DTypeBytes(workload.dtype));
    const uint64_t l0a = static_cast<uint64_t>(tiling.baseM) * tiling.baseK * inputBytes * tiling.dbL0A;
    const uint64_t l0b = static_cast<uint64_t>(tiling.baseN) * tiling.baseK * inputBytes * tiling.dbL0B;
    const uint64_t l0c = static_cast<uint64_t>(tiling.baseM) * tiling.baseN *
        AccumulatorBytes(workload.dtype) * tiling.dbL0C;
    if (l0a > caps.l0aBytes || l0b > caps.l0bBytes || l0c > caps.l0cBytes) {
        return ContractError("final DB-adjusted L0 allocation exceeds platform capacity");
    }
    if (tiling.shareL1Size < 0 || tiling.shareL0CSize < 0 || tiling.shareUbSize < 0 ||
        static_cast<uint64_t>(tiling.shareL1Size) > caps.l1Bytes ||
        static_cast<uint64_t>(tiling.shareL0CSize) > caps.l0cBytes ||
        static_cast<uint64_t>(tiling.shareUbSize) > caps.ubBytes) {
        return ContractError("official shared workspace exceeds platform capacity");
    }

    const uint64_t mParts = CeilDiv<uint64_t>(workload.m, tiling.singleCoreM);
    const uint64_t nParts = CeilDiv<uint64_t>(workload.n, tiling.singleCoreN);
    const uint64_t kParts = CeilDiv<uint64_t>(workload.k, tiling.singleCoreK);
    const uint64_t mappedCores = mParts * nParts * kParts;
    if (mappedCores != static_cast<uint64_t>(tiling.usedCoreNum)) {
        return ContractError("usedCoreNum does not equal M/N/K core partition product");
    }

    if (kParts == 1) {
        mode = ExecutionMode::BASE_ITERATE_ALL;
        return {};
    }
    if (!SupportsDirectAtomicSplitK(workload)) {
        return ContractError("cross-core split-K requires deterministic/workspace reduction; "
                             "direct atomic mode only supports fp32 transA=false transB=true");
    }
    if (mappedCores > static_cast<uint64_t>(coreLimit)) {
        return ContractError("direct atomic split-K requires a single scheduling round");
    }
    const uint64_t c0Elements = 32 / static_cast<uint64_t>(OutputBytes(workload.dtype));
    const uint64_t outputElements = static_cast<uint64_t>(workload.m) * workload.n;
    const uint64_t alignedOutput = CeilDiv<uint64_t>(outputElements, c0Elements) * c0Elements;
    const uint64_t clearElementsPerCore =
        CeilDiv<uint64_t>(CeilDiv<uint64_t>(alignedOutput, mappedCores), c0Elements) * c0Elements;
    const uint64_t clearBytesPerCore = clearElementsPerCore * OutputBytes(workload.dtype);
    if (clearBytesPerCore + static_cast<uint64_t>(tiling.shareL1Size) > caps.l1Bytes) {
        return ContractError("direct atomic split-K clear buffer plus Matmul L1 exceeds L1 capacity");
    }

    mode = ExecutionMode::DIRECT_ATOMIC_SPLIT_K_FP32_NT;
    return {};
}

OfficialTilingEngine::OfficialTilingEngine(const std::string &socVersion)
{
    platform_ = platform_ascendc::PlatformAscendCManager::GetInstance(socVersion.c_str());
    if (platform_ == nullptr) {
        error_ = "PlatformAscendCManager returned null";
        return;
    }

    caps_.coreNum = static_cast<int32_t>(platform_->GetCoreNumAic());
    if (caps_.coreNum <= 0) {
        caps_.coreNum = static_cast<int32_t>(platform_->GetCoreNum());
    }
    if (caps_.coreNum <= 0) {
        caps_.coreNum = 24;
    }

    auto readSize = [this](platform_ascendc::CoreMemType type, uint64_t fallback) {
        uint64_t size = 0;
        platform_->GetCoreMemSize(type, size);
        return size == 0 ? fallback : size;
    };
    caps_.l0aBytes = readSize(platform_ascendc::CoreMemType::L0_A, caps_.l0aBytes);
    caps_.l0bBytes = readSize(platform_ascendc::CoreMemType::L0_B, caps_.l0bBytes);
    caps_.l0cBytes = readSize(platform_ascendc::CoreMemType::L0_C, caps_.l0cBytes);
    caps_.l1Bytes = readSize(platform_ascendc::CoreMemType::L1, caps_.l1Bytes);
    caps_.ubBytes = readSize(platform_ascendc::CoreMemType::UB, caps_.ubBytes);
}

bool OfficialTilingEngine::IsReady() const
{
    return platform_ != nullptr;
}

const std::string &OfficialTilingEngine::Error() const
{
    return error_;
}

const PlatformCaps &OfficialTilingEngine::Caps() const
{
    return caps_;
}

Evaluation OfficialTilingEngine::Evaluate(const Workload &workload, const Candidate &candidate) const
{
    Evaluation result;
    result.workload = workload;
    result.candidate = candidate;

    if (platform_ == nullptr) {
        result.error = error_;
        return result;
    }
    if (workload.m <= 0 || workload.n <= 0 || workload.k <= 0) {
        result.error = "shape must be positive";
        return result;
    }

    try {
        matmul_tiling::MultiCoreMatmulTiling tiler(*platform_);
        std::ostringstream setterErrors;
        const auto inputType = ToCannInputType(workload.dtype);
        const auto outputType = ToCannOutputType(workload.dtype);

        AppendSetterError(setterErrors, "SetDim", tiler.SetDim(std::min(workload.maxCores, caps_.coreNum)));
        AppendSetterError(setterErrors, "SetAType", tiler.SetAType(
            matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND, inputType, workload.transA));
        AppendSetterError(setterErrors, "SetBType", tiler.SetBType(
            matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND, inputType, workload.transB));
        AppendSetterError(setterErrors, "SetCType", tiler.SetCType(
            matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND, outputType));
        AppendSetterError(setterErrors, "SetShape", tiler.SetShape(workload.m, workload.n, workload.k));
        AppendSetterError(setterErrors, "SetOrgShape", tiler.SetOrgShape(workload.m, workload.n, workload.k));
        AppendSetterError(setterErrors, "SetFixSplit", tiler.SetFixSplit(
            candidate.baseM, candidate.baseN, candidate.baseK));
        AppendSetterError(setterErrors, "SetDoubleBuffer", tiler.SetDoubleBuffer(
            candidate.dbA, candidate.dbB, false, false, true, true));

        if (candidate.traverse == 1) {
            AppendSetterError(setterErrors, "SetTraverseM", tiler.SetTraverse(matmul_tiling::MatrixTraverse::FIRSTM));
        } else if (candidate.traverse == 2) {
            AppendSetterError(setterErrors, "SetTraverseN", tiler.SetTraverse(matmul_tiling::MatrixTraverse::FIRSTN));
        }
        tiler.EnableMultiCoreSplitK(candidate.splitK);

        if (setterErrors.tellp() > 0) {
            result.error = setterErrors.str();
            return result;
        }

        result.officialReturn = tiler.GetTiling(result.tiling);
        if (result.officialReturn == -1) {
            result.error = "MultiCoreMatmulTiling::GetTiling returned -1";
            return result;
        }
        result.tilingSignature = TilingSignature(result.tiling);
        result.error = ValidateTilingContract(workload, result.tiling, caps_, result.executionMode);
        if (!result.error.empty()) {
            return result;
        }

        result.valid = true;
        return result;
    } catch (const std::exception &ex) {
        result.error = std::string("exception:") + ex.what();
        return result;
    } catch (...) {
        result.error = "unknown exception";
        return result;
    }
}

}  // namespace matmul_search

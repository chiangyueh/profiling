#include "kernel_operator.h"
#include "lib/matmul_intf.h"

namespace {

// MatMulV3's aligned base template uses MDL with UnitFlag enabled.  The
// TCubeTiling returned by MultiCoreMatmulTiling is consumed by this template,
// so the kernel must use the same scheduler family.
constexpr MatmulConfig kMatmulMdlConfig =
    GetMDLConfig(false, false, 0, false, false, false, true);

__aicore__ inline void LoadCubeTiling(const __gm__ uint8_t *srcBytes, TCubeTiling &dst)
{
    const __gm__ uint32_t *src = reinterpret_cast<const __gm__ uint32_t *>(srcBytes);
    uint32_t *out = reinterpret_cast<uint32_t *>(&dst);
    for (uint32_t i = 0; i < sizeof(TCubeTiling) / sizeof(uint32_t); ++i) {
        out[i] = src[i];
    }
}

__aicore__ inline uint64_t CeilDivU64(uint64_t x, uint64_t y)
{
    return y == 0 ? 0 : (x + y - 1) / y;
}

__aicore__ inline uint64_t AlignUpU64(uint64_t x, uint64_t alignment)
{
    return CeilDivU64(x, alignment) * alignment;
}

template <typename T>
__aicore__ inline void ZeroGlobalOutput(AscendC::GlobalTensor<T> &cGm, const TCubeTiling &tiling, AscendC::TPipe &pipe)
{
    const uint64_t c0 = 32 / sizeof(T);
    const uint64_t outSize = AlignUpU64(static_cast<uint64_t>(tiling.M) * tiling.N, c0);
    const uint64_t clearSizePerCore = AlignUpU64(CeilDivU64(outSize, AscendC::GetBlockNum()), c0);
    uint64_t dstOffset = clearSizePerCore * AscendC::GetBlockIdx();

    AscendC::TBuf<AscendC::TPosition::TSCM> localBuffer;
    pipe.InitBuffer(localBuffer, clearSizePerCore * sizeof(T));
    AscendC::LocalTensor<T> zeros = localBuffer.Get<T>();
    if (outSize > dstOffset) {
        uint16_t blockLen = static_cast<uint16_t>(CeilDivU64(clearSizePerCore, c0));
        if (outSize - dstOffset < clearSizePerCore) {
            blockLen = static_cast<uint16_t>(CeilDivU64(outSize - dstOffset, c0));
            dstOffset = outSize - static_cast<uint64_t>(blockLen) * c0;
        }
        AscendC::InitConstValue(zeros, {1, blockLen, 0, 0U});
        AscendC::DataCopyParams copyParams(1, blockLen, 0, 0);
        AscendC::DataCopy(cGm[dstOffset], zeros, copyParams);
    }
}

template <typename InputT, typename OutputT, bool TRANS_A, bool TRANS_B>
__aicore__ inline void RunMatmulSplitK(
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, const TCubeTiling &tilingData)
{
    (void)workspace;
    using AType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, InputT, TRANS_A>;
    using BType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, InputT, TRANS_B>;
    using CType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, OutputT, false>;

    AscendC::GlobalTensor<InputT> aGm;
    AscendC::GlobalTensor<InputT> bGm;
    AscendC::GlobalTensor<OutputT> cGm;
    aGm.SetGlobalBuffer(reinterpret_cast<__gm__ InputT *>(a), static_cast<uint64_t>(tilingData.M) * tilingData.Ka);
    bGm.SetGlobalBuffer(reinterpret_cast<__gm__ InputT *>(b), static_cast<uint64_t>(tilingData.Kb) * tilingData.N);
    cGm.SetGlobalBuffer(reinterpret_cast<__gm__ OutputT *>(c), static_cast<uint64_t>(tilingData.M) * tilingData.N);

    AscendC::TPipe pipe;
    ZeroGlobalOutput(cGm, tilingData, pipe);
    AscendC::SetAtomicNone();

    if (AscendC::GetBlockIdx() >= static_cast<uint64_t>(tilingData.usedCoreNum)) {
        AscendC::CrossCoreSetFlag<0, PIPE_MTE3>(AscendC::SYNC_AIC_FLAG);
        AscendC::CrossCoreWaitFlag(AscendC::SYNC_AIC_FLAG);
        return;
    }

    AscendC::MatmulImpl<
        AType, BType, CType, CType, kMatmulMdlConfig,
        AscendC::MatmulCallBackFunc<nullptr, nullptr, nullptr>> mm;
    mm.SetSubBlockIdx(0);
    mm.Init(&tilingData, &pipe);
    mm.SetOrgShape(tilingData.M, tilingData.N, tilingData.Ka, tilingData.Kb, tilingData.N);

    const uint64_t mCnt = CeilDivU64(tilingData.M, tilingData.singleCoreM);
    const uint64_t nCnt = CeilDivU64(tilingData.N, tilingData.singleCoreN);
    const uint64_t kCnt = CeilDivU64(tilingData.Ka, tilingData.singleCoreK);
    const uint64_t blockIdx = AscendC::GetBlockIdx();
    const uint64_t mIndex = blockIdx % mCnt;
    const uint64_t nIndex = (blockIdx / mCnt) % nCnt;
    const uint64_t kIndex = blockIdx / (mCnt * nCnt);

    const uint64_t mCoreTail = tilingData.M - (mCnt - 1) * tilingData.singleCoreM;
    const uint64_t nCoreTail = tilingData.N - (nCnt - 1) * tilingData.singleCoreN;
    const uint64_t kCoreTail = tilingData.Ka - (kCnt - 1) * tilingData.singleCoreK;
    const uint64_t mCoreUse = mIndex == mCnt - 1 ? mCoreTail : tilingData.singleCoreM;
    const uint64_t nCoreUse = nIndex == nCnt - 1 ? nCoreTail : tilingData.singleCoreN;
    const uint64_t kCoreUse = kIndex == kCnt - 1 ? kCoreTail : tilingData.singleCoreK;

    const uint64_t offsetA = kIndex * tilingData.singleCoreK +
        mIndex * tilingData.singleCoreM * tilingData.Ka;
    const uint64_t offsetB = kIndex * tilingData.singleCoreK +
        nIndex * tilingData.singleCoreN * tilingData.Kb;
    const uint64_t offsetC = nIndex * tilingData.singleCoreN +
        mIndex * tilingData.singleCoreM * tilingData.N;

    mm.SetSingleShape(mCoreUse, nCoreUse, kCoreUse);
    mm.SetTensorA(aGm[offsetA], TRANS_A);
    mm.SetTensorB(bGm[offsetB], TRANS_B);
    mm.Iterate();
    // Match MatMulV3's direct multi-core split-K template: all partial
    // products are ready, and all disjoint C clear operations are visible,
    // before any core starts atomic fixpipe accumulation.
    AscendC::CrossCoreSetFlag<0, PIPE_MTE3>(AscendC::SYNC_AIC_FLAG);
    AscendC::CrossCoreWaitFlag(AscendC::SYNC_AIC_FLAG);
    mm.GetTensorC(cGm[offsetC], 1);
    AscendC::PipeBarrier<PIPE_ALL>();
    AscendC::SetAtomicNone();
    mm.SetHF32(false, 0);
}

template <typename InputT, typename OutputT, bool TRANS_A, bool TRANS_B, bool DIRECT_ATOMIC_SPLIT_K>
__aicore__ inline void RunMatmul(
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, GM_ADDR tiling)
{
    (void)workspace;
#if defined(__CCE_KT_TEST__) && defined(MATMUL_CPU_SMOKE_ONLY)
    if (g_coreType != AscendC::AIC_TYPE) {
        return;
    }
#endif
    using AType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, InputT, TRANS_A>;
    using BType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, InputT, TRANS_B>;
    using CType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, OutputT, false>;

    TCubeTiling tilingData{};
    LoadCubeTiling(reinterpret_cast<const __gm__ uint8_t *>(tiling), tilingData);
    if (tilingData.singleCoreK > 0 && tilingData.singleCoreK < tilingData.Ka) {
        if constexpr (DIRECT_ATOMIC_SPLIT_K) {
            RunMatmulSplitK<InputT, OutputT, TRANS_A, TRANS_B>(a, b, c, workspace, tilingData);
        }
        return;
    }

    AscendC::TPipe pipe;
    AscendC::MatmulImpl<
        AType, BType, CType, CType, kMatmulMdlConfig,
        AscendC::MatmulCallBackFunc<nullptr, nullptr, nullptr>> mm;
    mm.SetSubBlockIdx(0);
    mm.Init(&tilingData, &pipe);

    AscendC::GlobalTensor<InputT> aGm;
    AscendC::GlobalTensor<InputT> bGm;
    AscendC::GlobalTensor<OutputT> cGm;
    aGm.SetGlobalBuffer(reinterpret_cast<__gm__ InputT *>(a),
        static_cast<uint64_t>(tilingData.M) * tilingData.Ka);
    bGm.SetGlobalBuffer(reinterpret_cast<__gm__ InputT *>(b),
        static_cast<uint64_t>(tilingData.Kb) * tilingData.N);
    cGm.SetGlobalBuffer(reinterpret_cast<__gm__ OutputT *>(c),
        static_cast<uint64_t>(tilingData.M) * tilingData.N);

    const uint64_t mCnt = CeilDivU64(tilingData.M, tilingData.singleCoreM);
    const uint64_t nCnt = CeilDivU64(tilingData.N, tilingData.singleCoreN);
    const uint64_t totalTileCnt = mCnt * nCnt;
    const uint64_t usedCoreNum = static_cast<uint64_t>(tilingData.usedCoreNum);
    const uint64_t blockIdx = AscendC::GetBlockIdx();
    if (mCnt == 0 || nCnt == 0 || usedCoreNum == 0 || blockIdx >= usedCoreNum || blockIdx >= totalTileCnt) {
        return;
    }

    // Match MatMulV3's row-major multi-core partition and contiguous tail balancing.
    const uint64_t rounds = CeilDivU64(totalTileCnt, usedCoreNum);
    const uint64_t fullRoundCores = totalTileCnt % usedCoreNum == 0 ?
        usedCoreNum : totalTileCnt % usedCoreNum;
    const uint64_t coreRounds = blockIdx < fullRoundCores ? rounds : rounds - 1;
    const uint64_t firstTile = blockIdx < fullRoundCores ?
        blockIdx * rounds :
        fullRoundCores * rounds + (blockIdx - fullRoundCores) * (rounds - 1);

    for (uint64_t round = 0; round < coreRounds; ++round) {
        const uint64_t tileIndex = firstTile + round;
        const uint64_t mIndex = tileIndex / nCnt;
        const uint64_t nIndex = tileIndex % nCnt;
        const uint64_t mStart = mIndex * tilingData.singleCoreM;
        const uint64_t nStart = nIndex * tilingData.singleCoreN;
        const uint64_t mCoreUse = mIndex == mCnt - 1 ?
            static_cast<uint64_t>(tilingData.M) - mStart : tilingData.singleCoreM;
        const uint64_t nCoreUse = nIndex == nCnt - 1 ?
            static_cast<uint64_t>(tilingData.N) - nStart : tilingData.singleCoreN;

        const uint64_t offsetA = TRANS_A ? mStart : mStart * tilingData.Ka;
        const uint64_t offsetB = TRANS_B ? nStart * tilingData.Kb : nStart;
        const uint64_t offsetC = mStart * tilingData.N + nStart;

        // This branch has no cross-core K split. Use the real K extent so an
        // aligned singleCoreK returned by a tiler can never read past GM.
        mm.SetSingleShape(mCoreUse, nCoreUse, tilingData.Ka);
        mm.SetTensorA(aGm[offsetA], TRANS_A);
        mm.SetTensorB(bGm[offsetB], TRANS_B);
        // MultiCoreMatmulTiling may return a single-core shape that spans
        // several baseM/baseN tiles. IterateAll drains every such output tile.
        mm.IterateAll(cGm[offsetC], 0);
    }
    AscendC::PipeBarrier<PIPE_ALL>();
    AscendC::SetAtomicNone();
    mm.SetHF32(false, 0);
}

}  // namespace

#define DEFINE_MATMUL_KERNEL(NAME, INPUT_T, OUTPUT_T, TRANS_A, TRANS_B, DIRECT_SPLIT_K) \
extern "C" __global__ __aicore__ void NAME(                              \
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, GM_ADDR tiling)  \
{                                                                         \
    RunMatmul<INPUT_T, OUTPUT_T, TRANS_A, TRANS_B, DIRECT_SPLIT_K>(a, b, c, workspace, tiling); \
}

#ifdef MATMUL_CPU_SMOKE_ONLY
#ifndef MATMUL_CPU_TRANS_A
#define MATMUL_CPU_TRANS_A 0
#endif
#ifndef MATMUL_CPU_TRANS_B
#define MATMUL_CPU_TRANS_B 0
#endif
#ifndef MATMUL_CPU_FP32
#define MATMUL_CPU_FP32 0
#endif
#if MATMUL_CPU_FP32
DEFINE_MATMUL_KERNEL(matmul_search_test, float, float,
                     (MATMUL_CPU_TRANS_A != 0), (MATMUL_CPU_TRANS_B != 0),
                     (MATMUL_CPU_TRANS_A == 0 && MATMUL_CPU_TRANS_B != 0))
#else
DEFINE_MATMUL_KERNEL(matmul_search_test, half, half,
                     (MATMUL_CPU_TRANS_A != 0), (MATMUL_CPU_TRANS_B != 0), false)
#endif
#else
DEFINE_MATMUL_KERNEL(matmul_search_fp16_nn, half, half, false, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp16_tn, half, half, true, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp16_nt, half, half, false, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp16_tt, half, half, true, true, false)

DEFINE_MATMUL_KERNEL(matmul_search_bf16_nn, bfloat16_t, bfloat16_t, false, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_bf16_tn, bfloat16_t, bfloat16_t, true, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_bf16_nt, bfloat16_t, bfloat16_t, false, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_bf16_tt, bfloat16_t, bfloat16_t, true, true, false)

DEFINE_MATMUL_KERNEL(matmul_search_fp32_nn, float, float, false, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp32_tn, float, float, true, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp32_nt, float, float, false, true, true)
DEFINE_MATMUL_KERNEL(matmul_search_fp32_tt, float, float, true, true, false)

DEFINE_MATMUL_KERNEL(matmul_search_int8_nn, int8_t, int32_t, false, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_int8_tn, int8_t, int32_t, true, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_int8_nt, int8_t, int32_t, false, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_int8_tt, int8_t, int32_t, true, true, false)
#endif

#undef DEFINE_MATMUL_KERNEL

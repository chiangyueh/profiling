#include <acl/acl.h>
#include <acl/acl_rt.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {

struct Options {
    std::string candidatesCsv = "results/candidates.csv";
    std::string outputCsv = "results/npu_profile.csv";
    std::string samplesCsv = "results/npu_profile_samples.csv";
    int32_t deviceId = 0;
    int32_t warmup = 10;
    int32_t repeat = 50;
    int32_t samples = 15;
    int32_t workloadLimit = -1;
    int32_t rankLimit = -1;
    int32_t onlyRank = -1;
    std::string onlyWorkload;
    int32_t workspaceMiB = 64;
    int32_t numericPreflightMaxMiB = 4;
    int32_t stageLogInterval = 1;
    int32_t repeatStageInterval = 0;
};

struct CandidateRow {
    int32_t rank = 0;
    std::string workloadId;
    std::string source;
    std::string candidateRole;
    int64_t m = 0;
    int64_t n = 0;
    int64_t k = 0;
    std::string dtype;
    bool transA = false;
    bool transB = false;
    std::string executionMode;
    int32_t usedCoreNum = 0;
    int32_t singleCoreM = 0;
    int32_t singleCoreN = 0;
    int32_t singleCoreK = 0;
    int32_t hintSingleM = 0;
    int32_t hintSingleN = 0;
    int32_t hintSingleK = 0;
    int32_t hintBaseM = 0;
    int32_t hintBaseN = 0;
    int32_t hintBaseK = 0;
    int32_t officialBaseM = 0;
    int32_t officialBaseN = 0;
    int32_t officialBaseK = 0;
    int32_t officialCoreNum = 0;
    int32_t officialMDim = 0;
    int32_t officialNDim = 0;
    double proxyTotal = 0.0;
    std::string tilingSignature;
    std::string tilingBin;
};

struct CubeTilingPrefix {
    int32_t usedCoreNum;
    int32_t m;
    int32_t n;
    int32_t ka;
    int32_t kb;
    int32_t singleCoreM;
    int32_t singleCoreN;
    int32_t singleCoreK;
    int32_t baseM;
    int32_t baseN;
    int32_t baseK;
};

static_assert(sizeof(CubeTilingPrefix) == 11 * sizeof(int32_t), "unexpected tiling prefix layout");

struct ProfileSummary {
    bool success = false;
    bool preflightPassed = false;
    std::string preflightMode;
    std::string error;
    std::vector<double> valuesMs;
    double minimum = 0.0;
    double mean = 0.0;
    double median = 0.0;
    double standardDeviation = 0.0;
    double p95 = 0.0;
    double maximum = 0.0;
    double tflops = 0.0;
};

struct DeviceBuffer {
    void *ptr = nullptr;
    size_t bytes = 0;

    DeviceBuffer() = default;
    explicit DeviceBuffer(size_t requested) { Allocate(requested); }
    DeviceBuffer(const DeviceBuffer &) = delete;
    DeviceBuffer &operator=(const DeviceBuffer &) = delete;
    DeviceBuffer(DeviceBuffer &&other) noexcept : ptr(other.ptr), bytes(other.bytes)
    {
        other.ptr = nullptr;
        other.bytes = 0;
    }
    DeviceBuffer &operator=(DeviceBuffer &&other) noexcept
    {
        if (this != &other) {
            Release();
            ptr = other.ptr;
            bytes = other.bytes;
            other.ptr = nullptr;
            other.bytes = 0;
        }
        return *this;
    }
    ~DeviceBuffer() { Release(); }

    void Allocate(size_t requested)
    {
        Release();
        bytes = std::max<size_t>(requested, 32);
        const aclError rc = aclrtMalloc(&ptr, bytes, ACL_MEM_MALLOC_HUGE_FIRST);
        if (rc != ACL_SUCCESS) {
            ptr = nullptr;
            throw std::runtime_error("aclrtMalloc failed, bytes=" + std::to_string(bytes) +
                                     ", rc=" + std::to_string(rc));
        }
    }

    void Release()
    {
        if (ptr != nullptr) {
            aclrtFree(ptr);
            ptr = nullptr;
            bytes = 0;
        }
    }
};

struct KernelArguments {
    void *a;
    void *b;
    void *c;
    void *workspace;
    void *tiling;
};

#ifdef MATMUL_USE_ASCENDC_STUB
extern "C" uint32_t aclrtlaunch_matmul_search_fp16_nn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp16_tn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp16_nt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp16_tt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_bf16_nn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_bf16_tn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_bf16_nt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_bf16_tt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp32_nn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp32_tn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp32_nt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_fp32_tt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_int8_nn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_int8_tn(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_int8_nt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);
extern "C" uint32_t aclrtlaunch_matmul_search_int8_tt(uint32_t blockDim, void *stream, void *a, void *b, void *c,
                                                      void *workspace, void *tiling);

using KernelLaunchFn = uint32_t (*)(uint32_t, void *, void *, void *, void *, void *, void *);
#endif

void CheckAcl(aclError rc, const std::string &operation)
{
    if (rc != ACL_SUCCESS) {
        std::string message = operation + " failed, rc=" + std::to_string(rc);
        const char *recentError = aclGetRecentErrMsg();
        if (recentError != nullptr && recentError[0] != '\0') {
            std::string detail(recentError);
            std::replace(detail.begin(), detail.end(), '\n', ' ');
            std::replace(detail.begin(), detail.end(), '\r', ' ');
            if (detail.size() > 1024) {
                detail.resize(1024);
            }
            message += ", acl_detail=" + detail;
        }
        throw std::runtime_error(message);
    }
}

void LogCandidateStage(const CandidateRow &row, const std::string &stage)
{
    std::cout << "candidate_stage " << row.workloadId
              << " rank=" << row.rank
              << " stage=" << stage
              << std::endl;
}

std::vector<std::string> SplitCsv(const std::string &line)
{
    std::vector<std::string> fields;
    std::string current;
    bool quoted = false;
    for (size_t i = 0; i < line.size(); ++i) {
        const char ch = line[i];
        if (ch == '"') {
            if (quoted && i + 1 < line.size() && line[i + 1] == '"') {
                current.push_back('"');
                ++i;
            } else {
                quoted = !quoted;
            }
        } else if (ch == ',' && !quoted) {
            fields.push_back(current);
            current.clear();
        } else {
            current.push_back(ch);
        }
    }
    fields.push_back(current);
    return fields;
}

std::string EscapeCsv(const std::string &value)
{
    if (value.find_first_of(",\"\n\r") == std::string::npos) {
        return value;
    }
    std::string out = "\"";
    for (char ch : value) {
        out += ch == '"' ? "\"\"" : std::string(1, ch);
    }
    out += '"';
    return out;
}

bool ParseBool(const std::string &value)
{
    return value == "1" || value == "true" || value == "TRUE" || value == "yes";
}

std::string GetField(const std::vector<std::string> &fields,
                     const std::unordered_map<std::string, size_t> &columns,
                     const std::string &name,
                     const std::string &fallback = "")
{
    const auto it = columns.find(name);
    if (it == columns.end() || it->second >= fields.size()) {
        return fallback;
    }
    return fields[it->second];
}

std::vector<CandidateRow> LoadCandidates(const std::string &path, const Options &options)
{
    std::ifstream input(path);
    if (!input) {
        throw std::runtime_error("cannot open candidate CSV: " + path);
    }
    std::string line;
    if (!std::getline(input, line)) {
        throw std::runtime_error("candidate CSV is empty");
    }
    const auto header = SplitCsv(line);
    std::unordered_map<std::string, size_t> columns;
    for (size_t i = 0; i < header.size(); ++i) {
        columns[header[i]] = i;
    }
    for (const char *required : {"rank", "workload_id", "source", "candidate_role",
                                 "m", "n", "k", "dtype", "trans_a", "trans_b",
                                 "execution_mode", "used_core_num", "single_core_m", "single_core_n",
                                 "single_core_k", "tiling_bin"}) {
        if (columns.count(required) == 0) {
            throw std::runtime_error(std::string("candidate CSV missing column: ") + required);
        }
    }

    std::map<std::string, int32_t> acceptedPerWorkload;
    std::vector<CandidateRow> rows;
    while (std::getline(input, line)) {
        if (line.empty()) {
            continue;
        }
        const auto fields = SplitCsv(line);
        CandidateRow row;
        row.rank = std::stoi(GetField(fields, columns, "rank"));
        row.workloadId = GetField(fields, columns, "workload_id");
        row.source = GetField(fields, columns, "source");
        row.candidateRole = GetField(fields, columns, "candidate_role");
        row.m = std::stoll(GetField(fields, columns, "m"));
        row.n = std::stoll(GetField(fields, columns, "n"));
        row.k = std::stoll(GetField(fields, columns, "k"));
        row.dtype = GetField(fields, columns, "dtype");
        row.transA = ParseBool(GetField(fields, columns, "trans_a"));
        row.transB = ParseBool(GetField(fields, columns, "trans_b"));
        row.executionMode = GetField(fields, columns, "execution_mode");
        row.usedCoreNum = std::stoi(GetField(fields, columns, "used_core_num"));
        row.singleCoreM = std::stoi(GetField(fields, columns, "single_core_m"));
        row.singleCoreN = std::stoi(GetField(fields, columns, "single_core_n"));
        row.singleCoreK = std::stoi(GetField(fields, columns, "single_core_k"));
        row.hintSingleM = std::stoi(GetField(fields, columns, "candidate_single_core_m", "-1"));
        row.hintSingleN = std::stoi(GetField(fields, columns, "candidate_single_core_n", "-1"));
        row.hintSingleK = std::stoi(GetField(fields, columns, "candidate_single_core_k", "-1"));
        row.hintBaseM = std::stoi(GetField(fields, columns, "candidate_base_m", "-1"));
        row.hintBaseN = std::stoi(GetField(fields, columns, "candidate_base_n", "-1"));
        row.hintBaseK = std::stoi(GetField(fields, columns, "candidate_base_k", "-1"));
        row.officialBaseM = std::stoi(GetField(fields, columns, "base_m", "0"));
        row.officialBaseN = std::stoi(GetField(fields, columns, "base_n", "0"));
        row.officialBaseK = std::stoi(GetField(fields, columns, "base_k", "0"));
        row.officialCoreNum = std::stoi(GetField(fields, columns, "official_core_num", "0"));
        row.officialMDim = std::stoi(GetField(fields, columns, "official_m_dim", "0"));
        row.officialNDim = std::stoi(GetField(fields, columns, "official_n_dim", "0"));
        row.proxyTotal = std::stod(GetField(fields, columns, "proxy_total", "0"));
        row.tilingSignature = GetField(fields, columns, "tiling_signature");
        row.tilingBin = GetField(fields, columns, "tiling_bin");

        if (!options.onlyWorkload.empty() && row.workloadId != options.onlyWorkload) {
            continue;
        }
        if (options.onlyRank >= 0 && row.rank != options.onlyRank) {
            continue;
        }
        if (options.rankLimit > 0 && row.rank > options.rankLimit) {
            continue;
        }
        if (row.usedCoreNum <= 0 || row.tilingBin.empty()) {
            continue;
        }
        if (options.workloadLimit > 0 && acceptedPerWorkload.count(row.workloadId) == 0 &&
            static_cast<int32_t>(acceptedPerWorkload.size()) >= options.workloadLimit) {
            continue;
        }
        ++acceptedPerWorkload[row.workloadId];
        rows.push_back(std::move(row));
    }
    if (rows.empty()) {
        throw std::runtime_error("no candidates matched the requested filters");
    }
    return rows;
}

std::vector<uint8_t> ReadBinary(const std::string &path)
{
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    if (!input) {
        throw std::runtime_error("cannot open binary: " + path);
    }
    const std::streamsize size = input.tellg();
    if (size <= 0) {
        throw std::runtime_error("binary is empty: " + path);
    }
    input.seekg(0, std::ios::beg);
    std::vector<uint8_t> data(static_cast<size_t>(size));
    if (!input.read(reinterpret_cast<char *>(data.data()), size)) {
        throw std::runtime_error("failed to read binary: " + path);
    }
    return data;
}

int64_t CeilDiv(int64_t x, int64_t y)
{
    return y <= 0 ? 0 : (x + y - 1) / y;
}

void ValidateCandidateContract(const CandidateRow &row, const std::vector<uint8_t> &tilingBytes)
{
    const bool isBaseline = row.rank == 0;
    if (isBaseline != (row.candidateRole == "api_auto_baseline") ||
        isBaseline != (row.source == "official_default")) {
        throw std::runtime_error(
            "candidate rank/source/role disagree about API auto baseline identity");
    }
    if (!isBaseline && (row.rank < 1 || row.candidateRole != "searched")) {
        throw std::runtime_error("searched candidate must use rank >= 1 and role=searched");
    }
    if (tilingBytes.size() < sizeof(CubeTilingPrefix)) {
        throw std::runtime_error("tiling binary is smaller than TCubeTiling prefix: " + row.tilingBin);
    }
    CubeTilingPrefix tiling{};
    std::memcpy(&tiling, tilingBytes.data(), sizeof(tiling));
    if (tiling.usedCoreNum != row.usedCoreNum || tiling.m != row.m || tiling.n != row.n ||
        tiling.ka != row.k || tiling.kb != row.k || tiling.singleCoreM != row.singleCoreM ||
        tiling.singleCoreN != row.singleCoreN || tiling.singleCoreK != row.singleCoreK ||
        tiling.baseM != row.officialBaseM || tiling.baseN != row.officialBaseN ||
        tiling.baseK != row.officialBaseK) {
        throw std::runtime_error("candidate CSV and tiling binary disagree");
    }
    if (row.m <= 0 || row.n <= 0 || row.k <= 0 || row.usedCoreNum <= 0 ||
        row.singleCoreM <= 0 || row.singleCoreN <= 0 || row.singleCoreK <= 0) {
        throw std::runtime_error("candidate has a non-positive shape or core partition");
    }
    const int64_t kAlignment =
        row.dtype == "fp32" ? 8 : row.dtype == "int8" ? 32 : 16;
    if (row.m % 16 != 0 || row.n % 16 != 0 || row.k % kAlignment != 0) {
        throw std::runtime_error(
            "raw ND MDL kernel requires logical M/N/K Cube alignment");
    }

    const int64_t mParts = CeilDiv(row.m, row.singleCoreM);
    const int64_t nParts = CeilDiv(row.n, row.singleCoreN);
    const int64_t kParts = CeilDiv(row.k, row.singleCoreK);
    const int64_t mappedCores = mParts * nParts * kParts;
    if (row.executionMode == "base_iterate_all") {
        if (kParts != 1) {
            throw std::runtime_error("base_iterate_all candidate contains cross-core split-K");
        }
        if (mappedCores < row.usedCoreNum) {
            throw std::runtime_error("base_iterate_all launches more cores than logical M/N tiles");
        }
        return;
    }
    if (row.executionMode == "direct_atomic_split_k_fp32_nt") {
        if (row.dtype != "fp32" || row.transA || !row.transB || kParts <= 1) {
            throw std::runtime_error("direct atomic split-K candidate violates fp32/NT template contract");
        }
        if (mappedCores != row.usedCoreNum) {
            throw std::runtime_error("direct atomic split-K requires one logical tile per core");
        }
        return;
    }
    throw std::runtime_error("unsupported execution_mode: " + row.executionMode);
}

size_t CheckedBytes(int64_t x, int64_t y, size_t elementBytes, const char *name)
{
    if (x <= 0 || y <= 0) {
        throw std::runtime_error(std::string(name) + " has non-positive shape");
    }
    const unsigned long long product = static_cast<unsigned long long>(x) * static_cast<unsigned long long>(y);
    if (product > std::numeric_limits<size_t>::max() / elementBytes) {
        throw std::runtime_error(std::string(name) + " byte size overflow");
    }
    return static_cast<size_t>(product) * elementBytes;
}

size_t InputElementBytes(const std::string &dtype)
{
    if (dtype == "fp16" || dtype == "bf16") return 2;
    if (dtype == "fp32") return 4;
    if (dtype == "int8") return 1;
    throw std::runtime_error("unsupported dtype in NPU runner: " + dtype);
}

size_t OutputElementBytes(const std::string &dtype)
{
    return dtype == "int8" ? 4 : InputElementBytes(dtype);
}

uint16_t FloatToBfloat16(float value)
{
    uint32_t bits = 0;
    std::memcpy(&bits, &value, sizeof(bits));
    const uint32_t roundingBias = 0x7fffU + ((bits >> 16U) & 1U);
    return static_cast<uint16_t>((bits + roundingBias) >> 16U);
}

float Bfloat16ToFloat(uint16_t value)
{
    const uint32_t bits = static_cast<uint32_t>(value) << 16U;
    float out = 0.0F;
    std::memcpy(&out, &bits, sizeof(out));
    return out;
}

void FillOnes(std::vector<uint8_t> &buffer, const std::string &dtype)
{
    if (dtype == "int8") {
        std::fill(buffer.begin(), buffer.end(), static_cast<uint8_t>(1));
        return;
    }
    if (dtype == "fp16") {
        const aclFloat16 one = aclFloatToFloat16(1.0F);
        auto *values = reinterpret_cast<aclFloat16 *>(buffer.data());
        std::fill(values, values + buffer.size() / sizeof(*values), one);
        return;
    }
    if (dtype == "bf16") {
        const uint16_t one = FloatToBfloat16(1.0F);
        auto *values = reinterpret_cast<uint16_t *>(buffer.data());
        std::fill(values, values + buffer.size() / sizeof(*values), one);
        return;
    }
    if (dtype == "fp32") {
        auto *values = reinterpret_cast<float *>(buffer.data());
        std::fill(values, values + buffer.size() / sizeof(*values), 1.0F);
        return;
    }
    throw std::runtime_error("cannot create numeric preflight input for dtype: " + dtype);
}

double DecodeOutput(const uint32_t observed, const std::string &dtype)
{
    if (dtype == "int8") {
        int32_t value = 0;
        std::memcpy(&value, &observed, sizeof(value));
        return value;
    }
    if (dtype == "fp16") {
        aclFloat16 value = 0;
        std::memcpy(&value, &observed, sizeof(value));
        return aclFloat16ToFloat(value);
    }
    if (dtype == "bf16") {
        uint16_t value = 0;
        std::memcpy(&value, &observed, sizeof(value));
        return Bfloat16ToFloat(value);
    }
    if (dtype == "fp32") {
        float value = 0.0F;
        std::memcpy(&value, &observed, sizeof(value));
        return value;
    }
    throw std::runtime_error("cannot decode numeric preflight output for dtype: " + dtype);
}

double ExpectedOnesOutput(const int64_t k, const std::string &dtype)
{
    const float value = static_cast<float>(k);
    if (dtype == "fp16") {
        return aclFloat16ToFloat(aclFloatToFloat16(value));
    }
    if (dtype == "bf16") {
        return Bfloat16ToFloat(FloatToBfloat16(value));
    }
    return static_cast<double>(k);
}

std::string KernelName(const CandidateRow &row)
{
    std::string layoutTag;
    if (!row.transA && !row.transB) layoutTag = "nn";
    else if (row.transA && !row.transB) layoutTag = "tn";
    else if (!row.transA && row.transB) layoutTag = "nt";
    else layoutTag = "tt";
    return "matmul_search_" + row.dtype + "_" + layoutTag;
}

#ifdef MATMUL_USE_ASCENDC_STUB
KernelLaunchFn ResolveKernelLauncher(const CandidateRow &row)
{
    const std::string name = KernelName(row);
    if (name == "matmul_search_fp16_nn") return aclrtlaunch_matmul_search_fp16_nn;
    if (name == "matmul_search_fp16_tn") return aclrtlaunch_matmul_search_fp16_tn;
    if (name == "matmul_search_fp16_nt") return aclrtlaunch_matmul_search_fp16_nt;
    if (name == "matmul_search_fp16_tt") return aclrtlaunch_matmul_search_fp16_tt;
    if (name == "matmul_search_bf16_nn") return aclrtlaunch_matmul_search_bf16_nn;
    if (name == "matmul_search_bf16_tn") return aclrtlaunch_matmul_search_bf16_tn;
    if (name == "matmul_search_bf16_nt") return aclrtlaunch_matmul_search_bf16_nt;
    if (name == "matmul_search_bf16_tt") return aclrtlaunch_matmul_search_bf16_tt;
    if (name == "matmul_search_fp32_nn") return aclrtlaunch_matmul_search_fp32_nn;
    if (name == "matmul_search_fp32_tn") return aclrtlaunch_matmul_search_fp32_tn;
    if (name == "matmul_search_fp32_nt") return aclrtlaunch_matmul_search_fp32_nt;
    if (name == "matmul_search_fp32_tt") return aclrtlaunch_matmul_search_fp32_tt;
    if (name == "matmul_search_int8_nn") return aclrtlaunch_matmul_search_int8_nn;
    if (name == "matmul_search_int8_tn") return aclrtlaunch_matmul_search_int8_tn;
    if (name == "matmul_search_int8_nt") return aclrtlaunch_matmul_search_int8_nt;
    if (name == "matmul_search_int8_tt") return aclrtlaunch_matmul_search_int8_tt;
    throw std::runtime_error("unsupported generated kernel launcher: " + name);
}

aclError LaunchCandidateKernel(const CandidateRow &row, aclrtStream stream, const KernelArguments &args)
{
    const KernelLaunchFn launcher = ResolveKernelLauncher(row);
    return static_cast<aclError>(launcher(static_cast<uint32_t>(row.usedCoreNum), stream,
                                          args.a, args.b, args.c, args.workspace, args.tiling));
}
#endif

void ComputeStats(ProfileSummary &summary, int64_t m, int64_t n, int64_t k)
{
    if (summary.valuesMs.empty()) {
        return;
    }
    std::sort(summary.valuesMs.begin(), summary.valuesMs.end());
    summary.minimum = summary.valuesMs.front();
    summary.maximum = summary.valuesMs.back();
    summary.mean = std::accumulate(summary.valuesMs.begin(), summary.valuesMs.end(), 0.0) /
                   static_cast<double>(summary.valuesMs.size());
    const size_t count = summary.valuesMs.size();
    summary.median = count % 2 == 0
        ? 0.5 * (summary.valuesMs[count / 2 - 1] + summary.valuesMs[count / 2])
        : summary.valuesMs[count / 2];
    double variance = 0.0;
    for (double value : summary.valuesMs) {
        const double delta = value - summary.mean;
        variance += delta * delta;
    }
    summary.standardDeviation = std::sqrt(variance / static_cast<double>(count));
    const size_t p95Index = std::min(count - 1, static_cast<size_t>(std::ceil(0.95 * count) - 1));
    summary.p95 = summary.valuesMs[p95Index];
    const double operations = 2.0 * static_cast<double>(m) * static_cast<double>(n) * static_cast<double>(k);
    summary.tflops = summary.median > 0.0 ? operations / (summary.median * 1.0e9) : 0.0;
    summary.success = true;
}

ProfileSummary ProfileCandidate(const CandidateRow &row,
                                aclrtStream stream,
                                const Options &options,
                                std::ofstream &samplesOutput)
{
    ProfileSummary summary;
    try {
        LogCandidateStage(row, "shape_bytes");
        const size_t inputElementBytes = InputElementBytes(row.dtype);
        const size_t outputElementBytes = OutputElementBytes(row.dtype);
        const size_t aBytes = CheckedBytes(row.m, row.k, inputElementBytes, "A");
        const size_t bBytes = CheckedBytes(row.k, row.n, inputElementBytes, "B");
        const size_t cBytes = CheckedBytes(row.m, row.n, outputElementBytes, "C");
        const size_t workspaceBytes = static_cast<size_t>(std::max(1, options.workspaceMiB)) * 1024 * 1024;
        LogCandidateStage(row, "read_tiling");
        const auto tilingHost = ReadBinary(row.tilingBin);
        ValidateCandidateContract(row, tilingHost);

        LogCandidateStage(row, "device_malloc");
        DeviceBuffer a(aBytes);
        DeviceBuffer b(bBytes);
        DeviceBuffer c(cBytes);
        DeviceBuffer workspace(workspaceBytes);
        DeviceBuffer tiling(tilingHost.size());
        LogCandidateStage(row, "device_memset");
        const size_t numericLimit = static_cast<size_t>(
            std::max(0, options.numericPreflightMaxMiB)) * 1024 * 1024;
        const bool numericPreflight =
            numericLimit > 0 && aBytes <= numericLimit && bBytes <= numericLimit - aBytes &&
            row.k <= 60000;
        if (numericPreflight) {
            std::vector<uint8_t> aHost(aBytes);
            std::vector<uint8_t> bHost(bBytes);
            FillOnes(aHost, row.dtype);
            FillOnes(bHost, row.dtype);
            CheckAcl(aclrtMemcpy(a.ptr, a.bytes, aHost.data(), aHost.size(),
                                 ACL_MEMCPY_HOST_TO_DEVICE), "aclrtMemcpy numeric A");
            CheckAcl(aclrtMemcpy(b.ptr, b.bytes, bHost.data(), bHost.size(),
                                 ACL_MEMCPY_HOST_TO_DEVICE), "aclrtMemcpy numeric B");
            summary.preflightMode = "numeric_ones";
        } else {
            CheckAcl(aclrtMemset(a.ptr, a.bytes, 0, a.bytes), "aclrtMemset A");
            CheckAcl(aclrtMemset(b.ptr, b.bytes, 0, b.bytes), "aclrtMemset B");
            summary.preflightMode = "zero_coverage";
        }
        CheckAcl(aclrtMemset(c.ptr, c.bytes, 0x5a, c.bytes), "aclrtMemset C poison");
        CheckAcl(aclrtMemset(workspace.ptr, workspace.bytes, 0, workspace.bytes), "aclrtMemset workspace");
        LogCandidateStage(row, "copy_tiling");
        CheckAcl(aclrtMemcpy(tiling.ptr, tiling.bytes, tilingHost.data(), tilingHost.size(),
                             ACL_MEMCPY_HOST_TO_DEVICE), "aclrtMemcpy tiling");

        KernelArguments args{a.ptr, b.ptr, c.ptr, workspace.ptr, tiling.ptr};
        LogCandidateStage(row, "preflight_launch");
        CheckAcl(LaunchCandidateKernel(row, stream, args), "preflight matmul_search launch");
        LogCandidateStage(row, "preflight_sync");
        CheckAcl(aclrtSynchronizeStream(stream), "preflight aclrtSynchronizeStream");

        std::set<int64_t> sampleIndices{0, row.n - 1, (row.m - 1) * row.n,
                                        row.m * row.n - 1, (row.m * row.n) / 2};
        sampleIndices.insert(std::min(row.m - 1, static_cast<int64_t>(row.singleCoreM)) * row.n);
        sampleIndices.insert(std::min(row.n - 1, static_cast<int64_t>(row.singleCoreN)));
        for (int64_t index : sampleIndices) {
            uint32_t observed = 0;
            auto *source = static_cast<uint8_t *>(c.ptr) + static_cast<size_t>(index) * outputElementBytes;
            CheckAcl(aclrtMemcpy(&observed, outputElementBytes, source, outputElementBytes,
                                 ACL_MEMCPY_DEVICE_TO_HOST), "aclrtMemcpy preflight C sample");
            if (numericPreflight) {
                const double actual = DecodeOutput(observed, row.dtype);
                const double expected = ExpectedOnesOutput(row.k, row.dtype);
                const double tolerance = row.dtype == "int8" ? 0.0 :
                    std::max(0.03, std::abs(expected) * 0.01);
                if (!std::isfinite(actual) || std::abs(actual - expected) > tolerance) {
                    throw std::runtime_error("numeric preflight failed at C index=" +
                        std::to_string(index) + ", actual=" + std::to_string(actual) +
                        ", expected=" + std::to_string(expected));
                }
            } else {
                const auto *bytes = reinterpret_cast<const uint8_t *>(&observed);
                for (size_t byte = 0; byte < outputElementBytes; ++byte) {
                    if (bytes[byte] != 0) {
                        throw std::runtime_error("preflight output coverage failed at C index=" +
                                                 std::to_string(index));
                    }
                }
            }
        }
        summary.preflightPassed = true;
        CheckAcl(aclrtMemset(c.ptr, c.bytes, 0, c.bytes), "aclrtMemset C after preflight");

        LogCandidateStage(row, "warmup_launch");
        for (int32_t i = 0; i < options.warmup; ++i) {
            if (options.stageLogInterval > 0 && (i == 0 || i + 1 == options.warmup || i % options.stageLogInterval == 0)) {
                LogCandidateStage(row, "warmup_" + std::to_string(i + 1) + "_of_" + std::to_string(options.warmup));
            }
            CheckAcl(LaunchCandidateKernel(row, stream, args), "warmup matmul_search launch");
        }
        LogCandidateStage(row, "warmup_sync");
        CheckAcl(aclrtSynchronizeStream(stream), "warmup aclrtSynchronizeStream");

        aclrtEvent start = nullptr;
        aclrtEvent end = nullptr;
        LogCandidateStage(row, "create_events");
        CheckAcl(aclrtCreateEvent(&start), "aclrtCreateEvent start");
        try {
            CheckAcl(aclrtCreateEvent(&end), "aclrtCreateEvent end");
            for (int32_t sample = 0; sample < options.samples; ++sample) {
                LogCandidateStage(row, "sample_" + std::to_string(sample) + "_record_start");
                CheckAcl(aclrtRecordEvent(start, stream), "aclrtRecordEvent start");
                LogCandidateStage(row, "sample_" + std::to_string(sample) + "_launch_repeat");
                for (int32_t r = 0; r < options.repeat; ++r) {
                    if (options.repeatStageInterval > 0 &&
                        (r == 0 || r + 1 == options.repeat || r % options.repeatStageInterval == 0)) {
                        LogCandidateStage(row, "sample_" + std::to_string(sample) +
                                               "_repeat_" + std::to_string(r + 1) +
                                               "_of_" + std::to_string(options.repeat));
                    }
                    CheckAcl(LaunchCandidateKernel(row, stream, args), "matmul_search launch");
                }
                LogCandidateStage(row, "sample_" + std::to_string(sample) + "_record_end");
                CheckAcl(aclrtRecordEvent(end, stream), "aclrtRecordEvent end");
                LogCandidateStage(row, "sample_" + std::to_string(sample) + "_sync_event");
                CheckAcl(aclrtSynchronizeEvent(end), "aclrtSynchronizeEvent end");
                float batchMs = 0.0F;
                LogCandidateStage(row, "sample_" + std::to_string(sample) + "_elapsed_time");
                CheckAcl(aclrtEventElapsedTime(&batchMs, start, end), "aclrtEventElapsedTime");
                const double perKernelMs = static_cast<double>(batchMs) / std::max(1, options.repeat);
                summary.valuesMs.push_back(perKernelMs);
                samplesOutput << EscapeCsv(row.workloadId) << ',' << row.rank << ',' << sample << ','
                              << std::setprecision(12) << perKernelMs << '\n';
                samplesOutput.flush();
                LogCandidateStage(row, "sample_" + std::to_string(sample) + "_done");
            }
            LogCandidateStage(row, "destroy_events");
            aclrtDestroyEvent(end);
            aclrtDestroyEvent(start);
        } catch (...) {
            if (end != nullptr) aclrtDestroyEvent(end);
            if (start != nullptr) aclrtDestroyEvent(start);
            throw;
        }
        LogCandidateStage(row, "compute_stats");
        ComputeStats(summary, row.m, row.n, row.k);
    } catch (const std::exception &ex) {
        summary.error = ex.what();
    }
    return summary;
}

std::unordered_map<std::string, std::string> ParseArgs(int argc, char **argv)
{
    std::unordered_map<std::string, std::string> args;
    for (int i = 1; i < argc; ++i) {
        const std::string key = argv[i];
        if (key == "--help" || key == "-h") {
            args[key] = "1";
            continue;
        }
        if (key == "--acl-only" || key == "--validate-candidates") {
            args[key] = "1";
            continue;
        }
        if (key.rfind("--", 0) != 0 || i + 1 >= argc) {
            throw std::runtime_error("invalid argument: " + key);
        }
        args[key] = argv[++i];
    }
    return args;
}

std::string Get(const std::unordered_map<std::string, std::string> &args,
                const std::string &name, const std::string &fallback)
{
    const auto it = args.find(name);
    return it == args.end() ? fallback : it->second;
}

int32_t GetInt(const std::unordered_map<std::string, std::string> &args,
               const std::string &name, int32_t fallback)
{
    const auto it = args.find(name);
    return it == args.end() ? fallback : std::stoi(it->second);
}

void PrintUsage()
{
    std::cout
        << "npu_profile_runner [options]\n"
        << "  --candidates FILE      candidate CSV generated by host search\n"
        << "  --output FILE          aggregate profiling CSV\n"
        << "  --samples-output FILE  per-sample CSV\n"
        << "  --device N             device ID\n"
        << "  --warmup N             warmup launches per candidate\n"
        << "  --repeat N             launches measured inside each event pair\n"
        << "  --samples N            independent event measurements\n"
        << "  --rank-limit N         profile ranks 1..N per workload\n"
        << "  --only-rank N          profile exactly this rank\n"
        << "  --only-workload ID     profile one workload ID\n"
        << "  --workload-limit N     profile first N workload IDs\n"
        << "  --workspace-mib N      temporary workspace allocation\n"
        << "  --numeric-preflight-max-mib N  max combined A+B host input for all-ones correctness check\n"
        << "  --stage-log-interval N log every N warmup launches; 0 disables per-warmup stage logs\n"
        << "  --repeat-stage-interval N log every N measured repeat launches; 0 disables repeat stage logs\n"
        << "  --validate-candidates  validate CSV/binary execution contracts without ACL/NPU access\n"
        << "  --acl-only             run only aclInit/setDevice/getSocName in this linked runner\n";
}

int RunAclOnly(int32_t deviceId)
{
    std::cout << "acl-only runner check\n";
    std::cout << "device=" << deviceId << '\n';

    aclError rc = aclInit(nullptr);
    std::cout << "aclInit rc=" << rc << '\n';
    if (rc != ACL_SUCCESS) {
        return static_cast<int>(rc);
    }

    bool deviceSet = false;
    rc = aclrtSetDevice(deviceId);
    std::cout << "aclrtSetDevice rc=" << rc << '\n';
    if (rc != ACL_SUCCESS) {
        aclFinalize();
        return static_cast<int>(rc);
    }
    deviceSet = true;

    const char *soc = aclrtGetSocName();
    std::cout << "aclrtGetSocName=" << (soc == nullptr ? "<null>" : soc) << '\n';

    if (deviceSet) {
        rc = aclrtResetDevice(deviceId);
        std::cout << "aclrtResetDevice rc=" << rc << '\n';
    }
    rc = aclFinalize();
    std::cout << "aclFinalize rc=" << rc << '\n';
    return 0;
}

}  // namespace

int main(int argc, char **argv)
{
    try {
        const auto args = ParseArgs(argc, argv);
        if (args.count("--help") || args.count("-h")) {
            PrintUsage();
            return 0;
        }
        Options options;
        options.candidatesCsv = Get(args, "--candidates", options.candidatesCsv);
        options.outputCsv = Get(args, "--output", options.outputCsv);
        options.samplesCsv = Get(args, "--samples-output", options.samplesCsv);
        options.deviceId = GetInt(args, "--device", options.deviceId);
        options.warmup = GetInt(args, "--warmup", options.warmup);
        options.repeat = GetInt(args, "--repeat", options.repeat);
        options.samples = GetInt(args, "--samples", options.samples);
        options.rankLimit = GetInt(args, "--rank-limit", options.rankLimit);
        options.onlyRank = GetInt(args, "--only-rank", options.onlyRank);
        options.onlyWorkload = Get(args, "--only-workload", options.onlyWorkload);
        options.workloadLimit = GetInt(args, "--workload-limit", options.workloadLimit);
        options.workspaceMiB = GetInt(args, "--workspace-mib", options.workspaceMiB);
        options.numericPreflightMaxMiB =
            GetInt(args, "--numeric-preflight-max-mib", options.numericPreflightMaxMiB);
        options.stageLogInterval = GetInt(args, "--stage-log-interval", options.stageLogInterval);
        options.repeatStageInterval = GetInt(args, "--repeat-stage-interval", options.repeatStageInterval);
        if (args.count("--acl-only")) {
            return RunAclOnly(options.deviceId);
        }
        if (options.repeat <= 0 || options.samples <= 0 || options.warmup < 0) {
            throw std::runtime_error("warmup/repeat/samples values are invalid");
        }

        const auto rows = LoadCandidates(options.candidatesCsv, options);
        for (const auto &row : rows) {
            ValidateCandidateContract(row, ReadBinary(row.tilingBin));
        }
        if (args.count("--validate-candidates")) {
            std::cout << "candidate contracts passed: " << rows.size() << '\n';
            return 0;
        }
        const auto outputParent = std::filesystem::path(options.outputCsv).parent_path();
        const auto samplesParent = std::filesystem::path(options.samplesCsv).parent_path();
        if (!outputParent.empty()) std::filesystem::create_directories(outputParent);
        if (!samplesParent.empty()) std::filesystem::create_directories(samplesParent);
        std::ofstream output(options.outputCsv);
        std::ofstream samplesOutput(options.samplesCsv);
        if (!output || !samplesOutput) {
            throw std::runtime_error("cannot create profiling CSV output");
        }
        output << "workload_id,rank,source,candidate_role,m,n,k,dtype,trans_a,trans_b,execution_mode,used_core_num,"
                  "hint_single_core_m,hint_single_core_n,hint_single_core_k,"
                  "hint_base_m,hint_base_n,hint_base_k,official_base_m,official_base_n,official_base_k,"
                  "official_core_num,official_m_dim,official_n_dim,"
                  "proxy_total,success,preflight_passed,preflight_mode,error,"
                  "min_ms,mean_ms,median_ms,stddev_ms,p95_ms,max_ms,tflops,"
                  "warmup,repeat,samples,tiling_signature,tiling_bin\n";
        samplesOutput << "workload_id,rank,sample,latency_ms\n";

        bool aclInitialized = false;
        bool deviceSet = false;
        aclrtContext context = nullptr;
        aclrtStream stream = nullptr;
        try {
            CheckAcl(aclInit(nullptr), "aclInit");
            aclInitialized = true;
            CheckAcl(aclrtSetDevice(options.deviceId), "aclrtSetDevice");
            deviceSet = true;
            CheckAcl(aclrtCreateContext(&context, options.deviceId), "aclrtCreateContext");
            CheckAcl(aclrtCreateStream(&stream), "aclrtCreateStream");

            for (size_t index = 0; index < rows.size(); ++index) {
                const CandidateRow &row = rows[index];
                std::cout << '[' << (index + 1) << '/' << rows.size() << "] " << row.workloadId
                          << " rank=" << row.rank << " role=" << row.candidateRole
                          << " M=" << row.m << " N=" << row.n << " K=" << row.k
                          << " cores=" << row.usedCoreNum << std::endl;
                std::cout << "candidate_tiling " << row.workloadId
                          << " rank=" << row.rank
                          << " mode=" << row.executionMode
                          << " single_hint=" << row.hintSingleM << 'x' << row.hintSingleN << 'x'
                          << row.hintSingleK
                          << " hint=" << row.hintBaseM << 'x' << row.hintBaseN << 'x' << row.hintBaseK
                          << " official=" << row.officialBaseM << 'x' << row.officialBaseN << 'x' << row.officialBaseK
                          << " signature=" << row.tilingSignature
                          << " bin=" << row.tilingBin
                          << std::endl;
                const ProfileSummary summary = ProfileCandidate(row, stream, options, samplesOutput);
                output << EscapeCsv(row.workloadId) << ',' << row.rank << ','
                       << EscapeCsv(row.source) << ',' << EscapeCsv(row.candidateRole) << ','
                       << row.m << ',' << row.n << ',' << row.k
                       << ',' << row.dtype << ',' << row.transA << ',' << row.transB << ','
                       << row.executionMode << ',' << row.usedCoreNum << ','
                       << row.hintSingleM << ',' << row.hintSingleN << ',' << row.hintSingleK << ','
                       << row.hintBaseM << ',' << row.hintBaseN << ',' << row.hintBaseK << ','
                       << row.officialBaseM << ',' << row.officialBaseN << ',' << row.officialBaseK << ','
                       << row.officialCoreNum << ',' << row.officialMDim << ',' << row.officialNDim << ','
                       << std::setprecision(12) << row.proxyTotal << ',' << summary.success << ','
                       << summary.preflightPassed << ',' << summary.preflightMode << ','
                       << EscapeCsv(summary.error) << ','
                       << summary.minimum << ',' << summary.mean << ','
                       << summary.median << ',' << summary.standardDeviation << ',' << summary.p95 << ','
                       << summary.maximum << ',' << summary.tflops << ',' << options.warmup << ','
                       << options.repeat << ',' << options.samples << ',' << EscapeCsv(row.tilingSignature) << ','
                       << EscapeCsv(row.tilingBin) << '\n';
                output.flush();
                samplesOutput.flush();
                std::cout << "candidate_done " << row.workloadId
                          << " rank=" << row.rank
                          << " success=" << summary.success
                          << " median_ms=" << std::setprecision(12) << summary.median;
                if (!summary.success) {
                    std::cout << " reason=" << summary.error;
                }
                std::cout << std::endl;
                if (!summary.success) {
                    throw std::runtime_error("profiling aborted at " + row.workloadId + " rank=" +
                                             std::to_string(row.rank) + ": " + summary.error);
                }
            }

            CheckAcl(aclrtSynchronizeStream(stream), "final aclrtSynchronizeStream");
            if (stream != nullptr) {
                aclrtDestroyStream(stream);
                stream = nullptr;
            }
            if (context != nullptr) {
                aclrtDestroyContext(context);
                context = nullptr;
            }
            aclrtResetDevice(options.deviceId);
            deviceSet = false;
            aclFinalize();
            aclInitialized = false;
        } catch (...) {
            if (stream != nullptr) aclrtDestroyStream(stream);
            if (context != nullptr) aclrtDestroyContext(context);
            if (deviceSet) aclrtResetDevice(options.deviceId);
            if (aclInitialized) aclFinalize();
            throw;
        }
        std::cout << "aggregate CSV: " << options.outputCsv << '\n'
                  << "sample CSV: " << options.samplesCsv << '\n';
        return 0;
    } catch (const std::exception &ex) {
        std::cerr << "fatal: " << ex.what() << '\n';
        return 1;
    }
}

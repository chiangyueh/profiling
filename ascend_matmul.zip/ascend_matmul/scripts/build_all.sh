#!/usr/bin/env bash
set -eo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

source "$ROOT/scripts/env.sh"

if [[ "${BUILD_MEMORY_KIB:-0}" -gt 0 ]]; then
    ulimit -v "${BUILD_MEMORY_KIB}"
fi

ARCH="$(uname -m)"
PLATFORM_ROOT="$CANN_ROOT/${ARCH}-linux"
CANN_INCLUDE="$PLATFORM_ROOT/include"
CANN_LIB="$PLATFORM_ROOT/lib64"
HOST_TILING_INCLUDE="$CANN_INCLUDE/ascendc/host_api/tiling"
HOST_HIGHLEVEL_INCLUDE="$CANN_INCLUDE/ascendc/highlevel_api"
ASCENDC_INCLUDE="$PLATFORM_ROOT/ascendc/include"
BISHENG="${BISHENG:-}"
if [[ -z "$BISHENG" ]]; then
    if [[ -x "$CANN_ROOT/tools/ccec_compiler/bin/bisheng" ]]; then
        BISHENG="$CANN_ROOT/tools/ccec_compiler/bin/bisheng"
    elif [[ -x "$CANN_ROOT/compiler/ccec_compiler/bin/bisheng" ]]; then
        BISHENG="$CANN_ROOT/compiler/ccec_compiler/bin/bisheng"
    else
        BISHENG="$(command -v bisheng || true)"
    fi
fi

if [[ ! -x "$BISHENG" ]]; then
    echo "bisheng not found: $BISHENG" >&2
    exit 1
fi

ASCENDC_SOC_VERSION="${ASCENDC_SOC_VERSION:-${SOC_VERSION:-Ascend910B}}"
case "${ASCENDC_SOC_VERSION}" in
    Ascend910B1|Ascend910B2|Ascend910B2C|Ascend910B3|Ascend910B4|Ascend910B4-1)
        ;;
    *)
        echo "ASCENDC_SOC_VERSION must be an exact Ascend910B submodel for NPU build." >&2
        echo "Detected/provided value: ${ASCENDC_SOC_VERSION}" >&2
        echo "Expected one of: Ascend910B1 Ascend910B2 Ascend910B2C Ascend910B3 Ascend910B4 Ascend910B4-1" >&2
        exit 2
        ;;
esac
echo "ASCENDC_SOC_VERSION=${ASCENDC_SOC_VERSION}"

COMMON_HOST=(
    -std=c++17 -O3 -DNDEBUG -Wall -Wextra -Wpedantic
    -I"$ROOT/host/include"
    -I"$ROOT/compat"
    -I"$HOST_TILING_INCLUDE"
    -I"$HOST_HIGHLEVEL_INCLUDE"
    -I"$CANN_INCLUDE"
)

HOST_SOURCES=(
    "$ROOT/host/src/search_types.cpp"
    "$ROOT/host/src/official_tiling.cpp"
    "$ROOT/host/src/proxy_model.cpp"
    "$ROOT/host/src/beam_lns_search.cpp"
    "$ROOT/host/src/csv_io.cpp"
    "$ROOT/host/src/main.cpp"
)

echo "[1/3] Building official-CANN tiling search host"
HOST_OBJ_DIR="$BUILD/host_obj"
mkdir -p "$HOST_OBJ_DIR"
: >"$BUILD/host_build.log"
HOST_OBJECTS=()
for source_file in "${HOST_SOURCES[@]}"; do
    object_file="$HOST_OBJ_DIR/$(basename "${source_file%.cpp}").o"
    g++ "${COMMON_HOST[@]}" -c "$source_file" -o "$object_file" \
        >>"$BUILD/host_build.log" 2>&1
    HOST_OBJECTS+=("$object_file")
done
g++ "${HOST_OBJECTS[@]}" \
    -L"$CANN_LIB" -Wl,-rpath,"$CANN_LIB" \
    -ltiling_api -lplatform -lregister -lgraph -lgraph_base \
    -lascendcl -lascendalog -lc_sec -ldl -lpthread \
    -o "$BUILD/matmul_tiling_search" \
    >>"$BUILD/host_build.log" 2>&1

echo "[2/3] Configuring AscendC host-stub NPU runner"
SOC_BUILD_NAME="$(printf '%s' "$ASCENDC_SOC_VERSION" | tr '[:upper:]' '[:lower:]' | tr -c '[:alnum:]' '_')"
NPU_BUILD="$BUILD/npu_cmake_${SOC_BUILD_NAME}"
if [[ -d "$NPU_BUILD" ]]; then
    find "$NPU_BUILD" -mindepth 1 -delete
fi
cmake -S "$ROOT/cmake_npu" -B "$NPU_BUILD" \
    -DASCEND_CANN_PACKAGE_PATH="$CANN_ROOT" \
    -DSOC_VERSION="${ASCENDC_SOC_VERSION}" \
    -DCMAKE_BUILD_TYPE=Release \
    >"$BUILD/kernel_build.log" 2>&1

echo "[3/3] Building AscendC host-stub and official MatMul runners"
cmake --build "$NPU_BUILD" --target npu_profile_runner official_matmul_runner --parallel "${BUILD_JOBS:-1}" \
    >>"$BUILD/kernel_build.log" 2>&1
cp "$NPU_BUILD/npu_profile_runner" "$BUILD/npu_profile_runner"
cp "$NPU_BUILD/official_matmul_runner" "$BUILD/official_matmul_runner"
: >"$BUILD/runner_build.log"

HOST_STUB="$NPU_BUILD/auto_gen/matmul_search_kernel/host_stub.cpp"
if [[ ! -f "$HOST_STUB" ]]; then
    echo "Generated AscendC host stub not found: $HOST_STUB" >&2
    exit 3
fi
if grep -Eq 'g_kernel_handle_aiv|matmul_search_.*_mix_aiv' "$HOST_STUB" ||
   strings "$BUILD/npu_profile_runner" | grep -Eq 'matmul_search_.*_mix_aiv'; then
    echo "MatMul kernel task-type check failed: generated runner contains AIV/MIX entry points." >&2
    echo "Every MatMul entry must declare KERNEL_TYPE_AIC_ONLY." >&2
    exit 3
fi
if ! grep -q 'g_kernel_handle_aic' "$HOST_STUB"; then
    echo "MatMul kernel task-type check failed: generated runner has no AIC handle." >&2
    exit 3
fi

file "$BUILD/matmul_tiling_search" "$BUILD/npu_profile_runner" "$BUILD/official_matmul_runner"
echo "Embedded AscendC kernel SoC markers:"
strings "$BUILD/npu_profile_runner" | grep -E '__ascend_kernel_ascend910|\\.ascend\\.kernel\\.ascend910' | sort -u | sed -n '1,20p' || true
echo "Kernel task type: AIC-only (no AIV/MIX entry points)"
echo "Build completed: $BUILD"

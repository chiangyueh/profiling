#!/usr/bin/env bash
set -eo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

source "$ROOT/scripts/env.sh"

if [[ "${BUILD_MEMORY_KIB:-0}" -gt 0 ]]; then
    ulimit -v "${BUILD_MEMORY_KIB}"
fi

ARCH="$(uname -m)"
PLATFORM_ROOT="$CANN_ROOT/${ARCH}-linux"
CANN_INCLUDE="$PLATFORM_ROOT/include"
CANN_LIB="$PLATFORM_ROOT/lib64"
HOST_TILING_INCLUDE="$CANN_INCLUDE/ascendc/host_api/tiling"
HOST_HIGHLEVEL_INCLUDE="$CANN_INCLUDE/ascendc/highlevel_api"

ASCENDC_SOC_VERSION="${ASCENDC_SOC_VERSION:-${SOC_VERSION:-Ascend910B}}"
echo "ASCENDC_SOC_VERSION=${ASCENDC_SOC_VERSION}"

COMMON_HOST=(
    -std=c++17 -O3 -DNDEBUG -Wall -Wextra -Wpedantic
    -I"$ROOT/host/include"
    -I"$ROOT/compat"
    -I"$HOST_TILING_INCLUDE"
    -I"$HOST_HIGHLEVEL_INCLUDE"
    -I"$CANN_INCLUDE"
)

HOST_SOURCES=(
    "$ROOT/host/src/search_types.cpp"
    "$ROOT/host/src/official_tiling.cpp"
    "$ROOT/host/src/proxy_model.cpp"
    "$ROOT/host/src/beam_lns_search.cpp"
    "$ROOT/host/src/csv_io.cpp"
    "$ROOT/host/src/main.cpp"
)

echo "[1/2] Building official-CANN tiling search host"
HOST_OBJ_DIR="$BUILD/host_obj"
mkdir -p "$HOST_OBJ_DIR"
: >"$BUILD/host_build.log"
HOST_OBJECTS=()
for source_file in "${HOST_SOURCES[@]}"; do
    object_file="$HOST_OBJ_DIR/$(basename "${source_file%.cpp}").o"
    g++ "${COMMON_HOST[@]}" -c "$source_file" -o "$object_file" \
        >>"$BUILD/host_build.log" 2>&1
    HOST_OBJECTS+=("$object_file")
done
g++ "${HOST_OBJECTS[@]}" \
    -L"$CANN_LIB" -Wl,-rpath,"$CANN_LIB" \
    -ltiling_api -lplatform -lregister -lgraph -lgraph_base \
    -lascendcl -lascendalog -lc_sec -ldl -lpthread \
    -o "$BUILD/matmul_tiling_search" \
    >>"$BUILD/host_build.log" 2>&1

echo "[2/2] Building official MatMulV3 runner and tuning-bank probe"
SOC_BUILD_NAME="$(printf '%s' "$ASCENDC_SOC_VERSION" | tr '[:upper:]' '[:lower:]' | tr -c '[:alnum:]' '_')"
NPU_BUILD="$BUILD/npu_cmake_${SOC_BUILD_NAME}"
if [[ -d "$NPU_BUILD" ]]; then
    find "$NPU_BUILD" -mindepth 1 -delete
fi
cmake -S "$ROOT/cmake_npu" -B "$NPU_BUILD" \
    -DASCEND_CANN_PACKAGE_PATH="$CANN_ROOT" \
    -DSOC_VERSION="${ASCENDC_SOC_VERSION}" \
    -DCMAKE_BUILD_TYPE=Release \
    >"$BUILD/kernel_build.log" 2>&1

cmake --build "$NPU_BUILD" --target official_matmul_runner tiling_bank_probe --parallel "${BUILD_JOBS:-1}" \
    >>"$BUILD/kernel_build.log" 2>&1
cp "$NPU_BUILD/official_matmul_runner" "$BUILD/official_matmul_runner"
cp "$NPU_BUILD/tiling_bank_probe" "$BUILD/tiling_bank_probe"
: >"$BUILD/runner_build.log"

file "$BUILD/matmul_tiling_search" "$BUILD/official_matmul_runner" "$BUILD/tiling_bank_probe"
echo "Build completed: $BUILD"

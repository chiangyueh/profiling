#!/usr/bin/env bash
set -eo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

source "$ROOT/scripts/env.sh"

ARCH="$(uname -m)"
PLATFORM_ROOT="$CANN_ROOT/${ARCH}-linux"
CANN_INCLUDE="$PLATFORM_ROOT/include"
CANN_LIB="$PLATFORM_ROOT/lib64"
HOST_TILING_INCLUDE="$CANN_INCLUDE/ascendc/host_api/tiling"
HOST_HIGHLEVEL_INCLUDE="$CANN_INCLUDE/ascendc/highlevel_api"
ASCENDC_INCLUDE="$PLATFORM_ROOT/ascendc/include"
BISHENG="${BISHENG:-}"
if [[ -z "$BISHENG" ]]; then
    if [[ -x "$CANN_ROOT/tools/ccec_compiler/bin/bisheng" ]]; then
        BISHENG="$CANN_ROOT/tools/ccec_compiler/bin/bisheng"
    elif [[ -x "$CANN_ROOT/compiler/ccec_compiler/bin/bisheng" ]]; then
        BISHENG="$CANN_ROOT/compiler/ccec_compiler/bin/bisheng"
    else
        BISHENG="$(command -v bisheng || true)"
    fi
fi

if [[ ! -x "$BISHENG" ]]; then
    echo "bisheng not found: $BISHENG" >&2
    exit 1
fi

ASCENDC_SOC_VERSION="${ASCENDC_SOC_VERSION:-${SOC_VERSION:-Ascend910B}}"
case "${ASCENDC_SOC_VERSION}" in
    Ascend910B1|Ascend910B2|Ascend910B2C|Ascend910B3|Ascend910B4|Ascend910B4-1)
        ;;
    *)
        echo "ASCENDC_SOC_VERSION must be an exact Ascend910B submodel for NPU build." >&2
        echo "Detected/provided value: ${ASCENDC_SOC_VERSION}" >&2
        echo "Expected one of: Ascend910B1 Ascend910B2 Ascend910B2C Ascend910B3 Ascend910B4 Ascend910B4-1" >&2
        exit 2
        ;;
esac
echo "ASCENDC_SOC_VERSION=${ASCENDC_SOC_VERSION}"

COMMON_HOST=(
    -std=c++17 -O3 -DNDEBUG -Wall -Wextra -Wpedantic
    -I"$ROOT/host/include"
    -I"$ROOT/compat"
    -I"$HOST_TILING_INCLUDE"
    -I"$HOST_HIGHLEVEL_INCLUDE"
    -I"$CANN_INCLUDE"
)

HOST_SOURCES=(
    "$ROOT/host/src/search_types.cpp"
    "$ROOT/host/src/official_tiling.cpp"
    "$ROOT/host/src/proxy_model.cpp"
    "$ROOT/host/src/beam_lns_search.cpp"
    "$ROOT/host/src/csv_io.cpp"
    "$ROOT/host/src/main.cpp"
)

echo "[1/3] Building official-CANN tiling search host"
g++ "${COMMON_HOST[@]}" "${HOST_SOURCES[@]}" \
    -L"$CANN_LIB" -Wl,-rpath,"$CANN_LIB" \
    -ltiling_api -lplatform -lregister -lgraph -lgraph_base \
    -lascendcl -lascendalog -lc_sec -ldl -lpthread \
    -o "$BUILD/matmul_tiling_search" \
    >"$BUILD/host_build.log" 2>&1

echo "[2/3] Configuring AscendC host-stub NPU runner"
cmake -E remove_directory "$BUILD/npu_cmake"
cmake -S "$ROOT/cmake_npu" -B "$BUILD/npu_cmake" \
    -DASCEND_CANN_PACKAGE_PATH="$CANN_ROOT" \
    -DSOC_VERSION="${ASCENDC_SOC_VERSION}" \
    -DCMAKE_BUILD_TYPE=Release \
    >"$BUILD/kernel_build.log" 2>&1

echo "[3/3] Building AscendC host-stub NPU runner"
cmake --build "$BUILD/npu_cmake" --target npu_profile_runner \
    >>"$BUILD/kernel_build.log" 2>&1
cp "$BUILD/npu_cmake/npu_profile_runner" "$BUILD/npu_profile_runner"
: >"$BUILD/runner_build.log"

file "$BUILD/matmul_tiling_search" "$BUILD/npu_profile_runner"
echo "Embedded AscendC kernel SoC markers:"
strings "$BUILD/npu_profile_runner" | grep -E '__ascend_kernel_ascend910|\\.ascend\\.kernel\\.ascend910' | sort -u | sed -n '1,20p' || true
echo "Build completed: $BUILD"

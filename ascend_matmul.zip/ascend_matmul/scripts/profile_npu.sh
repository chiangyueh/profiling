#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

CANDIDATES="${1:-results/candidates.csv}"
OUT_STEM="${2:-results/npu}"
PROFILE_CSV="${OUT_STEM}_profile.csv"
SAMPLES_CSV="${OUT_STEM}_samples.csv"
RANKED_CSV="${OUT_STEM}_ranked.csv"
BEST_CSV="${OUT_STEM}_best.csv"
COMPARISON_CSV="${OUT_STEM}_proxy_comparison.csv"
PROFILE_VERBOSE="${PROFILE_VERBOSE:-0}"
PROFILE_LIVE="${PROFILE_LIVE:-1}"
PROFILE_POLL_SEC="${PROFILE_POLL_SEC:-5}"
PROFILE_HEARTBEAT_SEC="${PROFILE_HEARTBEAT_SEC:-60}"
PROFILE_STALL_TIMEOUT_SEC="${PROFILE_STALL_TIMEOUT_SEC:-300}"
PROFILE_STAGE_LOG_INTERVAL="${PROFILE_STAGE_LOG_INTERVAL:-1}"
PROFILE_REPEAT_STAGE_INTERVAL="${PROFILE_REPEAT_STAGE_INTERVAL:-0}"
LOG_DIR="${ROOT}/results/logs"
ERROR_PATTERN='\[ERROR\]|RegisterAscendBinary|LaunchAscendKernel ret|fatal:|terminate|throwing|Aborted|(^|[^a-z])error([^a-z]|$)|failed|failure|aclrtBinaryLoadFromFile|rc=[0-9]+|exit_code|symbol lookup error|undefined symbol|not found|missing|No successful|invalid|cannot|Traceback|Exception'
mkdir -p "${LOG_DIR}"
RUNNER_LOG="${LOG_DIR}/$(basename "${OUT_STEM}")_runner_$(date +%Y%m%d_%H%M%S).log"
CSV_CHECK_LOG="${LOG_DIR}/$(basename "${OUT_STEM}")_csv_check_$(date +%Y%m%d_%H%M%S).log"

print_error_lines() {
    local log_file="$1"
    if [[ ! -s "${log_file}" ]]; then
        echo "  phase_log: ${log_file} (empty or missing)"
        return
    fi
    local matches
    matches="$(grep -Eai "${ERROR_PATTERN}" "${log_file}" | tail -40 || true)"
    if [[ -n "${matches}" ]]; then
        echo "${matches}"
    else
        echo "  no concise error lines found"
    fi
    if grep -Eaiq '(^|[^0-9])507008([^0-9]|$)' "${log_file}"; then
        echo "  hint: 507008 = ACL_ERROR_RT_SOC_VERSION (SoC version error)."
        echo "        Check CANN/runtime path and ASCENDC_SOC_VERSION for this card."
    fi
    echo "  phase_log: ${log_file}"
}

print_diag_summary() {
    local diag_file="$1"
    if [[ ! -s "${diag_file}" ]]; then
        echo "  runtime_diag: ${diag_file} (empty or missing)"
        return
    fi
    echo "  runtime_diag: ${diag_file}"
    grep -Eai '^(ASCEND_MATMUL_STRICT_ENV|CANN_ROOT|CANN_PLATFORM_ROOT|ASCEND_HOME_PATH|ASCEND_TOOLKIT_HOME|ASCEND_OPP_PATH|ASCEND_LATEST_INSTALL_PATH|ASCENDC_SOC_VERSION|DETECTED_|arch=|device_id=|exists:|missing:|npu_profile_runner|.*libascendcl|.*not found|npu-smi_rc=|symbol lookup error|undefined symbol|__ascend_kernel_|\\.ascend\\.kernel\\.)' "${diag_file}" \
        | head -80 || true
}

run_tool() {
    local label="$1"
    shift
    if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
        echo "+ $*"
        "$@"
    else
        "$@" >>"${RUNNER_LOG}" 2>&1
    fi
}

normalize_soc() {
    printf '%s\n' "$1" | tr '[:upper:]' '[:lower:]'
}

runner_soc_markers() {
    if [[ ! -x ./build/npu_profile_runner ]]; then
        return 1
    fi
    strings ./build/npu_profile_runner 2>/dev/null \
        | tr '[:upper:]' '[:lower:]' \
        | grep -Eo 'ascend910b(4-1|2c|[1234])' \
        | sort -u
}

preflight_runner_soc() {
    local expected="${ASCENDC_SOC_VERSION:-${DETECTED_NPU_SOC:-}}"
    local markers
    markers="$(runner_soc_markers || true)"
    if [[ -z "${expected}" ]]; then
        echo "warning: ASCENDC_SOC_VERSION is unset before profiling; continuing to ACL runtime"
        return 0
    fi
    if [[ -z "${markers}" ]]; then
        echo "warning: cannot find exact embedded AscendC SoC marker in build/npu_profile_runner; continuing to ACL runtime"
        return 0
    fi
    expected="$(normalize_soc "${expected}")"
    if ! grep -Fxq "${expected}" <<<"${markers}"; then
        echo "warning: runner SoC marker mismatch"
        echo "  ASCENDC_SOC_VERSION=${ASCENDC_SOC_VERSION:-<unset>}"
        echo "  DETECTED_NPU_SOC=${DETECTED_NPU_SOC:-<unset>}"
        echo "  runner_markers=${markers//$'\n'/,}"
        echo "  continuing to ACL runtime because aclrtGetSocName is the authoritative check."
        if [[ "${ASCEND_MATMUL_ENFORCE_SOC_MARKER:-0}" == "1" ]]; then
            echo "fatal: ASCEND_MATMUL_ENFORCE_SOC_MARKER=1 requested strict marker enforcement"
            return 10
        fi
        return 0
    fi
    if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
        echo "  runner_soc: ${expected}"
    fi
}

if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    echo "profile_npu"
    echo "  candidates: ${CANDIDATES}"
    echo "  output:     ${PROFILE_CSV}"
    echo "  samples:    ${SAMPLES_CSV}"
    echo "  device:     ${DEVICE_ID:-0}"
    echo "  rank_limit: ${RANK_LIMIT:-20}"
    echo "  warmup:     ${WARMUP:-10}"
    echo "  repeat:     ${REPEAT:-50}"
    echo "  samples_n:  ${SAMPLES:-15}"
    echo "  workspace:  ${WORKSPACE_MIB:-64} MiB"
fi

preflight_runner_soc

csv_data_rows() {
    local path="$1"
    if [[ -s "$path" ]]; then
        local lines
        lines="$(wc -l <"$path" 2>/dev/null || echo 0)"
        if [[ "$lines" -gt 0 ]]; then
            echo $((lines - 1))
        else
            echo 0
        fi
    else
        echo 0
    fi
}

latest_progress_line() {
    if [[ -s "$RUNNER_LOG" ]]; then
        grep -E '^\[[0-9]+/[0-9]+\]' "$RUNNER_LOG" | tail -1 || true
    fi
}

latest_stage_line() {
    if [[ -s "$RUNNER_LOG" ]]; then
        grep -E '^candidate_stage ' "$RUNNER_LOG" | tail -1 || true
    fi
}

latest_tiling_line() {
    if [[ -s "$RUNNER_LOG" ]]; then
        grep -E '^candidate_tiling ' "$RUNNER_LOG" | tail -1 || true
    fi
}

latest_error_lines() {
    if [[ -s "$RUNNER_LOG" ]]; then
        grep -Eai "$ERROR_PATTERN" "$RUNNER_LOG" | tail -8 || true
    fi
}

print_profile_heartbeat() {
    local elapsed="$1"
    local progress="$2"
    local stage="${3:-}"
    local tiling="${4:-}"
    local profile_rows sample_rows last_sample
    profile_rows="$(csv_data_rows "$PROFILE_CSV")"
    sample_rows="$(csv_data_rows "$SAMPLES_CSV")"
    last_sample=""
    if [[ -s "$SAMPLES_CSV" ]]; then
        last_sample="$(tail -1 "$SAMPLES_CSV" 2>/dev/null || true)"
    fi
    echo "  profile_heartbeat: elapsed=${elapsed}s profile_rows=${profile_rows} sample_rows=${sample_rows}"
    if [[ -n "$progress" ]]; then
        echo "    current: ${progress}"
    fi
    if [[ -n "$stage" ]]; then
        echo "    stage: ${stage}"
    fi
    if [[ -n "$tiling" ]]; then
        echo "    tiling: ${tiling}"
    fi
    if [[ -n "$last_sample" && "$last_sample" != "workload_id,rank,sample,latency_ms" ]]; then
        echo "    last_sample: ${last_sample}"
    fi
}

run_runner_with_live_progress() {
    local start_ts now last_heartbeat_ts last_progress progress errors last_errors stage last_stage tiling last_tiling
    local last_activity_ts activity_sig last_activity_sig
    start_ts="$(date +%s)"
    last_heartbeat_ts="$start_ts"
    last_activity_ts="$start_ts"
    last_progress=""
    last_stage=""
    last_tiling=""
    last_errors=""
    last_activity_sig=""

    "${runner_cmd[@]}" >"${RUNNER_LOG}" 2>&1 &
    local runner_pid=$!

    while kill -0 "$runner_pid" 2>/dev/null; do
        progress="$(latest_progress_line)"
        if [[ -n "$progress" && "$progress" != "$last_progress" ]]; then
            echo "  profile_progress: ${progress}"
            last_progress="$progress"
        fi

        stage="$(latest_stage_line)"
        if [[ -n "$stage" && "$stage" != "$last_stage" ]]; then
            echo "  profile_stage: ${stage}"
            last_stage="$stage"
        fi

        tiling="$(latest_tiling_line)"
        if [[ -n "$tiling" && "$tiling" != "$last_tiling" ]]; then
            echo "  profile_tiling: ${tiling}"
            last_tiling="$tiling"
        fi

        activity_sig="${progress}|${stage}|${tiling}|$(csv_data_rows "$PROFILE_CSV")|$(csv_data_rows "$SAMPLES_CSV")"
        if [[ "$activity_sig" != "$last_activity_sig" ]]; then
            last_activity_sig="$activity_sig"
            last_activity_ts="$(date +%s)"
        fi

        errors="$(latest_error_lines)"
        if [[ -n "$errors" && "$errors" != "$last_errors" ]]; then
            echo "  profile_error_preview:"
            echo "$errors" | sed 's/^/    /'
            last_errors="$errors"
        fi

        now="$(date +%s)"
        if (( now - last_heartbeat_ts >= PROFILE_HEARTBEAT_SEC )); then
            print_profile_heartbeat "$((now - start_ts))" "$progress" "$stage" "$tiling"
            last_heartbeat_ts="$now"
        fi
        if (( PROFILE_STALL_TIMEOUT_SEC > 0 && now - last_activity_ts >= PROFILE_STALL_TIMEOUT_SEC )); then
            echo "  profile_timeout: no progress for $((now - last_activity_ts))s"
            echo "  suspect=bad_tiling_or_kernel_launch"
            print_profile_heartbeat "$((now - start_ts))" "$progress" "$stage" "$tiling"
            echo "  action: terminating npu_profile_runner pid=${runner_pid}"
            kill -TERM "$runner_pid" 2>/dev/null || true
            sleep 5
            if kill -0 "$runner_pid" 2>/dev/null; then
                echo "  action: force killing npu_profile_runner pid=${runner_pid}"
                kill -KILL "$runner_pid" 2>/dev/null || true
            fi
            wait "$runner_pid" 2>/dev/null || true
            return 124
        fi
        sleep "$PROFILE_POLL_SEC"
    done

    wait "$runner_pid"
    local rc=$?
    progress="$(latest_progress_line)"
    stage="$(latest_stage_line)"
    tiling="$(latest_tiling_line)"
    if [[ -n "$progress" && "$progress" != "$last_progress" ]]; then
        echo "  profile_progress: ${progress}"
    fi
    now="$(date +%s)"
    print_profile_heartbeat "$((now - start_ts))" "$progress" "$stage" "$tiling"
    return "$rc"
}

runner_cmd=(
./build/npu_profile_runner
    --candidates "$CANDIDATES" \
    --output "${PROFILE_CSV}" \
    --samples-output "${SAMPLES_CSV}" \
    --device "${DEVICE_ID:-0}" \
    --warmup "${WARMUP:-10}" \
    --repeat "${REPEAT:-50}" \
    --samples "${SAMPLES:-15}" \
    --rank-limit "${RANK_LIMIT:-20}" \
    --workspace-mib "${WORKSPACE_MIB:-64}" \
    --stage-log-interval "${PROFILE_STAGE_LOG_INTERVAL}" \
    --repeat-stage-interval "${PROFILE_REPEAT_STAGE_INTERVAL}"
)

set +e
if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    echo "+ ${runner_cmd[*]}"
    "${runner_cmd[@]}" 2>&1 | tee "${RUNNER_LOG}"
    runner_rc=${PIPESTATUS[0]}
elif [[ "${PROFILE_LIVE}" == "1" ]]; then
    run_runner_with_live_progress
    runner_rc=$?
else
    "${runner_cmd[@]}" >"${RUNNER_LOG}" 2>&1
    runner_rc=$?
fi
set -e

if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    echo "npu_profile_runner exit_code=${runner_rc}"
fi

if [[ "${runner_rc}" -ne 0 ]]; then
    echo "npu_profile_runner failed"
    DIAG_LOG="${LOG_DIR}/$(basename "${OUT_STEM}")_runtime_diag_$(date +%Y%m%d_%H%M%S).log"
    "$ROOT/scripts/diagnose_runtime.sh" >"${DIAG_LOG}" 2>&1 || true
    print_error_lines "${RUNNER_LOG}"
    print_diag_summary "${DIAG_LOG}"
    exit "${runner_rc}"
fi

if grep -Eaiq '\\[ERROR\\]|RegisterAscendBinary|LaunchAscendKernel ret' "${RUNNER_LOG}"; then
    echo "npu_profile_runner reported AscendC launch/register error"
    print_error_lines "${RUNNER_LOG}"
    exit 5
fi

set +e
if [[ -s "${PROFILE_CSV}" ]]; then
    python3 - "$PROFILE_CSV" >"${CSV_CHECK_LOG}" 2>&1 <<'PY'
import csv
import sys
path = sys.argv[1]
with open(path, newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
print(f"rows={len(rows)}")
success = 0
for row in rows:
    ok = row.get("success") in {"1", "true", "True"}
    success += int(ok)
    if not ok:
        print(
            "failed_row "
            f"workload={row.get('workload_id')} rank={row.get('rank')} "
            f"error={row.get('error')}"
        )
print(f"success_rows={success}")
if rows and success == 0:
    sys.exit(3)
PY
    csv_rc=$?
else
    echo "Profile CSV was not created or is empty: ${PROFILE_CSV}" >"${CSV_CHECK_LOG}"
    csv_rc=4
fi
set -e

if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    cat "${CSV_CHECK_LOG}"
fi

if [[ "${csv_rc}" -ne 0 ]]; then
    echo "No successful NPU profiling rows; stop before ranking"
    print_error_lines "${CSV_CHECK_LOG}"
    exit "${csv_rc}"
fi

run_tool "rank" python3 tools/rank_npu_results.py \
    --input "${PROFILE_CSV}" \
    --output "${RANKED_CSV}" \
    --summary "${BEST_CSV}"

run_tool "compare" python3 tools/compare_proxy_npu.py \
    --candidates "$CANDIDATES" \
    --npu-results "${PROFILE_CSV}" \
    --output "${COMPARISON_CSV}"

echo "profile_npu completed: ${PROFILE_CSV}"

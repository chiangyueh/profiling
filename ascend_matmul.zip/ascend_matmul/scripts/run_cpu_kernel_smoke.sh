#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source "$ROOT/scripts/env.sh"

MODE="smoke"
if [[ $# -gt 0 ]]; then
    if [[ "$1" != "--mode" || $# -ne 2 ]]; then
        echo "usage: ./scripts/run_cpu_kernel_smoke.sh --mode smoke|full" >&2
        exit 2
    fi
    MODE="$2"
fi
if [[ "$MODE" != "smoke" && "$MODE" != "full" ]]; then
    echo "invalid mode: $MODE" >&2
    exit 2
fi

ulimit -v "${CPU_SMOKE_MEMORY_KIB:-655360}"
mkdir -p results/cpu_smoke build

prepare_dir() {
    local path="$1"
    mkdir -p "$path"
    find "$path" -mindepth 1 -delete
}

build_layout() {
    local layout="$1"
    local trans_a="$2"
    local trans_b="$3"
    local fp32="${4:-0}"
    local build_dir="build/cpu_smoke_${layout}"
    prepare_dir "$build_dir"
    cmake -S cpu_smoke -B "$build_dir" \
        -DCMAKE_BUILD_TYPE=Release \
        -DCPU_SMOKE_TRANS_A="$trans_a" \
        -DCPU_SMOKE_TRANS_B="$trans_b" \
        -DCPU_SMOKE_FP32="$fp32" \
        >"results/cpu_smoke/cmake_${layout}.log" 2>&1
    cmake --build "$build_dir" -j1 >"results/cpu_smoke/build_${layout}.log" 2>&1
}

run_case() {
    local id="$1"
    local layout="$2"
    local trans_a="$3"
    local trans_b="$4"
    local m="$5"
    local n="$6"
    local k="$7"
    local dtype="${8:-fp16}"
    local search_split_k=0
    if [[ "$dtype" == "fp32" && "$trans_a" == "0" && "$trans_b" == "1" ]]; then
        search_split_k=1
    fi
    local case_dir="results/cpu_smoke/${id}"
    prepare_dir "$case_dir"

    ./build/matmul_tiling_search \
        --id "$id" --m "$m" --n "$n" --k "$k" --dtype "$dtype" \
        --trans-a "$trans_a" --trans-b "$trans_b" --cores 24 \
        --beam-width 16 --tabu-iters 8 --lns-rounds 4 --top-k 1 \
        --max-core-rounds 4 \
        --max-base-m 256 --max-base-n 256 --max-base-k 256 --search-split-k "$search_split_k" \
        --soc "${SOC_VERSION:-Ascend910B}" \
        --output "$case_dir/candidates.csv" \
        --all-output "$case_dir/all.csv" \
        --tiling-dir "$case_dir/tilings" \
        >"$case_dir/search.log" 2>&1

    local tiling_bin
    local block_dim
    local execution_mode
    read -r tiling_bin block_dim execution_mode < <(
        python3 - "$case_dir/candidates.csv" <<'PY'
import csv
import sys

with open(sys.argv[1], newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
searched = [row for row in rows if row["candidate_role"] == "searched"]
if not searched:
    raise RuntimeError("search produced no searched candidate")
row = next(
    (row for row in searched
     if row["execution_mode"] == "direct_atomic_split_k_fp32_nt"),
    searched[0],
)
print(row["tiling_bin"], row["used_core_num"], row["execution_mode"])
PY
    )
    if [[ "$search_split_k" == "1" && "$execution_mode" != "direct_atomic_split_k_fp32_nt" ]]; then
        echo "expected a direct FP32 NT split-K candidate, got: $execution_mode" >&2
        return 1
    fi
    local tiling_abs
    tiling_abs="$(realpath "$tiling_bin")"
    if (
        cd "$case_dir"
        "$ROOT/build/cpu_smoke_${layout}/matmul_cpu_smoke" \
            "$tiling_abs" "$block_dim" "$m" "$n" "$k"
    ) >"$case_dir/cpu.log" 2>&1; then
        grep -E 'CANN CPU kernel smoke passed' "$case_dir/cpu.log" | tail -1
    else
        tail -80 "$case_dir/cpu.log" >&2
        return 1
    fi
    for generated_dir in "$case_dir/cceprint" "$case_dir/npuchk"; do
        if [[ -d "$generated_dir" ]]; then
            find "$generated_dir" -mindepth 1 -delete
            rmdir "$generated_dir"
        fi
    done
    find "$case_dir" -maxdepth 1 -type f -name 'stub_reg.log' -delete
}

prepare_dir results/cpu_smoke

build_layout nn 0 0 0
run_case fp16_nn_regular nn 0 0 256 256 256
run_case fp16_nn_aligned_tail nn 0 0 144 272 80

if [[ "$MODE" == "full" ]]; then
    build_layout tn 1 0 0
    run_case fp16_tn tn 1 0 144 272 80
    build_layout nt 0 1 0
    run_case fp16_nt nt 0 1 144 272 80
    build_layout tt 1 1 0
    run_case fp16_tt tt 1 1 144 272 80
    build_layout fp32_nt_splitk 0 1 1
    run_case fp32_nt_splitk fp32_nt_splitk 0 1 16 16 4096 fp32
fi

echo "CPU Debug numerical validation passed: mode=$MODE"

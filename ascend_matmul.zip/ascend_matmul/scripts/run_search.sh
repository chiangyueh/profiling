#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

WORKLOADS="${1:-config/workloads.csv}"
BEAM_WIDTH="${BEAM_WIDTH:-64}"
TABU_ITERS="${TABU_ITERS:-64}"
LNS_ROUNDS="${LNS_ROUNDS:-8}"
TOP_K="${TOP_K:-20}"
MAX_CORE_ROUNDS="${MAX_CORE_ROUNDS:-4}"
SEARCH_OUTPUT="${SEARCH_OUTPUT:-results/candidates.csv}"
SEARCH_ALL_OUTPUT="${SEARCH_ALL_OUTPUT:-results/all_evaluated.csv}"
SEARCH_TILING_DIR="${SEARCH_TILING_DIR:-results/tilings}"

./build/matmul_tiling_search \
    --workloads "$WORKLOADS" \
    --beam-width "$BEAM_WIDTH" \
    --tabu-iters "$TABU_ITERS" \
    --lns-rounds "$LNS_ROUNDS" \
    --top-k "$TOP_K" \
    --max-core-rounds "$MAX_CORE_ROUNDS" \
    --max-base-m 512 \
    --max-base-n 512 \
    --max-base-k 1024 \
    --search-split-k "${SEARCH_SPLIT_K:-1}" \
    --soc "${SOC_VERSION:-Ascend910B}" \
    --output "${SEARCH_OUTPUT}" \
    --all-output "${SEARCH_ALL_OUTPUT}" \
    --tiling-dir "${SEARCH_TILING_DIR}"

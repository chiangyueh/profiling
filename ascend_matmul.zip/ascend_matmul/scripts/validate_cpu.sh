#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source "$ROOT/scripts/env.sh"

SOC="${ASCENDC_SOC_VERSION:-${SOC_VERSION:-Ascend910B3}}"
WORK_DIR="$(mktemp -d "$ROOT/build/tiling_validate.XXXXXX")"
trap 'find "$WORK_DIR" -mindepth 1 -delete; rmdir "$WORK_DIR" 2>/dev/null || true' EXIT

if [[ "${SKIP_BUILD:-0}" != "1" ]]; then
    BUILD_JOBS="${BUILD_JOBS:-1}" ASCENDC_SOC_VERSION="$SOC" \
        SOC_VERSION="$SOC" ./scripts/build_all.sh
fi

ARCH="$(uname -m)"
CANN_INCLUDE="$CANN_ROOT/${ARCH}-linux/include"
g++ -std=c++17 -O2 -Wall -Wextra \
    -I"$ROOT/host/include" -I"$ROOT/compat" -I"$CANN_INCLUDE" \
    "$ROOT/tests/proxy_model_test.cpp" \
    "$ROOT/host/src/proxy_model.cpp" \
    "$ROOT/host/src/search_types.cpp" \
    -o "$WORK_DIR/proxy_model_test"
"$WORK_DIR/proxy_model_test"
python3 "$ROOT/tests/refine_model_test.py"
python3 "$ROOT/tests/rank_results_test.py"

GENERAL_CSV="$WORK_DIR/candidates.csv"
GENERAL_LOG="$WORK_DIR/search.log"
BEAM_WIDTH=16 TABU_ITERS=8 LNS_ROUNDS=2 TOP_K=4 \
    SEARCH_OUTPUT="$GENERAL_CSV" \
    SEARCH_ALL_OUTPUT="$WORK_DIR/all.csv" \
    SEARCH_TILING_DIR="$WORK_DIR/tilings" \
    ./scripts/run_search.sh config/workloads_validation.csv >"$GENERAL_LOG"

PLATFORM_LINE="$(sed -n '/^CANN platform=/{p;q;}' "$GENERAL_LOG")"
platform_field() {
    printf '%s\n' "$PLATFORM_LINE" |
        sed -n "s/.*[[:space:]]$1=\\([0-9][0-9.]*\\).*/\\1/p"
}
AIC_CORES="$(platform_field cores)"
L0A_BYTES="$(platform_field L0A)"
L0B_BYTES="$(platform_field L0B)"
L0C_BYTES="$(platform_field L0C)"
L1_BYTES="$(platform_field L1)"
test -n "$AIC_CORES"

python3 tools/profile_official_tilings.py \
    --runner build/official_matmul_runner \
    --bank-probe build/tiling_bank_probe \
    --candidates "$GENERAL_CSV" \
    --workloads config/workloads_validation.csv \
    --custom-output "$WORK_DIR/custom.csv" \
    --custom-samples-output "$WORK_DIR/custom_samples.csv" \
    --official-output "$WORK_DIR/official.csv" \
    --official-samples-output "$WORK_DIR/official_samples.csv" \
    --cann-root "$CANN_ROOT" \
    --soc "$SOC" \
    --aic-cores "$AIC_CORES" \
    --l0a-bytes "$L0A_BYTES" \
    --l0b-bytes "$L0B_BYTES" \
    --l0c-bytes "$L0C_BYTES" \
    --l1-bytes "$L1_BYTES" \
    --rank-limit 4 \
    --validate-only

python3 - "$GENERAL_CSV" <<'PY'
import csv
import sys
from collections import Counter

sys.path.insert(0, "tools")
import profile_official_tilings

with open(sys.argv[1], newline="", encoding="utf-8") as source:
    general = list(csv.DictReader(source))

ids = {row["workload_id"] for row in general}
assert "validation_skinny" in ids
assert "validation_skinny_n" in ids
assert "validation_trans_b" in ids
assert "validation_fp32_nt_splitk" in ids
assert "validation_int8" not in ids
assert all(row["valid"] == "1" for row in general)
assert len({
    (row["workload_id"], row["tiling_signature"]) for row in general
}) == len(general)
controls = [
    row for row in general
    if row.get("candidate_role") == "bank_seed_control"
]
assert len(controls) == 9
assert all(row["rank"] == "0" for row in controls)
assert all(len(row["callback_tiling_sha256"]) == 64 for row in controls)
skinny_control = next(
    row for row in controls
    if row["workload_id"] == "validation_skinny_n"
)
assert "baseBD:" in skinny_control["callback_derived_diff_vs_default"]
for row in general:
    if row.get("candidate_role") != "searched":
        continue
    assert len(row["callback_tiling_sha256"]) == 64
    assert float(row["search_model_cycles"]) > 0
    assert float(row["search_model_ratio_vs_bank_seed"]) > 0
    knowledge = profile_official_tilings.make_knowledge(row)
    assert knowledge["l2MTileCnt"] >= 1
    assert knowledge["l2NTileCnt"] >= 1
    assert knowledge["l2MTileBlock"] >= 1
    assert knowledge["l2NTileBlock"] >= 1
    m_blocks = -(-int(row["m"]) // knowledge["singleCoreM"])
    n_blocks = -(-int(row["n"]) // knowledge["singleCoreN"])
    m_tail = m_blocks - (knowledge["l2MTileCnt"] - 1) * knowledge["l2MTileBlock"]
    n_tail = n_blocks - (knowledge["l2NTileCnt"] - 1) * knowledge["l2NTileBlock"]
    assert 1 <= m_tail <= knowledge["l2MTileBlock"]
    assert 1 <= n_tail <= knowledge["l2NTileBlock"]
    if row["execution_mode"] == "base_iterate_all":
        assert int(row["single_core_m"]) == int(row["base_m"])
        assert int(row["single_core_n"]) == int(row["base_n"])
        assert int(row["candidate_traverse"]) == 0
        assert knowledge["tilingEnable"] % 10 == 0
    elif row["execution_mode"] == "deterministic_split_k":
        assert knowledge["tilingEnable"] % 10 == 3
        assert knowledge["baseM"] == knowledge["baseN"] == 128
        assert knowledge["singleCoreK"] == 3 * knowledge["baseK"]
    elif row["execution_mode"] == "direct_atomic_split_k_fp32_nt":
        assert knowledge["tilingEnable"] % 10 == 4
    else:
        raise AssertionError(row["execution_mode"])
fp32_nt = [
    row for row in general
    if row["workload_id"] == "validation_fp32_nt_splitk"
]
assert fp32_nt, "CANN callback produced no legal candidate for FP32 NT validation"
# CANN 8.1 rewrites the newer direct Split-K template to BASE for this shape.
# The search must reject that semantic rewrite rather than label mode 4 legal.
assert all(row["execution_mode"] == "base_iterate_all" for row in fp32_nt)
modes = Counter(row["execution_mode"] for row in general)
print(
    f"tiling_validation passed general={len(general)} "
    + " ".join(f"{mode}={count}" for mode, count in sorted(modes.items()))
)
PY

./build/official_matmul_runner \
    --candidates config/workloads_validation.csv \
    --validate-input

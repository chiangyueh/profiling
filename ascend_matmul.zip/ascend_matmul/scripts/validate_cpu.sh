#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ "${SKIP_BUILD:-0}" != "1" ]]; then
    ./scripts/build_all.sh
fi
BEAM_WIDTH=32 TABU_ITERS=24 LNS_ROUNDS=4 TOP_K=8 ./scripts/run_search.sh config/workloads_validation.csv

test -x build/matmul_tiling_search
test -x build/npu_profile_runner
test -s results/candidates.csv
test -s results/all_evaluated.csv
python3 - <<'PY'
import csv
import struct

with open("results/candidates.csv", newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
assert rows, "no executable candidates"
for row in rows:
    m, n, k = (int(row[name]) for name in ("m", "n", "k"))
    sm, sn, sk = (int(row[name]) for name in ("single_core_m", "single_core_n", "single_core_k"))
    parts = ((m + sm - 1) // sm) * ((n + sn - 1) // sn) * ((k + sk - 1) // sk)
    assert parts == int(row["used_core_num"])
    if row["execution_mode"] == "base_iterate_all":
        assert (k + sk - 1) // sk == 1
    elif row["execution_mode"] == "direct_atomic_split_k_fp32_nt":
        assert row["dtype"] == "fp32" and row["trans_a"] == "0" and row["trans_b"] == "1"
        assert (k + sk - 1) // sk > 1
    else:
        raise AssertionError("unsupported execution mode: " + row["execution_mode"])
    with open(row["tiling_bin"], "rb") as f:
        prefix = struct.unpack("11i", f.read(44))
    expected = (int(row["used_core_num"]), m, n, k, k, sm, sn, sk)
    assert prefix[:8] == expected

with open("results/all_evaluated.csv", newline="", encoding="utf-8") as f:
    evaluated = list(csv.DictReader(f))
unsafe = [row for row in evaluated if row["valid"] == "1" and
          row["dtype"] in {"fp16", "bf16", "int8"} and int(row["k_core_parts"]) > 1]
assert not unsafe, "non-fp32 direct split-K escaped the execution contract"
print(f"candidate contract validation passed: {len(rows)} rows")
PY
head -n 5 results/candidates.csv

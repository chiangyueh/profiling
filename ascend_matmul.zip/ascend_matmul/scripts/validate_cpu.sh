#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source "$ROOT/scripts/env.sh"

SOC="${ASCENDC_SOC_VERSION:-${SOC_VERSION:-Ascend910B3}}"
WORK_DIR="$(mktemp -d "$ROOT/build/tiling_validate.XXXXXX")"
trap 'find "$WORK_DIR" -mindepth 1 -delete; rmdir "$WORK_DIR" 2>/dev/null || true' EXIT

if [[ "${SKIP_BUILD:-0}" != "1" ]]; then
    ASCENDC_SOC_VERSION="$SOC" SOC_VERSION="$SOC" ./scripts/build_all.sh
fi

ARCH="$(uname -m)"
CANN_INCLUDE="$CANN_ROOT/${ARCH}-linux/include"
g++ -std=c++17 -O2 -Wall -Wextra \
    -I"$ROOT/host/include" -I"$ROOT/compat" -I"$CANN_INCLUDE" \
    "$ROOT/tests/proxy_model_test.cpp" \
    "$ROOT/host/src/proxy_model.cpp" \
    "$ROOT/host/src/search_types.cpp" \
    -o "$WORK_DIR/proxy_model_test"
"$WORK_DIR/proxy_model_test"

GENERAL_CSV="$WORK_DIR/candidates.csv"
GENERAL_LOG="$WORK_DIR/search.log"
./build/matmul_tiling_search \
    --workloads config/workloads_validation.csv \
    --beam-width 16 --tabu-iters 8 --lns-rounds 2 --top-k 2 \
    --max-core-rounds 4 --search-split-k 1 \
    --soc "$SOC" \
    --output "$GENERAL_CSV" \
    --all-output "$WORK_DIR/all.csv" \
    --tiling-dir "$WORK_DIR/tilings" \
    >"$GENERAL_LOG"

AIC_CORES="$(
    sed -n 's/^CANN platform=.* cores=\([0-9][0-9]*\).*$/\1/p' "$GENERAL_LOG" |
        head -1
)"
test -n "$AIC_CORES"

python3 tools/profile_official_tilings.py \
    --runner build/official_matmul_runner \
    --bank-probe build/tiling_bank_probe \
    --candidates "$GENERAL_CSV" \
    --workloads config/workloads_validation.csv \
    --custom-output "$WORK_DIR/custom.csv" \
    --custom-samples-output "$WORK_DIR/custom_samples.csv" \
    --official-output "$WORK_DIR/official.csv" \
    --official-samples-output "$WORK_DIR/official_samples.csv" \
    --cann-root "$CANN_ROOT" \
    --soc "$SOC" \
    --aic-cores "$AIC_CORES" \
    --rank-limit 2 \
    --validate-only

SPLIT_CSV="$WORK_DIR/split_candidates.csv"
./build/matmul_tiling_search \
    --id validation_fp32_nt_splitk \
    --m 16 --n 16 --k 4096 --dtype fp32 --trans-a 0 --trans-b 1 \
    --cores "$AIC_CORES" --soc "$SOC" \
    --beam-width 32 --tabu-iters 12 --lns-rounds 4 --top-k 4 \
    --max-core-rounds 2 --search-split-k 1 \
    --output "$SPLIT_CSV" \
    --all-output "$WORK_DIR/split_all.csv" \
    --tiling-dir "$WORK_DIR/split_tilings" \
    >"$WORK_DIR/split_search.log"

python3 tools/profile_official_tilings.py \
    --runner build/official_matmul_runner \
    --bank-probe build/tiling_bank_probe \
    --candidates "$SPLIT_CSV" \
    --workloads "$SPLIT_CSV" \
    --custom-output "$WORK_DIR/split_custom.csv" \
    --custom-samples-output "$WORK_DIR/split_custom_samples.csv" \
    --official-output "$WORK_DIR/split_official.csv" \
    --official-samples-output "$WORK_DIR/split_official_samples.csv" \
    --cann-root "$CANN_ROOT" \
    --soc "$SOC" \
    --aic-cores "$AIC_CORES" \
    --rank-limit 4 \
    --validate-only

python3 - "$GENERAL_CSV" "$SPLIT_CSV" <<'PY'
import csv
import sys

sys.path.insert(0, "tools")
import profile_official_tilings

with open(sys.argv[1], newline="", encoding="utf-8") as source:
    general = list(csv.DictReader(source))
with open(sys.argv[2], newline="", encoding="utf-8") as source:
    split = list(csv.DictReader(source))

ids = {row["workload_id"] for row in general}
assert "validation_skinny" in ids
assert "validation_tail" in ids
assert "validation_int8" not in ids
assert all(row["valid"] == "1" for row in general)
assert all(row["execution_mode"] == "base_iterate_all" for row in general)
for row in general + split:
    if row.get("candidate_role") != "searched":
        continue
    knowledge = profile_official_tilings.make_knowledge(row)
    assert knowledge["l2MTileCnt"] >= 1
    assert knowledge["l2NTileCnt"] >= 1
direct = [
    row for row in split
    if row["execution_mode"] == "direct_atomic_split_k_fp32_nt"
]
assert direct, "no legal FP32 NT multi-core split-K candidate"
print(
    f"tiling_validation passed general={len(general)} "
    f"split_k={len(direct)}"
)
PY

./build/official_matmul_runner \
    --candidates config/workloads_validation.csv \
    --validate-input

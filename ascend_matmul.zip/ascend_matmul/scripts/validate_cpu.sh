#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source "$ROOT/scripts/env.sh"
if [[ "${SKIP_BUILD:-0}" != "1" ]]; then
    ./scripts/build_all.sh
fi

ARCH="$(uname -m)"
CANN_INCLUDE="$CANN_ROOT/${ARCH}-linux/include"
g++ -std=c++17 -O2 -Wall -Wextra \
    -I"$ROOT/host/include" -I"$ROOT/compat" -I"$CANN_INCLUDE" \
    "$ROOT/tests/proxy_model_test.cpp" \
    "$ROOT/host/src/proxy_model.cpp" \
    "$ROOT/host/src/search_types.cpp" \
    -o "$ROOT/build/proxy_model_test"
"$ROOT/build/proxy_model_test"

BEAM_WIDTH=32 TABU_ITERS=24 LNS_ROUNDS=4 TOP_K=8 ./scripts/run_search.sh config/workloads_validation.csv
./build/matmul_tiling_search \
    --id validation_fp32_nt_splitk \
    --m 16 --n 16 --k 4096 --dtype fp32 --trans-a 0 --trans-b 1 --cores 24 \
    --beam-width 32 --tabu-iters 12 --lns-rounds 4 --top-k 4 \
    --max-core-rounds 2 \
    --max-base-m 128 --max-base-n 128 --max-base-k 512 --search-split-k 1 \
    --soc "${SOC_VERSION:-Ascend910B}" \
    --output results/splitk_validation_candidates.csv \
    --all-output results/splitk_validation_all.csv \
    --tiling-dir results/splitk_validation_tilings

test -x build/matmul_tiling_search
test -s results/candidates.csv
test -s results/all_evaluated.csv
python3 - <<'PY'
import csv
import math
import struct
from collections import defaultdict

with open("results/candidates.csv", newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
assert rows, "no executable candidates"
unsupported = {"validation_skinny", "validation_tail"}
assert not ({row["workload_id"] for row in rows} & unsupported), \
    "unaligned workload escaped the raw ND MDL execution contract"
grouped = defaultdict(list)
for row in rows:
    grouped[row["workload_id"]].append(row)
assert {"validation_large_k", "validation_trans_ab"} <= set(grouped), \
    "large-K or transA+transB regression workload produced no legal candidate"
for workload_id, workload_rows in grouped.items():
    baselines = [row for row in workload_rows if row["rank"] == "0"]
    dtype = workload_rows[0]["dtype"]
    if dtype != "int8" or baselines:
        assert len(baselines) == 1, f"{workload_id}: expected at most one rank-0 baseline"
        assert baselines[0]["source"] == "official_default"
        assert baselines[0]["candidate_role"] == "api_auto_baseline"
    else:
        assert not baselines
    searched_ranks = sorted(
        int(row["rank"]) for row in workload_rows if row["candidate_role"] == "searched"
    )
    assert searched_ranks == list(range(1, len(searched_ranks) + 1))

multi_round = 0
for row in rows:
    m, n, k = (int(row[name]) for name in ("m", "n", "k"))
    sm, sn, sk = (int(row[name]) for name in ("single_core_m", "single_core_n", "single_core_k"))
    parts = ((m + sm - 1) // sm) * ((n + sn - 1) // sn) * ((k + sk - 1) // sk)
    if row["execution_mode"] == "base_iterate_all":
        assert (k + sk - 1) // sk == 1
        assert parts >= int(row["used_core_num"])
        multi_round += int(parts > int(row["used_core_num"]))
    elif row["execution_mode"] == "direct_atomic_split_k_fp32_nt":
        assert row["dtype"] == "fp32" and row["trans_a"] == "0" and row["trans_b"] == "1"
        assert (k + sk - 1) // sk > 1
        assert parts == int(row["used_core_num"])
    else:
        raise AssertionError("unsupported execution mode: " + row["execution_mode"])
    assert int(row["official_core_num"]) == int(row["used_core_num"])
    assert int(row["official_m_dim"]) == (m + sm - 1) // sm
    assert int(row["official_n_dim"]) == (n + sn - 1) // sn
    with open(row["tiling_bin"], "rb") as f:
        prefix = struct.unpack("11i", f.read(44))
    expected = (int(row["used_core_num"]), m, n, k, k, sm, sn, sk)
    assert prefix[:8] == expected

    total = float(row["proxy_total"])
    critical = float(row["critical_core_cycles"])
    average = float(row["average_core_cycles"])
    gm_total = float(row["estimated_gm_bytes"])
    gm_parts = sum(float(row[name]) for name in
                   ("estimated_a_gm_bytes", "estimated_b_gm_bytes", "estimated_c_gm_bytes"))
    assert math.isfinite(total) and total > 0
    assert critical + 1e-9 >= average > 0
    assert abs(gm_total - gm_parts) <= max(1e-3, gm_total * 1e-12)
    assert 0.0 <= float(row["l1_cache_hit_rate"]) <= 1.0
    assert float(row["estimated_mmad_count"]) >= float(row["estimated_output_tile_count"]) > 0
assert multi_round > 0, "validation set did not retain any legal multi-round M/N tiling"

with open("results/all_evaluated.csv", newline="", encoding="utf-8") as f:
    evaluated = list(csv.DictReader(f))
for workload_id in unsupported:
    rejected = [row for row in evaluated if row["workload_id"] == workload_id]
    assert rejected, f"{workload_id}: no recorded contract evaluations"
    assert all(row["valid"] == "0" for row in rejected)
    assert all("raw ND MDL kernel requires" in row["error"] for row in rejected)
unsafe = [row for row in evaluated if row["valid"] == "1" and
          row["dtype"] in {"fp16", "bf16", "int8"} and int(row["k_core_parts"]) > 1]
assert not unsafe, "non-fp32 direct split-K escaped the execution contract"

with open("results/splitk_validation_candidates.csv", newline="", encoding="utf-8") as f:
    split_rows = list(csv.DictReader(f))
assert split_rows, "FP32 NT split-K validation produced no candidates"
direct = [row for row in split_rows
          if row["execution_mode"] == "direct_atomic_split_k_fp32_nt"]
assert direct, "FP32 NT split-K validation produced no direct atomic candidate"
for row in direct:
    m, n, k = (int(row[name]) for name in ("m", "n", "k"))
    sm, sn, sk = (int(row[name]) for name in
                  ("single_core_m", "single_core_n", "single_core_k"))
    parts = ((m + sm - 1) // sm) * ((n + sn - 1) // sn) * ((k + sk - 1) // sk)
    assert parts == int(row["used_core_num"])

print(
    f"candidate contract validation passed: {len(rows)} general rows, "
    f"{len(direct)} direct split-K rows, {multi_round} multi-round rows"
)
PY

./build/official_matmul_runner \
    --candidates results/candidates.csv \
    --validate-input
./build/official_matmul_runner \
    --candidates config/workloads_validation.csv \
    --validate-input

python3 - <<'PY'
import csv
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "tools")
from profile_npu_isolated import PROFILE_COLUMNS


def profile_row(
    workload_id, rank, source, role, dtype, success, median_ms, stddev_ms, error=""
):
    row = {column: "" for column in PROFILE_COLUMNS}
    row.update(
        workload_id=workload_id,
        rank=str(rank),
        source=source,
        candidate_role=role,
        m="256",
        n="256",
        k="256",
        dtype=dtype,
        trans_a="0",
        trans_b="0",
        execution_mode="validation",
        success=str(success),
        error=error,
        median_ms=str(median_ms),
        stddev_ms=str(stddev_ms),
        tflops="1",
    )
    return row


with tempfile.TemporaryDirectory(prefix="dual_baseline_validation_") as directory:
    root = Path(directory)
    custom = [
        profile_row(
            "fp16_case", 0, "official_default", "api_auto_baseline",
            "fp16", 1, 10.0, 0.1
        ),
        profile_row("fp16_case", 1, "beam", "searched", "fp16", 1, 8.0, 0.1),
        profile_row("int8_case", 1, "beam", "searched", "int8", 1, 5.0, 0.1),
    ]
    official = [
        profile_row(
            "fp16_case", -1, "installed_aclnn_matmul",
            "official_operator_baseline", "fp16", 1, 9.0, 0.1
        ),
        profile_row(
            "official_only", -1, "installed_aclnn_matmul",
            "official_operator_baseline", "fp16", 1, 7.0, 0.1
        ),
        profile_row(
            "int8_case", -1, "installed_aclnn_matmul",
            "official_operator_baseline", "int8", 0, 0.0, 0.0,
            "unsupported_by_aclnnMatmul:int8"
        ),
    ]
    for name, rows in (("custom.csv", custom), ("official.csv", official)):
        with (root / name).open("w", newline="", encoding="utf-8") as output:
            writer = csv.DictWriter(output, fieldnames=PROFILE_COLUMNS)
            writer.writeheader()
            writer.writerows(rows)

    subprocess.run(
        [
            "python3", "tools/rank_npu_results.py",
            "--input", str(root / "custom.csv"),
            "--official-input", str(root / "official.csv"),
            "--output", str(root / "ranked.csv"),
            "--summary", str(root / "best.csv"),
            "--comparison", str(root / "comparison.csv"),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
    )
    with (root / "comparison.csv").open(newline="", encoding="utf-8") as source:
        comparisons = {row["workload_id"]: row for row in csv.DictReader(source)}

    fp16 = comparisons["fp16_case"]
    int8 = comparisons["int8_case"]
    official_only = comparisons["official_only"]
    assert abs(float(fp16["speedup_vs_api_auto"]) - 1.25) < 1e-9
    assert abs(float(fp16["speedup_vs_official_operator"]) - 1.125) < 1e-9
    assert fp16["primary_reference"] == "official_operator"
    assert fp16["primary_verdict"] == "improved"
    assert int8["official_operator_verdict"] == "official_operator_unsupported"
    assert official_only["best_searched_rank"] == ""
    assert official_only["official_operator_success"] == "1"
    assert official_only["official_operator_median_ms"] == "7.0"
    assert official_only["primary_verdict"] == "no_successful_searched_candidate"

    report = subprocess.run(
        [
            "python3", "tools/print_npu_summary.py",
            "--summary", str(root / "comparison.csv"),
            "--candidates", str(root / "ranked.csv"),
        ],
        check=True,
        text=True,
        capture_output=True,
    ).stdout
    assert "official_only rank=NA no_successful_searched_candidate" in report

print("dual baseline and official-only report validation passed")
PY

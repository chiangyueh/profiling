#!/usr/bin/env python3
from __future__ import annotations

import struct
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import refine_matmul_v3_candidates as refine
import rank_npu_results as rank_results


HARDWARE = refine.Hardware(
    aic_cores=20,
    l0a_bytes=64 * 1024,
    l0b_bytes=64 * 1024,
    l0c_bytes=128 * 1024,
    l1_bytes=512 * 1024,
    l2_bytes=192 * 1024 * 1024,
    l2_bytes_per_cycle_per_core=110.0,
    hbm_bytes_per_cycle_per_core=32.0,
)


def base_knowledge(
    workload: refine.Workload,
    base_m: int,
    base_n: int,
    base_k: int,
) -> dict[str, int]:
    m_blocks = refine.ceil_div(workload.m, base_m)
    n_blocks = refine.ceil_div(workload.n, base_n)
    return {
        "usedCoreNum": HARDWARE.aic_cores,
        "singleCoreM": base_m,
        "singleCoreN": base_n,
        "singleCoreK": workload.k,
        "baseM": base_m,
        "baseN": base_n,
        "baseK": base_k,
        "depthA1": 2,
        "depthB1": 2,
        "stepM": 1,
        "stepN": 1,
        "iterateOrder": 0,
        "stepKa": 1,
        "stepKb": 1,
        "dbL0A": 2,
        "dbL0B": 2,
        "dbL0C": 1,
        "l2MTileCnt": 1,
        "l2NTileCnt": 1,
        "l2MTileBlock": m_blocks,
        "l2NTileBlock": n_blocks,
        "l2IterateOrder": 0,
        "tilingEnable": 0,
    }


def test_layout_specific_fp32_alignment() -> None:
    nn = refine.Workload("nn", 64, 64, 64, "fp32", False, False, 20)
    nt = refine.Workload("nt", 64, 64, 64, "fp32", False, True, 20)
    tn = refine.Workload("tn", 64, 64, 64, "fp32", True, False, 20)
    assert refine.base_k_alignment(nn) == 16
    assert refine.base_k_alignment(nt) == 8
    assert refine.base_k_alignment(tn) == 16


def test_complete_callback_blob_parsing() -> None:
    words = [0] * 68
    words[0] = 20
    words[5:15] = [128, 256, 4096, 128, 256, 64, 16, 8, 1, 1]
    words[17] = 0
    words[26:28] = [8, 4]
    words[30:33] = [2, 2, 1]
    words[50:55] = [1, 1, 32, 16, 0]
    words[62:67] = [1, 32, 64, 16, 128]
    result = {
        "tiling_key": 11000000000100000,
        "block_dim": 20,
        "workspaces": [1024],
        "tiling_data": struct.pack("<68I", *words),
    }
    callback = refine.parse_callback_result(result)
    assert len(callback.blob) == 272
    assert callback.knowledge["baseM"] == 128
    assert callback.knowledge["baseN"] == 256
    assert callback.derived == {
        "l2CacheFlag": 1,
        "baseAN": 32,
        "baseAD": 64,
        "baseBN": 16,
        "baseBD": 128,
    }
    assert len(callback.sha256) == 64


def test_twenty_core_slot_balance_is_ranked() -> None:
    workload = refine.Workload(
        "skinny_n", 4096, 17, 16384, "fp16", False, False, 20
    )
    exact_twenty = refine.analytical_score(
        workload, base_knowledge(workload, 208, 32, 64), HARDWARE
    )
    thirteen_blocks = refine.analytical_score(
        workload, base_knowledge(workload, 320, 32, 32), HARDWARE
    )
    assert exact_twenty.balance < thirteen_blocks.balance
    assert exact_twenty.cycles < thirteen_blocks.cycles


def test_bank_control_is_not_api_auto_baseline() -> None:
    control = {
        "rank": "0",
        "source": "official_seed_bank_roundtrip",
        "candidate_role": "bank_seed_control",
    }
    assert not rank_results.is_api_auto_baseline(control)
    assert rank_results.is_bank_seed_control(control)


def main() -> None:
    test_layout_specific_fp32_alignment()
    test_complete_callback_blob_parsing()
    test_twenty_core_slot_balance_is_ranked()
    test_bank_control_is_not_api_auto_baseline()
    print("refine_model_test passed")


if __name__ == "__main__":
    main()

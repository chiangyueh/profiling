from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        rows = list(reader)
    if not reader.fieldnames:
        raise ValueError(f"{path}: missing CSV header")
    return rows


def compact_number(value: str) -> str:
    if not value:
        return "NA"
    try:
        return f"{float(value):.6g}"
    except ValueError:
        return value


def clean(value: str) -> str:
    return value.replace(" ", "_") if value else "NA"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Print a compact, copyable report from an NPU MatMul run."
    )
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, required=True)
    args = parser.parse_args()

    summaries = read_csv(args.summary)
    candidates = read_csv(args.candidates)
    candidate_by_key = {
        (row.get("workload_id", ""), row.get("rank", "")): row
        for row in candidates
        if row.get("candidate_role") == "searched"
    }

    verdicts: Counter[str] = Counter()
    print("NPU_RESULT_BEGIN")
    print("LEGEND ms=searched/api_auto/official x=vs_api_auto/vs_official")
    print("LEGEND T=baseMxbaseNxbaseK C=cores D=mDimxnDim")
    total = len(summaries)
    width = max(2, len(str(total)))
    for index, summary in enumerate(summaries, 1):
        workload_id = summary.get("workload_id", "")
        searched_rank = summary.get("best_searched_rank", "")
        candidate = candidate_by_key.get((workload_id, searched_rank), {})
        verdict = summary.get("primary_verdict", "") or "unknown"
        verdicts[verdict] += 1

        shape = "x".join(
            summary.get(field, "") or "?" for field in ("m", "n", "k")
        )
        tiling = "x".join(
            candidate.get(field, "") or "?"
            for field in ("official_base_m", "official_base_n", "official_base_k")
        )
        core_dims = "x".join(
            candidate.get(field, "") or "?"
            for field in ("official_m_dim", "official_n_dim")
        )
        print(
            f"[{index:0{width}d}/{total:0{width}d}] {clean(workload_id)} "
            f"rank={clean(searched_rank)} {clean(verdict)}"
        )
        print(
            f"  {shape} {clean(summary.get('dtype', ''))}"
            f" T={tiling}"
            f" C={clean(candidate.get('used_core_num', ''))}"
            f" D={core_dims}"
            " ms="
            f"{compact_number(summary.get('best_searched_median_ms', ''))}/"
            f"{compact_number(summary.get('api_auto_median_ms', ''))}/"
            f"{compact_number(summary.get('official_operator_median_ms', ''))}"
            " x="
            f"{compact_number(summary.get('speedup_vs_api_auto', ''))}/"
            f"{compact_number(summary.get('speedup_vs_official_operator', ''))}"
        )

    ordered = ("improved", "within_noise", "regressed")
    totals = " ".join(f"{key}={verdicts.pop(key, 0)}" for key in ordered)
    other = sum(verdicts.values())
    print(f"RESULT_TOTAL workloads={len(summaries)} {totals} other={other}")
    print("NPU_RESULT_END")


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        rows = list(reader)
    if not reader.fieldnames:
        raise ValueError(f"{path}: missing CSV header")
    return rows


def compact_number(value: str) -> str:
    if not value:
        return "NA"
    try:
        return f"{float(value):.6g}"
    except ValueError:
        return value


def clean(value: str) -> str:
    return value.replace(" ", "_") if value else "NA"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Print a compact, copyable report from an NPU MatMul run."
    )
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, required=True)
    args = parser.parse_args()

    summaries = read_csv(args.summary)
    candidates = read_csv(args.candidates)
    candidate_by_key = {
        (row.get("workload_id", ""), row.get("rank", "")): row
        for row in candidates
        if row.get("candidate_role") == "searched"
    }

    verdicts: Counter[str] = Counter()
    print("NPU_RESULT_BEGIN")
    print("LEGEND ms=searched/bank_seed_control/official")
    print("LEGEND speedup=official_or_bank_ms/searched_ms (>1 is faster)")
    print("LEGEND tpl=MatMulV3 template T=baseMxbaseNxbaseK S=kernel_single_MxN")
    print("LEGEND C=cores G=output_block_grid")
    print("LEGEND L2=tile_count_MxN(blocks_per_tile_MxN)")
    print("LEGEND optimization=whether the searched tiling beats the official baseline")
    total = len(summaries)
    width = max(2, len(str(total)))
    optimization_results: Counter[str] = Counter()
    for index, summary in enumerate(summaries, 1):
        workload_id = summary.get("workload_id", "")
        searched_rank = summary.get("best_searched_rank", "")
        candidate = candidate_by_key.get((workload_id, searched_rank), {})
        verdict = summary.get("primary_verdict", "") or "unknown"
        verdicts[verdict] += 1
        optimization = (
            summary.get("optimization_result", "")
            or "no_successful_searched_candidate"
        )
        optimization_results[optimization] += 1

        shape = "x".join(
            summary.get(field, "") or "?" for field in ("m", "n", "k")
        )
        tiling = "x".join(
            candidate.get(field, "") or "?"
            for field in ("official_base_m", "official_base_n", "official_base_k")
        )
        core_dims = "x".join(
            candidate.get(field, "") or "?"
            for field in ("m_base_blocks", "n_base_blocks")
        )
        single = "x".join(
            candidate.get(field, "") or "?"
            for field in ("kernel_single_core_m", "kernel_single_core_n")
        )
        l2_count = "x".join(
            candidate.get(field, "") or "?"
            for field in ("l2_m_tile_count", "l2_n_tile_count")
        )
        l2_block = "x".join(
            candidate.get(field, "") or "?"
            for field in ("l2_m_tile_block", "l2_n_tile_block")
        )
        print(
            f"[{index:0{width}d}/{total:0{width}d}] {clean(workload_id)} "
            f"rank={clean(searched_rank)} {clean(verdict)} "
            f"optimization={clean(optimization)}"
        )
        print(
            f"  {shape} {clean(summary.get('dtype', ''))}"
            f" tpl={clean(candidate.get('kernel_template', ''))}"
            f" T={tiling}"
            f" S={single}"
            f" C={clean(candidate.get('used_core_num', ''))}"
            f" G={core_dims}"
            f" L2={l2_count}({l2_block})"
        )
        print(
            f"  guidance={clean(candidate.get('search_guidance', ''))}"
            f" model_ratio={compact_number(candidate.get('search_model_ratio_vs_bank_seed', ''))}"
            f" calibration={compact_number(candidate.get('search_model_calibration', ''))}"
            f" model_confidence={clean(candidate.get('search_model_confidence', ''))}"
        )
        print(
            "  ms="
            f"{compact_number(summary.get('best_searched_median_ms', ''))}/"
            f"{compact_number(summary.get('bank_seed_median_ms', ''))}/"
            f"{compact_number(summary.get('official_operator_median_ms', ''))}"
            " std="
            f"{compact_number(summary.get('best_searched_stddev_ms', ''))}/"
            f"{compact_number(summary.get('official_operator_stddev_ms', ''))}"
            f" speedup={compact_number(summary.get('speedup_vs_official_operator', ''))}"
            f" speedup_vs_bank={compact_number(summary.get('speedup_vs_bank_seed', ''))}"
            f" delta={compact_number(summary.get('latency_change_pct_vs_official_operator', ''))}%"
        )
        print(f"  decision={clean(summary.get('selection_reason', ''))}")

    ordered = ("improved", "within_noise", "regressed")
    totals = " ".join(f"{key}={verdicts.pop(key, 0)}" for key in ordered)
    other = sum(verdicts.values())
    optimized = optimization_results.pop("improved", 0)
    not_improved = optimization_results.pop("not_improved", 0)
    no_candidate = optimization_results.pop(
        "no_successful_searched_candidate", 0
    )
    optimization_other = sum(optimization_results.values())
    print(
        f"RESULT_TOTAL workloads={len(summaries)} {totals} other={other} "
        f"optimization_success={optimized} "
        f"optimization_not_improved={not_improved} "
        f"no_searched_candidate={no_candidate} "
        f"optimization_other={optimization_other}"
    )
    print("NPU_RESULT_END")


if __name__ == "__main__":
    main()

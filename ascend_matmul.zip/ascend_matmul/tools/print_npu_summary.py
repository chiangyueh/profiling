from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path


PRIOR_REGRESSION_WORKLOADS = {
    "llm_full_4096_ffn_up",
    "llm_full_4096_ffn_down",
    "llm_8192_square",
    "attention_score_1024",
    "vision_projection",
    "skinny_m_large_k",
}


def evidence_group(workload_id: str) -> str:
    if workload_id == "int8_projection":
        return "unsupported_control"
    if workload_id == "large_k_small_mn":
        return "det_split_k_anchor"
    if workload_id.startswith("det_split_k_aligned_holdout_"):
        return "det_split_k_holdout"
    if workload_id == "deterministic_split_k_unaligned":
        return "alignment_negative_control"
    if workload_id == "skinny_n_large_k":
        return "known_anchor"
    if workload_id.startswith("skinny_n_k16384_holdout_"):
        return "skinny_n_k16384_holdout"
    if workload_id.startswith("skinny_n_holdout_"):
        return "skinny_n_initial_holdout"
    if workload_id.startswith("skinny_n_boundary_"):
        return "boundary_control"
    if workload_id in PRIOR_REGRESSION_WORKLOADS:
        return "prior_regression"
    return "broad_validation"


def strict_evidence_status(
    results: Counter[str] | None,
    minimum_workloads: int,
) -> str:
    if not results or sum(results.values()) < minimum_workloads:
        return "insufficient_evidence"
    if results.get("improved", 0) == sum(results.values()):
        return "supported"
    return "not_supported"


def campaign_statuses(
    evidence_results: dict[str, Counter[str]],
) -> dict[str, str]:
    skinny_initial = strict_evidence_status(
        evidence_results.get("skinny_n_initial_holdout"), 3
    )
    skinny_k16384 = strict_evidence_status(
        evidence_results.get("skinny_n_k16384_holdout"), 3
    )
    det_split_k = strict_evidence_status(
        evidence_results.get("det_split_k_holdout"), 3
    )
    prior_failures = strict_evidence_status(
        evidence_results.get("prior_regression"), 6
    )
    broad_validation = strict_evidence_status(
        evidence_results.get("broad_validation"), 26
    )
    wide = (
        "supported"
        if skinny_k16384 == "supported"
        and det_split_k == "supported"
        and prior_failures == "supported"
        and broad_validation == "supported"
        else "not_proven"
    )
    return {
        "skinny_initial": skinny_initial,
        "skinny_k16384": skinny_k16384,
        "det_split_k": det_split_k,
        "prior_failures": prior_failures,
        "broad_validation": broad_validation,
        "wide": wide,
    }


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        rows = list(reader)
    if not reader.fieldnames:
        raise ValueError(f"{path}: missing CSV header")
    return rows


def compact_number(value: str) -> str:
    if not value:
        return "NA"
    try:
        return f"{float(value):.6g}"
    except ValueError:
        return value


def clean(value: str) -> str:
    return value.replace(" ", "_") if value else "NA"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Print a compact, copyable report from an NPU MatMul run."
    )
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument(
        "--all-workloads",
        action="store_true",
        help="print every workload instead of only analysis-relevant rows",
    )
    args = parser.parse_args()

    summaries = read_csv(args.summary)
    candidates = read_csv(args.candidates)
    candidate_by_key = {
        (row.get("workload_id", ""), row.get("rank", "")): row
        for row in candidates
        if row.get("candidate_role") == "searched"
    }

    verdicts: Counter[str] = Counter()
    print("NPU_RESULT_BEGIN")
    print("LEGEND ms=searched/bank_seed_control/official")
    print("LEGEND speedup=official_or_bank_ms/searched_ms (>1 is faster)")
    print("LEGEND tpl=MatMulV3 template T=baseMxbaseNxbaseK S=kernel_single_MxN")
    print("LEGEND C=cores G=output_block_grid")
    print("LEGEND L2=tile_count_MxN(blocks_per_tile_MxN)")
    print("LEGEND optimization=whether the searched tiling beats the official baseline")
    print("LEGEND evidence=known anchor, unseen holdout, prior regression, or broad")
    total = len(summaries)
    width = max(2, len(str(total)))
    optimization_results: Counter[str] = Counter()
    evidence_results: dict[str, Counter[str]] = {}
    printed_workloads = 0
    for index, summary in enumerate(summaries, 1):
        workload_id = summary.get("workload_id", "")
        evidence = evidence_group(workload_id)
        searched_rank = summary.get("best_searched_rank", "")
        candidate = candidate_by_key.get((workload_id, searched_rank), {})
        verdict = summary.get("primary_verdict", "") or "unknown"
        verdicts[verdict] += 1
        optimization = (
            summary.get("optimization_result", "")
            or "no_successful_searched_candidate"
        )
        optimization_results[optimization] += 1
        evidence_results.setdefault(evidence, Counter())[optimization] += 1

        should_print = (
            args.all_workloads
            or optimization == "improved"
            or verdict == "regressed"
            or candidate.get("search_resume_policy") == "allow_new"
        )
        if not should_print:
            continue
        printed_workloads += 1

        shape = "x".join(
            summary.get(field, "") or "?" for field in ("m", "n", "k")
        )
        tiling = "x".join(
            candidate.get(field, "") or "?"
            for field in ("official_base_m", "official_base_n", "official_base_k")
        )
        core_dims = "x".join(
            candidate.get(field, "") or "?"
            for field in ("m_base_blocks", "n_base_blocks")
        )
        single = "x".join(
            candidate.get(field, "") or "?"
            for field in ("kernel_single_core_m", "kernel_single_core_n")
        )
        l2_count = "x".join(
            candidate.get(field, "") or "?"
            for field in ("l2_m_tile_count", "l2_n_tile_count")
        )
        l2_block = "x".join(
            candidate.get(field, "") or "?"
            for field in ("l2_m_tile_block", "l2_n_tile_block")
        )
        print(
            f"[{index:0{width}d}/{total:0{width}d}] {clean(workload_id)} "
            f"rank={clean(searched_rank)} {clean(verdict)} "
            f"optimization={clean(optimization)} evidence={evidence}"
        )
        print(
            f"  {shape} {clean(summary.get('dtype', ''))}"
            f" tpl={clean(candidate.get('kernel_template', ''))}"
            f" T={tiling}"
            f" S={single}"
            f" C={clean(candidate.get('used_core_num', ''))}"
            f" G={core_dims}"
            f" L2={l2_count}({l2_block})"
        )
        print(
            f"  cause={clean(candidate.get('search_bottleneck', ''))}/"
            f"{clean(candidate.get('search_guidance', ''))}"
            f" model_ratio={compact_number(candidate.get('search_model_ratio_vs_bank_seed', ''))}"
            f" calibration={compact_number(candidate.get('search_model_calibration', ''))}"
            f" model_confidence={clean(candidate.get('search_model_confidence', ''))}"
            f" resume={clean(candidate.get('search_resume_policy', ''))}"
        )
        print(
            "  ms="
            f"{compact_number(summary.get('best_searched_median_ms', ''))}/"
            f"{compact_number(summary.get('bank_seed_median_ms', ''))}/"
            f"{compact_number(summary.get('official_operator_median_ms', ''))}"
            " std="
            f"{compact_number(summary.get('best_searched_stddev_ms', ''))}/"
            f"{compact_number(summary.get('official_operator_stddev_ms', ''))}"
            f" speedup={compact_number(summary.get('speedup_vs_official_operator', ''))}"
            f" speedup_vs_bank={compact_number(summary.get('speedup_vs_bank_seed', ''))}"
            f" delta={compact_number(summary.get('latency_change_pct_vs_official_operator', ''))}%"
        )
        print(f"  decision={clean(summary.get('selection_reason', ''))}")

    ordered = ("improved", "within_noise", "regressed")
    totals = " ".join(f"{key}={verdicts.pop(key, 0)}" for key in ordered)
    other = sum(verdicts.values())
    optimized = optimization_results.pop("improved", 0)
    not_improved = optimization_results.pop("not_improved", 0)
    no_candidate = optimization_results.pop(
        "no_successful_searched_candidate", 0
    )
    optimization_other = sum(optimization_results.values())
    if not args.all_workloads:
        print(
            f"PRINTED_WORKLOADS shown={printed_workloads} total={len(summaries)} "
            "policy=improved_or_regressed_or_new_allow_new; "
            "set_PRINT_ALL_RESULTS=1_for_every_workload"
        )
    print(
        f"RESULT_TOTAL workloads={len(summaries)} {totals} other={other} "
        f"optimization_success={optimized} "
        f"optimization_not_improved={not_improved} "
        f"no_searched_candidate={no_candidate} "
        f"optimization_other={optimization_other}"
    )
    for evidence in (
        "known_anchor",
        "skinny_n_initial_holdout",
        "skinny_n_k16384_holdout",
        "boundary_control",
        "det_split_k_anchor",
        "det_split_k_holdout",
        "alignment_negative_control",
        "prior_regression",
        "broad_validation",
        "unsupported_control",
    ):
        results = evidence_results.get(evidence)
        if not results:
            continue
        print(
            f"EVIDENCE_GROUP {evidence} workloads={sum(results.values())} "
            f"improved={results.get('improved', 0)} "
            f"not_improved={results.get('not_improved', 0)} "
            "no_candidate="
            f"{results.get('no_successful_searched_candidate', 0)} "
            f"other={sum(results.values()) - results.get('improved', 0) - results.get('not_improved', 0) - results.get('no_successful_searched_candidate', 0)}"
        )
    campaign = campaign_statuses(evidence_results)
    print(
        "GENERALIZATION_RESULT skinny_n_initial "
        f"status={campaign['skinny_initial']} "
        "criterion=all_three_unseen_shapes_must_improve"
    )
    print(
        "REFINED_SKINNY_N_RESULT k_eq_16384 "
        f"status={campaign['skinny_k16384']} "
        "criterion=all_three_preregistered_k16384_holdouts_must_improve"
    )
    print(
        "DETERMINISTIC_SPLIT_K_RESULT aligned_mn "
        f"status={campaign['det_split_k']} "
        "criterion=all_three_preregistered_aligned_k_holdouts_must_improve"
    )
    print(
        "PRIOR_FAILURE_RESULT "
        f"status={campaign['prior_failures']} "
        "criterion=all_six_previously_regressed_workloads_must_improve"
    )
    print(
        "BROAD_VALIDATION_RESULT "
        f"status={campaign['broad_validation']} "
        "criterion=all_28_supported_general_workloads_must_improve"
    )
    print(
        "MATMUL_WIDE_RESULT "
        f"status={campaign['wide']} "
        "anchor_success_alone_is_not_counted"
    )
    print("NPU_RESULT_END")


if __name__ == "__main__":
    main()

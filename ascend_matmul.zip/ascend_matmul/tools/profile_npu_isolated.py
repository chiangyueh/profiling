#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import os
import re
import selectors
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path


PROFILE_COLUMNS = [
    "workload_id", "rank", "source", "candidate_role",
    "m", "n", "k", "dtype", "trans_a", "trans_b", "execution_mode",
    "used_core_num", "hint_single_core_m", "hint_single_core_n", "hint_single_core_k",
    "hint_base_m", "hint_base_n", "hint_base_k", "official_base_m", "official_base_n", "official_base_k",
    "official_core_num", "official_m_dim", "official_n_dim",
    "proxy_total", "success", "preflight_passed", "preflight_mode", "error",
    "min_ms", "mean_ms", "median_ms", "stddev_ms", "p95_ms", "max_ms", "tflops",
    "warmup", "repeat", "samples", "tiling_signature", "tiling_bin",
]

SAMPLE_COLUMNS = ["workload_id", "rank", "sample", "latency_ms"]


def truthy(value: str) -> bool:
    return value in {"1", "true", "TRUE", "True", "yes", "YES"}


def load_candidates(path: Path, rank_limit: int) -> list[dict]:
    rows: list[dict] = []
    with path.open(newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            try:
                rank = int(row.get("rank", "0"))
                cores = int(row.get("used_core_num", "0"))
            except ValueError:
                continue
            if rank_limit > 0 and rank > rank_limit:
                continue
            if cores <= 0 or not row.get("tiling_bin"):
                continue
            rows.append(row)
    return rows


def profile_failure_row(row: dict, error: str, warmup: int, repeat: int, samples: int) -> dict:
    return {
        "workload_id": row.get("workload_id", ""),
        "rank": row.get("rank", ""),
        "source": row.get("source", ""),
        "candidate_role": row.get("candidate_role", ""),
        "m": row.get("m", ""),
        "n": row.get("n", ""),
        "k": row.get("k", ""),
        "dtype": row.get("dtype", ""),
        "trans_a": row.get("trans_a", ""),
        "trans_b": row.get("trans_b", ""),
        "execution_mode": row.get("execution_mode", ""),
        "used_core_num": row.get("used_core_num", ""),
        "hint_single_core_m": row.get("candidate_single_core_m", "-1"),
        "hint_single_core_n": row.get("candidate_single_core_n", "-1"),
        "hint_single_core_k": row.get("candidate_single_core_k", "-1"),
        "hint_base_m": row.get("candidate_base_m", "-1"),
        "hint_base_n": row.get("candidate_base_n", "-1"),
        "hint_base_k": row.get("candidate_base_k", "-1"),
        "official_base_m": row.get("base_m", "0"),
        "official_base_n": row.get("base_n", "0"),
        "official_base_k": row.get("base_k", "0"),
        "official_core_num": row.get("official_core_num", "0"),
        "official_m_dim": row.get("official_m_dim", "0"),
        "official_n_dim": row.get("official_n_dim", "0"),
        "proxy_total": row.get("proxy_total", "0"),
        "success": "0",
        "preflight_passed": "0",
        "preflight_mode": "",
        "error": error,
        "min_ms": "0",
        "mean_ms": "0",
        "median_ms": "0",
        "stddev_ms": "0",
        "p95_ms": "0",
        "max_ms": "0",
        "tflops": "0",
        "warmup": str(warmup),
        "repeat": str(repeat),
        "samples": str(samples),
        "tiling_signature": row.get("tiling_signature", ""),
        "tiling_bin": row.get("tiling_bin", ""),
    }


def append_csv_rows(dst: Path, columns: list[str], rows: list[dict]) -> None:
    with dst.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        for row in rows:
            writer.writerow(row)
        f.flush()


def read_data_rows(path: Path) -> list[dict]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def compact_line(line: str) -> bool:
    return line.startswith("candidate_done ")


def run_one(args: argparse.Namespace, row: dict, index: int, total: int, temp_dir: Path) -> tuple[int, str]:
    workload = row["workload_id"]
    rank = row["rank"]
    temp_profile = temp_dir / f"profile_{index}.csv"
    temp_samples = temp_dir / f"samples_{index}.csv"
    cmd = [
        str(args.runner),
        "--candidates", str(args.candidates),
        "--output", str(temp_profile),
        "--samples-output", str(temp_samples),
        "--device", str(args.device),
        "--warmup", str(args.warmup),
        "--repeat", str(args.repeat),
        "--samples", str(args.samples),
        "--rank-limit", str(args.rank_limit),
        "--workspace-mib", str(args.workspace_mib),
        "--numeric-preflight-max-mib", str(args.numeric_preflight_max_mib),
        "--only-workload", workload,
        "--only-rank", str(rank),
        "--stage-log-interval", str(args.stage_log_interval),
        "--repeat-stage-interval", str(args.repeat_stage_interval),
    ]

    print(
        f"profile_progress: [{index}/{total}] {workload} rank={rank} "
        f"role={row.get('candidate_role')} "
        f"M={row.get('m')} N={row.get('n')} K={row.get('k')} cores={row.get('used_core_num')}",
        flush=True,
    )
    env = os.environ.copy()
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        env=env,
        start_new_session=True,
    )
    assert proc.stdout is not None
    selector = selectors.DefaultSelector()
    selector.register(proc.stdout, selectors.EVENT_READ)

    start = time.monotonic()
    last_activity = start
    last_stage = ""
    last_output_lines: list[str] = []
    timed_out = False
    next_heartbeat = start + args.heartbeat_sec if args.heartbeat_sec > 0 else float("inf")

    while proc.poll() is None:
        events = selector.select(timeout=1.0)
        for key, _ in events:
            line = key.fileobj.readline()
            if not line:
                continue
            line = line.rstrip("\n")
            last_activity = time.monotonic()
            last_output_lines.append(line)
            if len(last_output_lines) > 24:
                last_output_lines = last_output_lines[-24:]
            if line.startswith("candidate_stage "):
                last_stage = line
            elif compact_line(line):
                print(line, flush=True)

        now = time.monotonic()
        if now >= next_heartbeat:
            print(
                f"profile_heartbeat: elapsed={int(now - start)}s "
                f"current={workload} rank={rank} stage={last_stage or '<none>'}",
                flush=True,
            )
            next_heartbeat = now + args.heartbeat_sec

        if args.stall_timeout_sec > 0 and now - last_activity >= args.stall_timeout_sec:
            timed_out = True
            print(f"profile_timeout: no child output for {int(now - last_activity)}s", flush=True)
            print("suspect=candidate_or_runtime_stall", flush=True)
            if last_stage:
                print(f"last_stage: {last_stage}", flush=True)
            print(
                "last_tiling: "
                f"{workload} rank={rank} official={row.get('base_m')}x{row.get('base_n')}x{row.get('base_k')} "
                f"signature={row.get('tiling_signature', '')} bin={row.get('tiling_bin', '')}",
                flush=True,
            )
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            time.sleep(5)
            if proc.poll() is None:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            break

    try:
        remaining = proc.communicate(timeout=2)[0]
    except subprocess.TimeoutExpired:
        remaining = ""
    for line in remaining.splitlines():
        last_output_lines.append(line)
        if len(last_output_lines) > 24:
            last_output_lines = last_output_lines[-24:]
        if line.startswith("candidate_stage "):
            last_stage = line
        elif compact_line(line):
            print(line, flush=True)

    rc = proc.returncode if proc.returncode is not None else 124
    profile_rows = read_data_rows(temp_profile)
    sample_rows = read_data_rows(temp_samples)
    if profile_rows:
        append_csv_rows(args.output, PROFILE_COLUMNS, profile_rows)
        append_csv_rows(args.samples_output, SAMPLE_COLUMNS, sample_rows)
        failed = next((item for item in profile_rows if not truthy(item.get("success", ""))), None)
        return rc, failed.get("error", "") if failed else ""

    if timed_out:
        error = (
            f"isolated_timeout_after_{args.stall_timeout_sec}s"
            f"; last_stage={last_stage}"
        )
    else:
        tail = " | ".join(last_output_lines[-6:])
        error = f"isolated_runner_failed rc={rc}; {tail}"
    append_csv_rows(args.output, PROFILE_COLUMNS, [profile_failure_row(row, error, args.warmup, args.repeat, args.samples)])
    print(
        f"candidate_done {workload} rank={rank} success=0 median_ms=0 reason={error}",
        flush=True,
    )
    return rc, error


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples-output", type=Path, required=True)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--repeat", type=int, default=50)
    parser.add_argument("--samples", type=int, default=15)
    parser.add_argument("--rank-limit", type=int, default=20)
    parser.add_argument("--workspace-mib", type=int, default=64)
    parser.add_argument("--numeric-preflight-max-mib", type=int, default=4)
    parser.add_argument("--stall-timeout-sec", type=int, default=60)
    parser.add_argument("--stage-log-interval", type=int, default=1)
    parser.add_argument("--repeat-stage-interval", type=int, default=0)
    parser.add_argument("--heartbeat-sec", type=float, default=60)
    args = parser.parse_args()

    candidates = load_candidates(args.candidates, args.rank_limit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.samples_output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=PROFILE_COLUMNS).writeheader()
    with args.samples_output.open("w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=SAMPLE_COLUMNS).writeheader()

    print(f"isolated_profile candidates={len(candidates)} timeout={args.stall_timeout_sec}s", flush=True)
    failures = 0
    stopped_on_aicore_exception = False
    with tempfile.TemporaryDirectory(prefix="npu_isolated_", dir=str(args.output.parent)) as tmp:
        temp_dir = Path(tmp)
        total = len(candidates)
        for index, row in enumerate(candidates, start=1):
            rc, error = run_one(args, row, index, total, temp_dir)
            if error or rc not in (0,):
                failures += 1
            if "507015" in error:
                stopped_on_aicore_exception = True
                print(
                    "fatal: AI Core exception rc=507015; stopping immediately because "
                    "later candidate results would not be trustworthy",
                    flush=True,
                )
                break
    profile_rows = read_data_rows(args.output)
    successes = sum(truthy(row.get("success", "")) for row in profile_rows)
    print(
        f"isolated_profile completed candidates={len(candidates)} "
        f"successes={successes} failures={failures}",
        flush=True,
    )
    return 1 if stopped_on_aicore_exception or (candidates and successes == 0) else 0


if __name__ == "__main__":
    raise SystemExit(main())

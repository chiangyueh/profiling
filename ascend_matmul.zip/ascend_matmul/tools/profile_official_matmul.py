#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import os
import signal
import subprocess
import tempfile
from pathlib import Path

from profile_npu_isolated import PROFILE_COLUMNS


SAMPLE_COLUMNS = ["workload_id", "rank", "candidate_role", "sample", "latency_ms"]


def load_workloads(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        fields = set(reader.fieldnames or [])
        id_field = "workload_id" if "workload_id" in fields else "id"
        required = {id_field, "m", "n", "k", "dtype", "trans_a", "trans_b"}
        missing = required - fields
        if missing:
            raise ValueError(f"{path}: missing workload columns: {sorted(missing)}")
        rows = list(reader)
    workloads: list[dict[str, str]] = []
    seen: dict[str, tuple[str, ...]] = {}
    keys = ("m", "n", "k", "dtype", "trans_a", "trans_b")
    for row in rows:
        row = dict(row)
        workload_id = row[id_field]
        row["workload_id"] = workload_id
        signature = tuple(row.get(key, "") for key in keys)
        if workload_id in seen:
            if seen[workload_id] != signature:
                raise ValueError(f"inconsistent workload ID: {workload_id}")
            continue
        seen[workload_id] = signature
        workloads.append(row)
    if not workloads:
        raise ValueError("candidate CSV contains no workloads")
    return workloads


def append_rows(path: Path, columns: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("a", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=columns, extrasaction="ignore")
        writer.writerows(rows)
        destination.flush()


def read_rows(path: Path, expected_columns: list[str]) -> list[dict[str, str]]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        if reader.fieldnames != expected_columns:
            raise ValueError(
                f"{path}: unexpected CSV schema: {reader.fieldnames!r}"
            )
        rows = list(reader)
    for line, row in enumerate(rows, 2):
        if None in row:
            raise ValueError(f"{path}:{line}: row has more fields than the header")
    return rows


def unsupported_row(
    workload: dict[str, str], warmup: int, repeat: int, samples: int
) -> dict[str, str]:
    return {
        "workload_id": workload["workload_id"],
        "rank": "-1",
        "source": "installed_aclnn_matmul",
        "candidate_role": "official_operator_baseline",
        "m": workload["m"],
        "n": workload["n"],
        "k": workload["k"],
        "dtype": workload["dtype"],
        "trans_a": workload["trans_a"],
        "trans_b": workload["trans_b"],
        "execution_mode": "official_matmul_v3",
        "used_core_num": "0",
        "proxy_total": "0",
        "success": "0",
        "preflight_passed": "0",
        "preflight_mode": "",
        "error": f"unsupported_by_aclnnMatmul:{workload['dtype']}",
        "min_ms": "0",
        "mean_ms": "0",
        "median_ms": "0",
        "stddev_ms": "0",
        "p95_ms": "0",
        "max_ms": "0",
        "tflops": "0",
        "warmup": str(warmup),
        "repeat": str(repeat),
        "samples": str(samples),
        "tiling_signature": "installed_cann_aclnn_matmul",
        "tiling_bin": "",
    }


def run_one(
    args: argparse.Namespace,
    workload: dict[str, str],
    index: int,
    total: int,
    temp_dir: Path,
) -> tuple[bool, str]:
    workload_id = workload["workload_id"]
    if workload["dtype"] == "int8":
        append_rows(
            args.output,
            PROFILE_COLUMNS,
            [unsupported_row(workload, args.warmup, args.repeat, args.samples)],
        )
        if index == 1 or index == total or index % args.progress_every == 0:
            print(
                f"official_progress: [{index}/{total}] {workload_id} "
                "unsupported dtype=int8",
                flush=True,
            )
        return True, ""

    temp_profile = temp_dir / f"profile_{index}.csv"
    temp_samples = temp_dir / f"samples_{index}.csv"
    command = [
        str(args.runner),
        "--candidates",
        str(args.workload_source),
        "--output",
        str(temp_profile),
        "--samples-output",
        str(temp_samples),
        "--device",
        str(args.device),
        "--warmup",
        str(args.warmup),
        "--repeat",
        str(args.repeat),
        "--samples",
        str(args.samples),
        "--numeric-preflight-max-mib",
        str(args.numeric_preflight_max_mib),
        "--only-workload",
        workload_id,
    ]
    if index == 1 or index == total or index % args.progress_every == 0:
        print(
            f"official_progress: [{index}/{total}] {workload_id} "
            f"M={workload['m']} N={workload['n']} K={workload['k']} "
            f"dtype={workload['dtype']}",
            flush=True,
        )
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        timeout = args.timeout_sec if args.timeout_sec > 0 else None
        output, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            output, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            output, _ = process.communicate()
        tail = " | ".join(output.splitlines()[-5:])
        error = f"official_baseline_timeout_after_{args.timeout_sec}s; {tail}"
        row = unsupported_row(workload, args.warmup, args.repeat, args.samples)
        row["error"] = error
        append_rows(args.output, PROFILE_COLUMNS, [row])
        print(f"official_timeout: {workload_id} {error}", flush=True)
        return False, error

    profile_rows = read_rows(temp_profile, PROFILE_COLUMNS)
    sample_rows = read_rows(temp_samples, SAMPLE_COLUMNS)
    if profile_rows:
        for row in profile_rows:
            if (
                row.get("workload_id") != workload_id
                or row.get("source") != "installed_aclnn_matmul"
                or row.get("candidate_role") != "official_operator_baseline"
            ):
                raise ValueError(
                    f"{temp_profile}: official runner identity contract failed"
                )
        append_rows(args.output, PROFILE_COLUMNS, profile_rows)
        append_rows(args.samples_output, SAMPLE_COLUMNS, sample_rows)
        success = all(row.get("success") in {"1", "true", "True"} for row in profile_rows)
        if success and process.returncode == 0:
            return True, ""
        error = profile_rows[-1].get("error", "") or f"runner_rc={process.returncode}"
        print(f"official_failed: {workload_id} {error}", flush=True)
        return False, error

    tail = " | ".join(output.splitlines()[-6:])
    error = f"official_runner_failed rc={process.returncode}; {tail}"
    row = unsupported_row(workload, args.warmup, args.repeat, args.samples)
    row["error"] = error
    append_rows(args.output, PROFILE_COLUMNS, [row])
    print(f"official_failed: {workload_id} {error}", flush=True)
    return False, error


def is_fatal_runtime_failure(error: str) -> bool:
    fatal_markers = (
        "aclInit failed",
        "aclrtSetDevice failed",
        "aclrtCreateContext failed",
        "aclrtCreateStream failed",
        "synchronize",
        "timeout_after_",
        "official_runner_failed",
        "symbol lookup error",
        "error while loading shared libraries",
        "507015",
    )
    return any(marker in error for marker in fatal_markers)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument(
        "--workloads",
        type=Path,
        help="original workload CSV; keeps official baselines for shapes rejected by the custom kernel",
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples-output", type=Path, required=True)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--repeat", type=int, default=50)
    parser.add_argument("--samples", type=int, default=15)
    parser.add_argument("--numeric-preflight-max-mib", type=int, default=4)
    parser.add_argument("--timeout-sec", type=int, default=60)
    parser.add_argument("--progress-every", type=int, default=5)
    args = parser.parse_args()
    if args.timeout_sec < 0 or args.progress_every <= 0:
        raise ValueError("timeout-sec must be non-negative and progress-every must be positive")
    args.runner = args.runner.resolve()
    args.candidates = args.candidates.resolve()
    args.workload_source = (
        args.workloads.resolve() if args.workloads is not None else args.candidates
    )
    args.output = args.output.resolve()
    args.samples_output = args.samples_output.resolve()
    if not args.runner.is_file() or not os.access(args.runner, os.X_OK):
        raise FileNotFoundError(f"official runner is not executable: {args.runner}")

    workloads = load_workloads(args.workload_source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.samples_output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as destination:
        csv.DictWriter(destination, fieldnames=PROFILE_COLUMNS).writeheader()
    with args.samples_output.open("w", newline="", encoding="utf-8") as destination:
        csv.DictWriter(destination, fieldnames=SAMPLE_COLUMNS).writeheader()

    failures = 0
    with tempfile.TemporaryDirectory(prefix="official_matmul_", dir=str(args.output.parent)) as temp:
        temp_dir = Path(temp)
        for index, workload in enumerate(workloads, 1):
            success, error = run_one(args, workload, index, len(workloads), temp_dir)
            failures += int(not success)
            if not success and is_fatal_runtime_failure(error):
                print(
                    f"official_abort: fatal runtime failure at {workload['workload_id']}",
                    flush=True,
                )
                break
    print(
        f"official_profile completed workloads={len(workloads)} failures={failures}",
        flush=True,
    )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())

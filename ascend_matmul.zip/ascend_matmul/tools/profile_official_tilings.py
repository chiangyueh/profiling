#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import signal
import struct
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path


PROFILE_COLUMNS = [
    "workload_id", "rank", "source", "candidate_role",
    "m", "n", "k", "dtype", "trans_a", "trans_b", "execution_mode",
    "used_core_num", "hint_single_core_m", "hint_single_core_n", "hint_single_core_k",
    "hint_base_m", "hint_base_n", "hint_base_k",
    "official_base_m", "official_base_n", "official_base_k",
    "official_core_num", "official_m_dim", "official_n_dim",
    "kernel_template", "kernel_single_core_m", "kernel_single_core_n",
    "kernel_single_core_k", "m_base_blocks", "n_base_blocks",
    "m_base_tail", "n_base_tail", "l2_m_tile_count", "l2_n_tile_count",
    "l2_m_tile_block", "l2_n_tile_block", "l2_iterate_order",
    "proxy_total", "success", "preflight_passed", "preflight_mode", "error",
    "min_ms", "mean_ms", "median_ms", "stddev_ms", "p95_ms", "max_ms", "tflops",
    "warmup", "repeat", "samples", "tiling_signature", "tiling_bin",
]
SAMPLE_COLUMNS = ["workload_id", "rank", "candidate_role", "sample", "latency_ms"]

INFO_KEYS = {
    "a_dtype", "a_format", "aub_double_num", "b_dtype", "b_format",
    "batch_a1", "batch_a2", "batch_a3", "batch_a4",
    "batch_b1", "batch_b2", "batch_b3", "batch_b4",
    "bias_flag", "bub_double_num", "fused_double_operand_num",
    "k", "k_align_flag", "l1_fused_num", "m", "m_align_flag",
    "n", "n_align_flag", "out_dtype", "out_format", "reserved_bool",
    "reserved_params1", "reserved_params2", "reserved_params3",
    "reserved_params4", "reserved_params5", "reserved_params6",
    "trans_a_flag", "trans_b_flag",
}
KNOWLEDGE_KEYS = {
    "usedCoreNum", "singleCoreM", "singleCoreN", "singleCoreK",
    "baseM", "baseN", "baseK", "depthA1", "depthB1", "stepM", "stepN",
    "iterateOrder", "stepKa", "stepKb", "dbL0A", "dbL0B", "dbL0C",
    "l2MTileCnt", "l2NTileCnt", "l2MTileBlock", "l2NTileBlock",
    "l2IterateOrder", "tilingEnable",
}


class ProfileError(RuntimeError):
    pass


class RunnerProfileError(ProfileError):
    def __init__(
        self,
        message: str,
        row: dict[str, str],
        samples: list[dict[str, str]],
        output: str,
        return_code: int,
    ) -> None:
        super().__init__(message)
        self.row = row
        self.samples = samples
        self.output = output
        self.return_code = return_code


@dataclass(frozen=True)
class BankSpec:
    soc: str
    aic_cores: int
    filename: str
    version: int
    template: dict


def truthy(value: str | bool | None) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").lower() in {"1", "true", "yes", "on"}


def align_up(value: int, alignment: int) -> int:
    return (value + alignment - 1) // alignment * alignment


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", value)


def as_float(row: dict[str, str], name: str) -> float:
    try:
        return float(row.get(name, ""))
    except (TypeError, ValueError):
        return float("nan")


def compact(value: float) -> str:
    return f"{value:.6g}" if math.isfinite(value) else "NA"


def comparison_status(
    baseline: dict[str, str], candidate: dict[str, str]
) -> tuple[float, float, float, str]:
    baseline_ms = as_float(baseline, "median_ms")
    candidate_ms = as_float(candidate, "median_ms")
    if baseline_ms <= 0 or candidate_ms <= 0:
        return float("nan"), float("nan"), float("nan"), "invalid_measurement"
    baseline_stddev = max(0.0, as_float(baseline, "stddev_ms"))
    candidate_stddev = max(0.0, as_float(candidate, "stddev_ms"))
    if not math.isfinite(baseline_stddev):
        baseline_stddev = 0.0
    if not math.isfinite(candidate_stddev):
        candidate_stddev = 0.0
    speedup = baseline_ms / candidate_ms
    delta_pct = 100.0 * (candidate_ms - baseline_ms) / baseline_ms
    noise_pct = max(
        1.0,
        200.0 * math.hypot(baseline_stddev, candidate_stddev) / baseline_ms,
    )
    if delta_pct < -noise_pct:
        status = "improved"
    elif delta_pct > noise_pct:
        status = "regressed"
    else:
        status = "within_noise"
    return speedup, delta_pct, noise_pct, status


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        rows = list(reader)
    if not reader.fieldnames:
        raise ProfileError(f"{path}: missing CSV header")
    for line, row in enumerate(rows, 2):
        if None in row:
            raise ProfileError(f"{path}:{line}: row has more values than its header")
    return rows


def load_workloads(path: Path) -> list[dict[str, str]]:
    rows = read_csv(path)
    if not rows:
        raise ProfileError(f"{path}: no workloads")
    id_key = "workload_id" if "workload_id" in rows[0] else "id"
    required = {id_key, "m", "n", "k", "dtype", "trans_a", "trans_b"}
    missing = required - set(rows[0])
    if missing:
        raise ProfileError(f"{path}: missing workload columns: {sorted(missing)}")
    workloads: list[dict[str, str]] = []
    seen: set[str] = set()
    for source in rows:
        workload = dict(source)
        workload["workload_id"] = source[id_key]
        if workload["workload_id"] in seen:
            continue
        seen.add(workload["workload_id"])
        workloads.append(workload)
    return workloads


def write_header(path: Path, columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as destination:
        csv.DictWriter(destination, fieldnames=columns).writeheader()


def append_row(path: Path, columns: list[str], row: dict[str, str]) -> None:
    with path.open("a", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=columns, extrasaction="ignore")
        writer.writerow(row)
        destination.flush()


def append_samples(
    path: Path,
    rows: list[dict[str, str]],
    rank: str,
    candidate_role: str,
) -> None:
    with path.open("a", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=SAMPLE_COLUMNS)
        for source in rows:
            row = dict(source)
            row["rank"] = rank
            row["candidate_role"] = candidate_role
            writer.writerow(row)
        destination.flush()


def pack_info(info: dict) -> bytes:
    values = [
        int(info["m"]), int(info["k"]), int(info["n"]),
        int(info["batch_a1"]), int(info["batch_a2"]),
        int(info["batch_a3"]), int(info["batch_a4"]),
        int(info["batch_b1"]), int(info["batch_b2"]),
        int(info["batch_b3"]), int(info["batch_b4"]),
        float(info["l1_fused_num"]), float(info["aub_double_num"]),
        float(info["bub_double_num"]), float(info["fused_double_operand_num"]),
        int(info["a_dtype"]), int(info["b_dtype"]), int(info["out_dtype"]),
        int(info["a_format"]), int(info["b_format"]), int(info["out_format"]),
        bool(info["trans_a_flag"]), bool(info["trans_b_flag"]),
        bool(info["bias_flag"]), bool(info["reserved_bool"]),
        bool(info["m_align_flag"]), bool(info["k_align_flag"]),
        bool(info["n_align_flag"]),
        int(info["reserved_params1"]), int(info["reserved_params2"]),
        int(info["reserved_params3"]), int(info["reserved_params4"]),
        int(info["reserved_params5"]), int(info["reserved_params6"]),
    ]
    packed = struct.pack("<11q4f6i7?6Q", *values)
    if len(packed) != 183:
        raise ProfileError(f"internal MatMulV3 key size error: {len(packed)}")
    return packed


def probe_hash(probe: Path, key_path: Path) -> int:
    result = subprocess.run(
        [str(probe), "--hash", str(key_path)],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if result.returncode != 0:
        raise ProfileError(
            f"RuntimeKb::CommonHash failed rc={result.returncode}: "
            f"{result.stdout.strip()}"
        )
    try:
        return int(result.stdout.strip())
    except ValueError as exception:
        raise ProfileError(f"invalid tiling-bank hash output: {result.stdout!r}") from exception


def discover_bank(
    cann_root: Path,
    soc: str,
    aic_cores: int,
    probe: Path,
    work_dir: Path,
) -> BankSpec:
    bank_dir = cann_root / "opp" / "built-in" / "data" / "op" / soc / "unified_bank"
    expected = bank_dir / f"{soc}_{aic_cores}_AiCore_MatMulV3_runtime_kb.json"
    if not expected.is_file():
        available = sorted(path.name for path in bank_dir.glob("*MatMulV3_runtime_kb.json"))
        raise ProfileError(
            "installed CANN has no matching MatMulV3 runtime bank: "
            f"expected={expected}; available={available}"
        )
    with expected.open(encoding="utf-8") as source:
        first_line = next((line for line in source if line.strip()), "")
    if not first_line:
        raise ProfileError(f"installed MatMulV3 runtime bank is empty: {expected}")
    template = json.loads(first_line)
    if template.get("op") != "MatMulV3":
        raise ProfileError(f"unexpected runtime-bank op in {expected}")
    info = template.get("info_dict")
    knowledge = template.get("knowledge")
    if not isinstance(info, dict) or set(info) != INFO_KEYS:
        raise ProfileError(
            "unsupported CANN MatMulV3 input-key schema; "
            f"missing={sorted(INFO_KEYS - set(info or {}))} "
            f"extra={sorted(set(info or {}) - INFO_KEYS)}"
        )
    if not isinstance(knowledge, dict) or set(knowledge) != KNOWLEDGE_KEYS:
        raise ProfileError(
            "unsupported CANN MatMulV3 knowledge schema; "
            f"missing={sorted(KNOWLEDGE_KEYS - set(knowledge or {}))} "
            f"extra={sorted(set(knowledge or {}) - KNOWLEDGE_KEYS)}"
        )

    key_path = work_dir / "installed_bank_key.bin"
    key_path.write_bytes(pack_info(info))
    observed_hash = probe_hash(probe, key_path)
    expected_hash = int(template.get("id", -1))
    if observed_hash != expected_hash:
        raise ProfileError(
            "CANN MatMulV3 runtime-bank ABI mismatch: "
            f"stored_id={expected_hash} computed_id={observed_hash}"
        )
    return BankSpec(
        soc=soc,
        aic_cores=aic_cores,
        filename=expected.name,
        version=int(template.get("version", 0)),
        template=template,
    )


def make_info(row: dict[str, str]) -> dict:
    dtype = row["dtype"].lower()
    if dtype not in {"fp16", "bf16", "fp32"}:
        raise ProfileError(f"MatMulV3 tuning bank does not support dtype={dtype}")
    dtype_code = 0 if dtype == "fp32" else 1
    reduce_alignment = 8 if dtype == "fp32" else 16
    m = int(row["m"])
    n = int(row["n"])
    k = int(row["k"])
    aligned_m = align_up(m, 16)
    aligned_n = align_up(n, 16)
    aligned_k = align_up(k, reduce_alignment)
    return {
        "a_dtype": dtype_code,
        "a_format": 2,
        "aub_double_num": 1.0,
        "b_dtype": dtype_code,
        "b_format": 2,
        "batch_a1": 1,
        "batch_a2": 1,
        "batch_a3": 1,
        "batch_a4": 1,
        "batch_b1": 1,
        "batch_b2": 1,
        "batch_b3": 1,
        "batch_b4": 1,
        "bias_flag": False,
        "bub_double_num": 1.0,
        "fused_double_operand_num": 0.0,
        "k": aligned_k,
        "k_align_flag": k == aligned_k,
        "l1_fused_num": 0.0,
        "m": aligned_m,
        "m_align_flag": m == aligned_m,
        "n": aligned_n,
        "n_align_flag": n == aligned_n,
        "out_dtype": dtype_code,
        "out_format": 2,
        "reserved_bool": False,
        "reserved_params1": 0,
        "reserved_params2": 0,
        "reserved_params3": 0,
        "reserved_params4": 0,
        "reserved_params5": 0,
        "reserved_params6": 0,
        "trans_a_flag": truthy(row.get("trans_a")),
        "trans_b_flag": truthy(row.get("trans_b")),
    }


def require_int(row: dict[str, str], name: str, minimum: int = 1) -> int:
    try:
        value = int(row[name])
    except (KeyError, ValueError) as exception:
        raise ProfileError(f"candidate has invalid {name}={row.get(name)!r}") from exception
    if value < minimum:
        raise ProfileError(f"candidate has invalid {name}={value}")
    return value


def validate_candidate(row: dict[str, str], spec: BankSpec) -> None:
    if row.get("candidate_role") != "searched" or not truthy(row.get("valid")):
        raise ProfileError("only valid searched candidates may enter the tuning bank")
    if int(row.get("official_return", "-1")) == -1:
        raise ProfileError("candidate was rejected by MultiCoreMatmulTiling")

    used_cores = require_int(row, "used_core_num")
    official_cores = require_int(row, "official_core_num")
    if used_cores != official_cores:
        raise ProfileError(
            f"used_core_num={used_cores} differs from official_core_num={official_cores}"
        )
    if used_cores > spec.aic_cores:
        raise ProfileError(
            f"used_core_num={used_cores} exceeds MatMulV3 AIC count={spec.aic_cores}"
        )

    single_m = require_int(row, "single_core_m")
    single_n = require_int(row, "single_core_n")
    single_k = require_int(row, "single_core_k")
    base_m = require_int(row, "base_m")
    base_n = require_int(row, "base_n")
    base_k = require_int(row, "base_k")
    dtype = row["dtype"].lower()
    k0 = 8 if dtype == "fp32" else 16
    if base_m % 16 or base_n % 16 or base_k % k0:
        raise ProfileError(
            f"base tile {base_m}x{base_n}x{base_k} violates Cube alignment"
        )
    if base_m > align_up(single_m, 16) or base_n > align_up(single_n, 16):
        raise ProfileError("base M/N exceeds aligned single-core M/N")
    if base_k > align_up(single_k, k0):
        raise ProfileError("base K exceeds aligned single-core K")

    step_m = require_int(row, "step_m")
    step_n = require_int(row, "step_n")
    step_ka = require_int(row, "step_ka")
    step_kb = require_int(row, "step_kb")
    depth_a = require_int(row, "depth_a1")
    depth_b = require_int(row, "depth_b1")
    if depth_a % (step_m * step_ka) or depth_b % (step_n * step_kb):
        raise ProfileError("L1 depth is incompatible with stepM/N and stepKa/Kb")
    for name in ("db_l0a", "db_l0b", "db_l0c"):
        value = require_int(row, name)
        if value > 2:
            raise ProfileError(f"{name}={value} is outside [1,2]")

    mode = row.get("execution_mode", "")
    k_parts = math.ceil(int(row["k"]) / single_k)
    if mode == "base_iterate_all":
        if k_parts != 1:
            raise ProfileError("base_iterate_all candidate splits K across cores")
        if single_m != base_m or single_n != base_n:
            raise ProfileError(
                "MatMulV3 tilingEnable=BASE requires single_core_m/n == base_m/n; "
                f"received single={single_m}x{single_n}, base={base_m}x{base_n}"
            )
    elif mode == "direct_atomic_split_k_fp32_nt":
        if dtype != "fp32" or truthy(row.get("trans_a")) or not truthy(row.get("trans_b")):
            raise ProfileError("multi-core split-K violates MatMulV3 FP32 NT contract")
        logical_tiles = (
            math.ceil(int(row["m"]) / single_m)
            * math.ceil(int(row["n"]) / single_n)
            * k_parts
        )
        if logical_tiles > spec.aic_cores:
            raise ProfileError("multi-core split-K requires one scheduling round")
    else:
        raise ProfileError(f"unsupported MatMulV3 execution_mode={mode!r}")


def make_knowledge(row: dict[str, str]) -> dict:
    tiling_enable = (
        4 if row["execution_mode"] == "direct_atomic_split_k_fp32_nt" else 0
    )
    single_m = int(row["single_core_m"])
    single_n = int(row["single_core_n"])
    m_tile_total = math.ceil(int(row["m"]) / single_m)
    n_tile_total = math.ceil(int(row["n"]) / single_n)
    if m_tile_total < 1 or n_tile_total < 1:
        raise ProfileError(
            "candidate has an empty MatMulV3 M/N scheduling domain"
        )

    # The BASE kernel schedules singleCoreM x singleCoreN output blocks.
    # Keep each L2 tile close to one full-core round, matching the official
    # MatMulV3 fallback (4 M blocks and AIC/4 N blocks).
    used_cores = int(row["used_core_num"])
    l2_m_tile_block = max(1, min(4, m_tile_total, used_cores))
    l2_n_tile_block = max(
        1,
        min(n_tile_total, max(1, used_cores // l2_m_tile_block)),
    )
    l2_m_tile_count = math.ceil(m_tile_total / l2_m_tile_block)
    l2_n_tile_count = math.ceil(n_tile_total / l2_n_tile_block)
    m_tail_blocks = m_tile_total - (l2_m_tile_count - 1) * l2_m_tile_block
    n_tail_blocks = n_tile_total - (l2_n_tile_count - 1) * l2_n_tile_block
    if not (
        1 <= m_tail_blocks <= l2_m_tile_block
        and 1 <= n_tail_blocks <= l2_n_tile_block
    ):
        raise ProfileError("generated L2 schedule does not exactly cover M/N blocks")

    return {
        "usedCoreNum": used_cores,
        "singleCoreM": single_m,
        "singleCoreN": single_n,
        "singleCoreK": int(row["single_core_k"]),
        "baseM": int(row["base_m"]),
        "baseN": int(row["base_n"]),
        "baseK": int(row["base_k"]),
        "depthA1": int(row["depth_a1"]),
        "depthB1": int(row["depth_b1"]),
        "stepM": int(row["step_m"]),
        "stepN": int(row["step_n"]),
        "iterateOrder": int(row["iterate_order"]),
        "stepKa": int(row["step_ka"]),
        "stepKb": int(row["step_kb"]),
        "dbL0A": int(row["db_l0a"]),
        "dbL0B": int(row["db_l0b"]),
        "dbL0C": int(row["db_l0c"]),
        "l2MTileCnt": l2_m_tile_count,
        "l2NTileCnt": l2_n_tile_count,
        "l2MTileBlock": l2_m_tile_block,
        "l2NTileBlock": l2_n_tile_block,
        "l2IterateOrder": 0,
        "tilingEnable": tiling_enable,
    }


def create_candidate_bank(
    row: dict[str, str],
    spec: BankSpec,
    probe: Path,
    root: Path,
    cache_root: Path,
) -> tuple[dict[str, str], str, dict]:
    validate_candidate(row, spec)
    info = make_info(row)
    knowledge = make_knowledge(row)
    key = pack_info(info)
    key_path = root / "matmul_v3_input.bin"
    key_path.parent.mkdir(parents=True, exist_ok=True)
    key_path.write_bytes(key)
    record_id = probe_hash(probe, key_path)
    record = {
        "id": record_id,
        "info_dict": info,
        "knowledge": knowledge,
        "op": "MatMulV3",
        "version": spec.version,
    }
    bank_file = root / spec.soc / "unified_bank" / spec.filename
    bank_file.parent.mkdir(parents=True, exist_ok=True)
    bank_file.write_text(
        json.dumps(record, separators=(",", ":"), ensure_ascii=True) + "\n",
        encoding="utf-8",
    )

    env = os.environ.copy()
    env["TUNE_BANK_PATH"] = str(root)
    env["ASCEND_CACHE_PATH"] = str(cache_root)
    query = subprocess.run(
        [
            str(probe), "--query", str(key_path),
            spec.soc, str(spec.aic_cores),
        ],
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    query_output = query.stdout.strip()
    if query.returncode != 0:
        raise ProfileError(
            "CANN rejected generated MatMulV3 tuning-bank record: "
            f"rc={query.returncode} output={query_output}"
        )
    if "found=1" in query_output:
        query_mode = "runtime_kb"
    else:
        raise ProfileError(
            "generated MatMulV3 bank record was not found by RuntimeKb: "
            f"output={query_output}"
        )
    return env, query_mode, knowledge


def run_official(
    runner: Path,
    workload_source: Path,
    workload_id: str,
    output_dir: Path,
    env: dict[str, str],
    args: argparse.Namespace,
) -> tuple[dict[str, str], list[dict[str, str]]]:
    profile_path = output_dir / "profile.csv"
    samples_path = output_dir / "samples.csv"
    command = [
        str(runner),
        "--candidates", str(workload_source),
        "--output", str(profile_path),
        "--samples-output", str(samples_path),
        "--device", str(args.device),
        "--warmup", str(args.warmup),
        "--repeat", str(args.repeat),
        "--samples", str(args.samples),
        "--numeric-preflight-max-mib", str(args.numeric_preflight_max_mib),
        "--only-workload", workload_id,
    ]
    process = subprocess.Popen(
        command,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True,
    )
    try:
        output, _ = process.communicate(
            timeout=args.timeout_sec if args.timeout_sec > 0 else None
        )
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            output, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            output, _ = process.communicate()
        tail = " | ".join(output.splitlines()[-6:])
        message = f"official MatMulV3 timeout after {args.timeout_sec}s"
        if tail:
            message += f"; {tail}"
        sample_rows: list[dict[str, str]] = []
        try:
            sample_rows = read_csv(samples_path) if samples_path.is_file() else []
        except (OSError, ProfileError):
            pass
        row = {column: "" for column in PROFILE_COLUMNS}
        row.update({
            "workload_id": workload_id,
            "success": "0",
            "preflight_passed": "0",
            "error": message,
        })
        raise RunnerProfileError(
            message, row, sample_rows, output, process.returncode or 124
        )

    profile_rows = read_csv(profile_path) if profile_path.is_file() else []
    sample_rows = read_csv(samples_path) if samples_path.is_file() else []
    if len(profile_rows) != 1:
        tail = " | ".join(output.splitlines()[-8:])
        message = (
            f"official runner produced {len(profile_rows)} rows "
            f"(rc={process.returncode}); {tail}"
        )
        row = {column: "" for column in PROFILE_COLUMNS}
        row.update({
            "workload_id": workload_id,
            "success": "0",
            "preflight_passed": "0",
            "error": message,
        })
        raise RunnerProfileError(
            message, row, sample_rows, output, process.returncode
        )
    row = profile_rows[0]
    if row.get("workload_id") != workload_id:
        raise ProfileError("official runner returned the wrong workload")
    if process.returncode != 0 or not truthy(row.get("success")):
        raise RunnerProfileError(
            row.get("error") or f"official MatMulV3 runner rc={process.returncode}",
            row,
            sample_rows,
            output,
            process.returncode,
        )
    return row, sample_rows


def candidate_profile(
    candidate: dict[str, str] | None,
    measured: dict[str, str],
    rank: str,
    source: str,
    role: str,
    knowledge: dict | None = None,
) -> dict[str, str]:
    result = dict(measured)
    result.update({
        "rank": rank,
        "source": source,
        "candidate_role": role,
    })
    if candidate is None:
        return result
    mapping = {
        "execution_mode": "execution_mode",
        "used_core_num": "used_core_num",
        "hint_single_core_m": "candidate_single_core_m",
        "hint_single_core_n": "candidate_single_core_n",
        "hint_single_core_k": "candidate_single_core_k",
        "hint_base_m": "candidate_base_m",
        "hint_base_n": "candidate_base_n",
        "hint_base_k": "candidate_base_k",
        "official_base_m": "base_m",
        "official_base_n": "base_n",
        "official_base_k": "base_k",
        "official_core_num": "official_core_num",
        "official_m_dim": "official_m_dim",
        "official_n_dim": "official_n_dim",
        "proxy_total": "proxy_total",
        "tiling_signature": "tiling_signature",
        "tiling_bin": "tiling_bin",
    }
    for destination, origin in mapping.items():
        result[destination] = candidate.get(origin, "")
    if knowledge is not None:
        single_m = int(knowledge["singleCoreM"])
        single_n = int(knowledge["singleCoreN"])
        m = int(candidate["m"])
        n = int(candidate["n"])
        m_blocks = math.ceil(m / single_m)
        n_blocks = math.ceil(n / single_n)
        result.update({
            "used_core_num": str(knowledge["usedCoreNum"]),
            "kernel_template": (
                "MatMulV3_MULTI_CORE_SPLIT_K"
                if knowledge["tilingEnable"] == 4
                else "MatMulV3_BASE"
            ),
            "kernel_single_core_m": str(knowledge["singleCoreM"]),
            "kernel_single_core_n": str(knowledge["singleCoreN"]),
            "kernel_single_core_k": str(knowledge["singleCoreK"]),
            "m_base_blocks": str(m_blocks),
            "n_base_blocks": str(n_blocks),
            "m_base_tail": str(m - (m_blocks - 1) * single_m),
            "n_base_tail": str(n - (n_blocks - 1) * single_n),
            "l2_m_tile_count": str(knowledge["l2MTileCnt"]),
            "l2_n_tile_count": str(knowledge["l2NTileCnt"]),
            "l2_m_tile_block": str(knowledge["l2MTileBlock"]),
            "l2_n_tile_block": str(knowledge["l2NTileBlock"]),
            "l2_iterate_order": str(knowledge["l2IterateOrder"]),
        })
    return result


def schedule_text(candidate: dict[str, str], knowledge: dict) -> str:
    m_blocks = math.ceil(int(candidate["m"]) / int(knowledge["singleCoreM"]))
    n_blocks = math.ceil(int(candidate["n"]) / int(knowledge["singleCoreN"]))
    template = "SPLIT_K" if knowledge["tilingEnable"] == 4 else "BASE"
    return (
        f"tpl={template} "
        f"T={knowledge['baseM']}x{knowledge['baseN']}x{knowledge['baseK']} "
        f"S={knowledge['singleCoreM']}x{knowledge['singleCoreN']}x"
        f"{knowledge['singleCoreK']} C={knowledge['usedCoreNum']} "
        f"G={m_blocks}x{n_blocks} "
        f"L2={knowledge['l2MTileCnt']}x{knowledge['l2NTileCnt']}"
        f"({knowledge['l2MTileBlock']}x{knowledge['l2NTileBlock']})"
    )


def print_tiling_failure(
    candidate: dict[str, str],
    knowledge: dict,
    error: RunnerProfileError,
) -> None:
    message = str(error)
    index_match = re.search(r"C index=(\d+)", message)
    observed_match = re.search(r"observed=([^,\s]+)", message)
    index = int(index_match.group(1)) if index_match else None
    n = int(candidate["n"])
    row = index // n if index is not None else None
    column = index % n if index is not None else None
    lower_message = message.lower()
    if "timeout" in lower_message:
        classification = "candidate_timeout"
        evidence = "the isolated official MatMulV3 process made no completion progress"
    elif index is not None and observed_match and observed_match.group(1).lower().startswith("0x5a"):
        classification = "output_not_written"
        evidence = "output still contains the 0x5a preflight poison value"
    elif "coverage failed" in message:
        classification = "output_coverage_failure"
        evidence = "at least one sampled output element was not produced"
    elif "507015" in message:
        classification = "aicore_exception"
        evidence = "the candidate raised an AICore exception during synchronization"
    else:
        classification = "candidate_execution_failure"
        evidence = "the official MatMulV3 candidate process returned failure"

    print("TILING_ERROR_BEGIN", flush=True)
    print(
        f"workload={candidate['workload_id']} rank={candidate['rank']} "
        f"shape={candidate['m']}x{candidate['n']}x{candidate['k']} "
        f"dtype={candidate['dtype']} trans={candidate['trans_a']}{candidate['trans_b']}",
        flush=True,
    )
    print(f"schedule: {schedule_text(candidate, knowledge)}", flush=True)
    print(
        "l1: "
        f"depth={knowledge['depthA1']}x{knowledge['depthB1']} "
        f"stepMN={knowledge['stepM']}x{knowledge['stepN']} "
        f"stepK={knowledge['stepKa']}x{knowledge['stepKb']} "
        f"db={knowledge['dbL0A']}x{knowledge['dbL0B']}x{knowledge['dbL0C']}",
        flush=True,
    )
    if "preflight" in lower_message:
        stage = "preflight"
    elif "warmup" in lower_message:
        stage = "warmup"
    elif "sample" in lower_message:
        stage = "timing"
    elif "timeout" in lower_message:
        stage = "timeout"
    else:
        stage = "runner"
    print(f"failure: stage={stage} classification={classification}", flush=True)
    print(f"error: {message}", flush=True)
    if index is not None:
        print(
            f"location: C_index={index} row={row} col={column} "
            f"observed={observed_match.group(1) if observed_match else 'unknown'}",
            flush=True,
        )
    print(f"evidence: {evidence}", flush=True)
    print(
        "contract: static=passed runtime_kb=found npu_preflight=failed",
        flush=True,
    )
    output_tail = [
        line.strip()
        for line in error.output.splitlines()
        if line.strip()
    ][-3:]
    if output_tail:
        print(f"runner_tail: {' | '.join(output_tail)}", flush=True)
    print("TILING_ERROR_END", flush=True)


def unsupported_profile(
    workload: dict[str, str],
    rank: str,
    source: str,
    role: str,
    args: argparse.Namespace,
) -> dict[str, str]:
    row = {column: "" for column in PROFILE_COLUMNS}
    row.update({
        "workload_id": workload["workload_id"],
        "rank": rank,
        "source": source,
        "candidate_role": role,
        "m": workload["m"],
        "n": workload["n"],
        "k": workload["k"],
        "dtype": workload["dtype"],
        "trans_a": workload["trans_a"],
        "trans_b": workload["trans_b"],
        "execution_mode": "unsupported",
        "success": "0",
        "preflight_passed": "0",
        "error": f"unsupported_by_MatMulV3:{workload['dtype']}",
        "min_ms": "0",
        "mean_ms": "0",
        "median_ms": "0",
        "stddev_ms": "0",
        "p95_ms": "0",
        "max_ms": "0",
        "tflops": "0",
        "warmup": str(args.warmup),
        "repeat": str(args.repeat),
        "samples": str(args.samples),
    })
    return row


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Profile searched tilings through the official CANN MatMulV3 kernel."
    )
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--bank-probe", type=Path, required=True)
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--workloads", type=Path, required=True)
    parser.add_argument("--custom-output", type=Path, required=True)
    parser.add_argument("--custom-samples-output", type=Path, required=True)
    parser.add_argument("--official-output", type=Path, required=True)
    parser.add_argument("--official-samples-output", type=Path, required=True)
    parser.add_argument("--cann-root", type=Path, required=True)
    parser.add_argument("--soc", required=True)
    parser.add_argument("--aic-cores", type=int, required=True)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--repeat", type=int, default=50)
    parser.add_argument("--samples", type=int, default=15)
    parser.add_argument("--rank-limit", type=int, default=20)
    parser.add_argument("--numeric-preflight-max-mib", type=int, default=4)
    parser.add_argument("--timeout-sec", type=int, default=60)
    parser.add_argument("--progress-every", type=int, default=10)
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="validate every candidate against CANN RuntimeKb without using the NPU",
    )
    args = parser.parse_args()

    for executable in (args.runner, args.bank_probe):
        executable = executable.resolve()
        if not executable.is_file() or not os.access(executable, os.X_OK):
            raise ProfileError(f"required executable is missing: {executable}")
    args.runner = args.runner.resolve()
    args.bank_probe = args.bank_probe.resolve()
    args.candidates = args.candidates.resolve()
    args.workloads = args.workloads.resolve()
    args.cann_root = args.cann_root.resolve()
    if args.aic_cores <= 0 or args.rank_limit <= 0:
        raise ProfileError("aic-cores and rank-limit must be positive")
    if args.repeat <= 0 or args.samples <= 0 or args.warmup < 0:
        raise ProfileError("warmup/repeat/samples values are invalid")

    candidates = read_csv(args.candidates)
    workloads = load_workloads(args.workloads)
    grouped: dict[str, list[dict[str, str]]] = {}
    for row in candidates:
        grouped.setdefault(row["workload_id"], []).append(row)
    for rows in grouped.values():
        rows.sort(key=lambda row: int(row.get("rank", "0")))

    write_header(args.custom_output, PROFILE_COLUMNS)
    write_header(args.custom_samples_output, SAMPLE_COLUMNS)
    write_header(args.official_output, PROFILE_COLUMNS)
    write_header(args.official_samples_output, SAMPLE_COLUMNS)

    supported_candidates = [
        row
        for row in candidates
        if row.get("candidate_role") == "searched"
        and 0 < int(row.get("rank", "0")) <= args.rank_limit
        and row.get("dtype", "").lower() in {"fp16", "bf16", "fp32"}
    ]

    with tempfile.TemporaryDirectory(
        prefix="matmul_v3_bank_", dir=str(args.custom_output.parent)
    ) as temporary:
        work_dir = Path(temporary)
        cache_root = work_dir / "empty_cache"
        cache_root.mkdir()
        spec = discover_bank(
            args.cann_root, args.soc, args.aic_cores, args.bank_probe, work_dir
        )
        print(
            f"bank_schema: soc={spec.soc} aic={spec.aic_cores} "
            "input_bytes=183 knowledge_fields=23",
            flush=True,
        )

        prepared_candidates: dict[
            tuple[str, str], tuple[dict[str, str], dict]
        ] = {}
        query_modes: set[str] = set()
        for validation_index, candidate in enumerate(supported_candidates, 1):
            workload_id = candidate["workload_id"]
            rank = candidate["rank"]
            candidate_root = (
                work_dir / "candidate" /
                f"{safe_name(workload_id)}_rank{rank}"
            )
            bank_root = candidate_root / "bank"
            candidate_cache = candidate_root / "cache"
            candidate_cache.mkdir(parents=True)
            candidate_env, query_mode, knowledge = create_candidate_bank(
                candidate, spec, args.bank_probe, bank_root, candidate_cache
            )
            prepared_candidates[(workload_id, rank)] = (candidate_env, knowledge)
            query_modes.add(query_mode)
            if (
                validation_index == 1
                or validation_index == len(supported_candidates)
                or validation_index % 50 == 0
            ):
                print(
                    f"bank_lookup: [{validation_index}/{len(supported_candidates)}] "
                    f"{workload_id} rank={rank}",
                    flush=True,
                )
        print(
            f"bank_records_prepared: {len(prepared_candidates)} "
            f"lookup={'+'.join(sorted(query_modes))}(found=1) "
            "execution_check=NPU_preflight",
            flush=True,
        )
        if args.validate_only:
            return 0

        empty_bank = work_dir / "empty_bank"
        empty_bank.mkdir()
        baseline_env = os.environ.copy()
        baseline_env["TUNE_BANK_PATH"] = str(empty_bank)
        baseline_env["ASCEND_CACHE_PATH"] = str(cache_root)

        candidate_index = 0
        unsupported = 0
        print(f"profile_plan: workloads={len(workloads)}", flush=True)
        for workload_index, workload in enumerate(workloads, 1):
            workload_id = workload["workload_id"]
            rows = grouped.get(workload_id, [])
            if workload["dtype"].lower() not in {"fp16", "bf16", "fp32"}:
                unsupported += 1
                official = unsupported_profile(
                    workload, "-1", "installed_aclnn_matmul",
                    "official_operator_baseline", args,
                )
                api_auto = unsupported_profile(
                    workload, "0", "official_default", "api_auto_baseline", args
                )
                append_row(args.official_output, PROFILE_COLUMNS, official)
                append_row(args.custom_output, PROFILE_COLUMNS, api_auto)
                print(
                    f"workload_skip: [{workload_index}/{len(workloads)}] "
                    f"{workload_id} dtype={workload['dtype']} not supported by MatMulV3",
                    flush=True,
                )
                continue

            baseline_dir = work_dir / "baseline" / safe_name(workload_id)
            baseline_dir.mkdir(parents=True)
            try:
                measured, samples = run_official(
                    args.runner, args.workloads, workload_id,
                    baseline_dir, baseline_env, args,
                )
            except RunnerProfileError as exception:
                append_row(args.official_output, PROFILE_COLUMNS, exception.row)
                print("OFFICIAL_BASELINE_ERROR_BEGIN", flush=True)
                print(
                    f"workload={workload_id} "
                    f"shape={workload['m']}x{workload['n']}x{workload['k']} "
                    f"dtype={workload['dtype']}",
                    flush=True,
                )
                print(f"error={exception}", flush=True)
                print("OFFICIAL_BASELINE_ERROR_END", flush=True)
                raise ProfileError(
                    f"installed official MatMulV3 baseline failed for {workload_id}"
                ) from exception
            append_row(args.official_output, PROFILE_COLUMNS, measured)
            append_samples(
                args.official_samples_output, samples,
                "-1", "official_operator_baseline",
            )
            api_auto = candidate_profile(
                None, measured, "0",
                "official_default", "api_auto_baseline",
            )
            append_row(args.custom_output, PROFILE_COLUMNS, api_auto)
            append_samples(
                args.custom_samples_output, samples, "0", "api_auto_baseline"
            )
            official_baseline = measured
            print(
                f"WORKLOAD [{workload_index}/{len(workloads)}] {workload_id} "
                f"shape={workload['m']}x{workload['n']}x{workload['k']} "
                f"dtype={workload['dtype']} "
                f"official_ms={compact(as_float(measured, 'median_ms'))} "
                f"std={compact(as_float(measured, 'stddev_ms'))} "
                f"tflops={compact(as_float(measured, 'tflops'))}",
                flush=True,
            )

            searched = [
                row
                for row in rows
                if row.get("candidate_role") == "searched"
                and 0 < int(row.get("rank", "0")) <= args.rank_limit
            ]
            best_ms = float("inf")
            best_rank = ""
            best_status = ""
            for candidate in searched:
                candidate_index += 1
                rank = candidate["rank"]
                candidate_root = (
                    work_dir / "candidate" /
                    f"{safe_name(workload_id)}_rank{rank}"
                )
                candidate_env, knowledge = prepared_candidates[(workload_id, rank)]
                run_dir = candidate_root / "run"
                run_dir.mkdir()
                show_progress = (
                    rank == "1"
                    or candidate_index == len(supported_candidates)
                    or candidate_index % args.progress_every == 0
                )
                if show_progress:
                    print(
                        f"candidate_start [{candidate_index}/{len(supported_candidates)}] "
                        f"{workload_id} rank={rank} {schedule_text(candidate, knowledge)}",
                        flush=True,
                    )
                try:
                    measured, samples = run_official(
                        args.runner, args.workloads, workload_id,
                        run_dir, candidate_env, args,
                    )
                except RunnerProfileError as exception:
                    failed = candidate_profile(
                        candidate,
                        exception.row,
                        rank,
                        candidate.get("source", "searched"),
                        "searched",
                        knowledge,
                    )
                    append_row(args.custom_output, PROFILE_COLUMNS, failed)
                    append_samples(
                        args.custom_samples_output,
                        exception.samples,
                        rank,
                        "searched",
                    )
                    print_tiling_failure(candidate, knowledge, exception)
                    print(
                        f"partial_profile: completed_candidates={candidate_index - 1} "
                        f"failed_candidate={candidate_index}",
                        flush=True,
                    )
                    raise ProfileError(
                        f"MatMulV3 preflight rejected {workload_id} rank={rank}"
                    ) from exception
                profiled = candidate_profile(
                    candidate, measured, rank,
                    candidate.get("source", "searched"), "searched", knowledge,
                )
                append_row(args.custom_output, PROFILE_COLUMNS, profiled)
                append_samples(
                    args.custom_samples_output, samples, rank, "searched"
                )
                candidate_ms = as_float(profiled, "median_ms")
                is_new_best = candidate_ms < best_ms
                if is_new_best:
                    best_ms = candidate_ms
                    best_rank = rank
                speedup, delta_pct, noise_pct, status = comparison_status(
                    official_baseline, profiled
                )
                if is_new_best:
                    best_status = status
                if show_progress or is_new_best:
                    marker = "best" if is_new_best else "measured"
                    print(
                        f"candidate_done [{candidate_index}/{len(supported_candidates)}] "
                        f"{workload_id} rank={rank} {schedule_text(candidate, knowledge)} "
                        f"ms={compact(candidate_ms)} std={compact(as_float(profiled, 'stddev_ms'))} "
                        f"speedup={compact(speedup)} delta={compact(delta_pct)}% "
                        f"noise={compact(noise_pct)}% status={status} mark={marker}",
                        flush=True,
                    )
            print(
                f"WORKLOAD_RESULT {workload_id} best_rank={best_rank or 'none'} "
                f"best_ms={compact(best_ms)} "
                f"official_ms={compact(as_float(official_baseline, 'median_ms'))} "
                f"speedup={compact(as_float(official_baseline, 'median_ms') / best_ms if best_ms > 0 else float('nan'))} "
                f"status={best_status or 'no_searched_candidate'}",
                flush=True,
            )

        print(
            f"official_tiling_profile completed "
            f"baselines={len(workloads) - unsupported} "
            f"searched={candidate_index} unsupported={unsupported}",
            flush=True,
        )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ProfileError, OSError, ValueError, KeyError, json.JSONDecodeError) as exception:
        print(f"fatal: {exception}", flush=True)
        raise SystemExit(1)

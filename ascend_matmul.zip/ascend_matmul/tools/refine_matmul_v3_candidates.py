#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import struct
import warnings
from dataclasses import dataclass
from pathlib import Path


warnings.filterwarnings("ignore", category=Warning, module="requests")


KNOWLEDGE_FIELDS = (
    "usedCoreNum", "singleCoreM", "singleCoreN", "singleCoreK",
    "baseM", "baseN", "baseK", "depthA1", "depthB1", "stepM",
    "stepN", "iterateOrder", "stepKa", "stepKb", "dbL0A", "dbL0B",
    "dbL0C", "l2MTileCnt", "l2NTileCnt", "l2MTileBlock",
    "l2NTileBlock", "l2IterateOrder", "tilingEnable",
)

BANK_COLUMNS = {
    "tilingEnable": "bank_tiling_enable",
    "l2MTileCnt": "bank_l2_m_tile_count",
    "l2NTileCnt": "bank_l2_n_tile_count",
    "l2MTileBlock": "bank_l2_m_tile_block",
    "l2NTileBlock": "bank_l2_n_tile_block",
    "l2IterateOrder": "bank_l2_iterate_order",
}

EXTRA_COLUMNS = [
    *BANK_COLUMNS.values(),
    "search_template", "search_guidance", "search_model_score",
    "search_model_cycles", "search_model_raw_ratio_vs_bank_seed",
    "search_model_ratio_vs_bank_seed", "search_model_calibration",
    "search_model_confidence", "search_model_breakdown",
    "search_hbm_bytes", "search_l2_bytes", "search_seed_key",
    "callback_tiling_sha256", "callback_tiling_bytes",
    "callback_tiling_key", "callback_block_dim", "callback_workspace_bytes",
    "callback_l2_cache_flag", "callback_base_an", "callback_base_ad",
    "callback_base_bn", "callback_base_bd",
    "callback_derived_diff_vs_default",
    "callback_derived_diff_vs_bank_seed",
    "search_history_match",
]

DTYPE_NAME = {
    "fp16": "float16",
    "bf16": "bfloat16",
    "fp32": "float32",
}

INPUT_BYTES = {"fp16": 2, "bf16": 2, "fp32": 4}
OUTPUT_BYTES = {"fp16": 2, "bf16": 2, "fp32": 4}

# MatmulV3TilingData is TCubeTiling (50 words), L2CacheTilePara (5),
# seven run-info words, l2CacheFlag, then the ND->NZ vector tiling. These
# offsets are part of the public MatMulV3 tiling-data definition. Keep unknown
# trailing words in the hash even when a CANN release extends the structure.
DERIVED_WORDS = {
    62: "l2CacheFlag",
    63: "baseAN",
    64: "baseAD",
    65: "baseBN",
    66: "baseBD",
}


class SearchError(RuntimeError):
    pass


@dataclass(frozen=True)
class Workload:
    workload_id: str
    m: int
    n: int
    k: int
    dtype: str
    trans_a: bool
    trans_b: bool
    max_cores: int


@dataclass(frozen=True)
class Hardware:
    aic_cores: int
    l0a_bytes: int
    l0b_bytes: int
    l0c_bytes: int
    l1_bytes: int
    l2_bytes: int
    l2_bytes_per_cycle_per_core: float
    hbm_bytes_per_cycle_per_core: float


@dataclass(frozen=True)
class CallbackTiling:
    key: int
    block_dim: int
    workspaces: tuple[int, ...]
    blob: bytes
    sha256: str
    words: tuple[int, ...]
    cube: tuple[int, ...]
    l2: tuple[int, ...]
    knowledge: dict[str, int]
    derived: dict[str, int]


@dataclass
class Seed:
    default: CallbackTiling
    bank: CallbackTiling

    @property
    def key(self) -> int:
        return self.default.key

    @property
    def block_dim(self) -> int:
        return self.default.block_dim

    @property
    def workspace(self) -> int:
        return sum(self.default.workspaces)

    @property
    def knowledge(self) -> dict[str, int]:
        return self.default.knowledge


@dataclass(frozen=True)
class ModelEstimate:
    cycles: float
    hbm_bytes: float
    l2_bytes: float
    cube_cycles: float
    mte2_cycles: float
    mte1_cycles: float
    fixpipe_cycles: float
    nd2nz_cycles: float
    issue_cycles: float
    balance: float
    confidence: str

    def breakdown(self) -> str:
        values = {
            "cube": self.cube_cycles,
            "mte2": self.mte2_cycles,
            "mte1": self.mte1_cycles,
            "fixpipe": self.fixpipe_cycles,
            "nd2nz": self.nd2nz_cycles,
            "issue": self.issue_cycles,
            "balance": self.balance,
        }
        return json.dumps(values, separators=(",", ":"), sort_keys=True)


@dataclass
class State:
    row: dict[str, str]
    knowledge: dict[str, int]
    model_score: float
    normalized_score: float
    hbm_bytes: float
    l2_bytes: float
    template: str
    guidance: str = "analytical_beam"
    callback: CallbackTiling | None = None
    estimate: ModelEstimate | None = None


def truthy(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def ceil_div(value: int, divisor: int) -> int:
    return (value + divisor - 1) // divisor


def align_up(value: int, alignment: int) -> int:
    return ceil_div(value, alignment) * alignment


def cube_k0(dtype: str) -> int:
    return 8 if dtype == "fp32" else 16


def base_k_alignment(workload: Workload) -> int:
    # TCubeTiling permits FP32 K0 alignment only for ND x transposed-ND.
    # All other layouts use 16-element baseK alignment.
    if workload.dtype == "fp32" and not workload.trans_a and workload.trans_b:
        return 8
    return 16


def callback_derived_diff(
    left: CallbackTiling,
    right: CallbackTiling,
) -> str:
    names: list[str] = []
    for index, name in DERIVED_WORDS.items():
        if index >= len(left.words) or index >= len(right.words):
            continue
        if left.words[index] != right.words[index]:
            names.append(
                f"{name}:{left.words[index]}->{right.words[index]}"
            )
    if len(left.words) != len(right.words):
        names.append(f"word_count:{len(left.words)}->{len(right.words)}")
    return "|".join(names)


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        rows = list(reader)
        fields = list(reader.fieldnames or [])
    if not fields:
        raise SearchError(f"{path}: missing CSV header")
    return fields, rows


def load_workloads(path: Path) -> list[Workload]:
    _, rows = read_csv(path)
    workloads: list[Workload] = []
    for row in rows:
        dtype = row["dtype"].lower()
        workloads.append(
            Workload(
                workload_id=row.get("workload_id") or row["id"],
                m=int(row["m"]),
                n=int(row["n"]),
                k=int(row["k"]),
                dtype=dtype,
                trans_a=truthy(row.get("trans_a")),
                trans_b=truthy(row.get("trans_b")),
                max_cores=int(row.get("max_cores") or 24),
            )
        )
    return workloads


def decode_tiling_enable(tiling_key: int) -> int:
    # EncodeTilingKey places MIX, SPLIT, FIX and FULL in the four low
    # decimal digits for MatMulV3. tilingEnable uses split + 10*full +
    # 1000*fix, matching MatmulV3BaseTiling::CheckAoeTilingEnable.
    split_mode = (tiling_key // 10) % 10
    fix_mode = (tiling_key // 100) % 10
    full_load = (tiling_key // 1000) % 10
    return split_mode + 10 * full_load + 1000 * fix_mode


def split_mode(knowledge: dict[str, int]) -> int:
    return knowledge["tilingEnable"] % 10


def full_load_mode(knowledge: dict[str, int]) -> int:
    return (knowledge["tilingEnable"] // 10) % 10


def template_name(knowledge: dict[str, int]) -> str:
    split = split_mode(knowledge)
    full = full_load_mode(knowledge)
    if split == 3:
        return "DETERMINISTIC_SPLIT_K"
    if split == 2:
        return "SINGLE_CORE_SPLIT_K"
    if split == 5:
        return "SINGLE_CORE_NKM_SPLIT_K"
    if split == 6:
        return "SINGLE_CORE_SPLIT_K_GM_TO_L1"
    if split == 4:
        return "MULTI_CORE_SPLIT_K"
    if full == 1:
        return "AL1_FULL_LOAD"
    if full == 2:
        return "BL1_FULL_LOAD"
    return "BASE"


def tensor_desc(name: str, shape: list[int], dtype: str) -> dict:
    return {
        "name": name,
        "shape": shape,
        "ori_shape": shape,
        "format": "ND",
        "ori_format": "ND",
        "dtype": DTYPE_NAME[dtype],
    }


def callback_knowledge(
    result: dict,
    cube: tuple[int, ...],
    l2: tuple[int, ...],
) -> dict[str, int]:
    return {
        "usedCoreNum": cube[0],
        "singleCoreM": cube[5],
        "singleCoreN": cube[6],
        "singleCoreK": cube[7],
        "baseM": cube[8],
        "baseN": cube[9],
        "baseK": cube[10],
        "depthA1": cube[11],
        "depthB1": cube[12],
        "stepM": cube[13],
        "stepN": cube[14],
        "iterateOrder": cube[17],
        "stepKa": cube[26],
        "stepKb": cube[27],
        "dbL0A": cube[30],
        "dbL0B": cube[31],
        "dbL0C": cube[32],
        "l2MTileCnt": l2[0],
        "l2NTileCnt": l2[1],
        "l2MTileBlock": l2[2],
        "l2NTileBlock": l2[3],
        "l2IterateOrder": l2[4],
        "tilingEnable": decode_tiling_enable(int(result["tiling_key"])),
    }


def parse_callback_result(result: dict) -> CallbackTiling:
    blob = bytes(result["tiling_data"])
    if len(blob) < 220 or len(blob) % 4:
        raise SearchError(
            f"unexpected MatMulV3 tiling_data size={len(blob)}"
        )
    cube = struct.unpack_from("<50i", blob, 0)
    l2 = struct.unpack_from("<5I", blob, 200)
    words = struct.unpack(f"<{len(blob) // 4}I", blob)
    derived = {
        name: int(words[index])
        for index, name in DERIVED_WORDS.items()
        if index < len(words)
    }
    workspaces = tuple(int(value) for value in (result.get("workspaces") or [0]))
    return CallbackTiling(
        key=int(result["tiling_key"]),
        block_dim=int(result["block_dim"]),
        workspaces=workspaces,
        blob=blob,
        sha256=hashlib.sha256(blob).hexdigest(),
        words=tuple(int(value) for value in words),
        cube=tuple(int(value) for value in cube),
        l2=tuple(int(value) for value in l2),
        knowledge=callback_knowledge(result, cube, l2),
        derived=derived,
    )


def invoke_official_callback(
    workload: Workload,
    injected: dict[str, int] | None = None,
) -> CallbackTiling:
    from tbe.common.utils import op_tiling

    shape_a = [workload.k, workload.m] if workload.trans_a else [workload.m, workload.k]
    shape_b = [workload.n, workload.k] if workload.trans_b else [workload.k, workload.n]
    attrs = [
        {"name": "transpose_x1", "dtype": "bool", "value": workload.trans_a},
        {"name": "transpose_x2", "dtype": "bool", "value": workload.trans_b},
        {"name": "offset_x", "dtype": "int", "value": 0},
        {"name": "enable_hf32", "dtype": "bool", "value": False},
    ]
    op_tiling._RT_BANK_CACHE = injected or {}
    result = op_tiling.do_op_tiling(
        "MatMulV3",
        {},
        [
            tensor_desc("x1", shape_a, workload.dtype),
            tensor_desc("x2", shape_b, workload.dtype),
            None,
            None,
        ],
        [tensor_desc("y", [workload.m, workload.n], workload.dtype)],
        attrs=attrs,
    )
    return parse_callback_result(result)


def parse_seed(workload: Workload) -> Seed:
    default = invoke_official_callback(workload)
    bank = invoke_official_callback(workload, default.knowledge)
    return Seed(default=default, bank=bank)


def raw_knowledge(row: dict[str, str]) -> dict[str, int]:
    execution_mode = row.get("execution_mode", "")
    tiling_enable = 4 if execution_mode == "direct_atomic_split_k_fp32_nt" else 0
    return {
        "usedCoreNum": int(row["used_core_num"]),
        "singleCoreM": int(row["single_core_m"]),
        "singleCoreN": int(row["single_core_n"]),
        "singleCoreK": int(row["single_core_k"]),
        "baseM": int(row["base_m"]),
        "baseN": int(row["base_n"]),
        "baseK": int(row["base_k"]),
        "depthA1": int(row["depth_a1"]),
        "depthB1": int(row["depth_b1"]),
        "stepM": int(row["step_m"]),
        "stepN": int(row["step_n"]),
        "iterateOrder": int(row["iterate_order"]),
        "stepKa": int(row["step_ka"]),
        "stepKb": int(row["step_kb"]),
        "dbL0A": int(row["db_l0a"]),
        "dbL0B": int(row["db_l0b"]),
        "dbL0C": int(row["db_l0c"]),
        "l2MTileCnt": 1,
        "l2NTileCnt": 1,
        "l2MTileBlock": 1,
        "l2NTileBlock": 1,
        "l2IterateOrder": 0,
        "tilingEnable": tiling_enable,
    }


def hard_legal(
    workload: Workload,
    knowledge: dict[str, int],
    hardware: Hardware,
) -> bool:
    required_positive = (
        "usedCoreNum", "singleCoreM", "singleCoreN", "singleCoreK",
        "baseM", "baseN", "baseK", "depthA1", "depthB1", "stepM",
        "stepN", "stepKa", "stepKb", "dbL0A", "dbL0B", "dbL0C",
        "l2MTileCnt", "l2NTileCnt", "l2MTileBlock", "l2NTileBlock",
    )
    if any(knowledge[name] <= 0 for name in required_positive):
        return False
    if knowledge["usedCoreNum"] > min(workload.max_cores, hardware.aic_cores):
        return False
    if knowledge["iterateOrder"] not in (0, 1) or knowledge["l2IterateOrder"] not in (0, 1):
        return False
    if any(knowledge[name] not in (1, 2) for name in ("dbL0A", "dbL0B", "dbL0C")):
        return False

    k0 = base_k_alignment(workload)
    if (
        knowledge["baseM"] % 16
        or knowledge["baseN"] % 16
        or knowledge["baseK"] % k0
    ):
        return False

    in_bytes = INPUT_BYTES[workload.dtype]
    l0a = knowledge["baseM"] * knowledge["baseK"] * in_bytes * knowledge["dbL0A"]
    l0b = knowledge["baseN"] * knowledge["baseK"] * in_bytes * knowledge["dbL0B"]
    l0c = knowledge["baseM"] * knowledge["baseN"] * 4 * knowledge["dbL0C"]
    if (
        l0a > hardware.l0a_bytes
        or l0b > hardware.l0b_bytes
        or l0c > hardware.l0c_bytes
    ):
        return False

    one_a = knowledge["stepM"] * knowledge["stepKa"]
    one_b = knowledge["stepN"] * knowledge["stepKb"]
    if knowledge["depthA1"] % one_a or knowledge["depthB1"] % one_b:
        return False
    if knowledge["depthA1"] // one_a not in (1, 2):
        return False
    if knowledge["depthB1"] // one_b not in (1, 2):
        return False
    a1 = (
        knowledge["baseM"] * knowledge["baseK"]
        * knowledge["depthA1"] * in_bytes
    )
    b1 = (
        knowledge["baseN"] * knowledge["baseK"]
        * knowledge["depthB1"] * in_bytes
    )
    if a1 + b1 > hardware.l1_bytes:
        return False

    if (
        knowledge["stepKa"] % knowledge["stepKb"]
        and knowledge["stepKb"] % knowledge["stepKa"]
    ):
        return False
    if (
        ceil_div(workload.k, knowledge["baseK"]) > knowledge["stepKa"]
        and split_mode(knowledge) == 0
        and knowledge["stepM"] != 1
    ):
        return False
    if (
        ceil_div(workload.k, knowledge["baseK"]) > knowledge["stepKb"]
        and split_mode(knowledge) == 0
        and knowledge["stepN"] != 1
    ):
        return False

    if split_mode(knowledge) == 0 and full_load_mode(knowledge) == 0:
        if (
            knowledge["singleCoreM"] != knowledge["baseM"]
            or knowledge["singleCoreN"] != knowledge["baseN"]
            or knowledge["singleCoreK"] < workload.k
        ):
            return False
    elif split_mode(knowledge) == 3:
        expected_base_k = 256 // in_bytes
        if (
            knowledge["baseM"], knowledge["baseN"], knowledge["baseK"]
        ) != (128, 128, expected_base_k):
            return False
        mk33 = (
            knowledge["stepM"], knowledge["stepN"],
            knowledge["stepKa"], knowledge["stepKb"],
            knowledge["depthA1"], knowledge["depthB1"],
            knowledge["singleCoreM"],
        ) == (3, 1, 3, 3, 9, 6, 384)
        nk33 = (
            knowledge["stepM"], knowledge["stepN"],
            knowledge["stepKa"], knowledge["stepKb"],
            knowledge["depthA1"], knowledge["depthB1"],
            knowledge["singleCoreN"],
        ) == (1, 3, 3, 3, 6, 9, 384)
        k_chunks = ceil_div(workload.k, knowledge["singleCoreK"])
        if (
            not (mk33 or nk33)
            or knowledge["singleCoreK"] != 3 * knowledge["baseK"]
            or k_chunks < 2
            or knowledge["usedCoreNum"] > k_chunks
        ):
            return False
    elif split_mode(knowledge) == 4:
        if (
            workload.dtype != "fp32"
            or workload.trans_a
            or not workload.trans_b
        ):
            return False
        m_chunks = ceil_div(workload.m, knowledge["singleCoreM"])
        n_chunks = ceil_div(workload.n, knowledge["singleCoreN"])
        k_chunks = ceil_div(workload.k, knowledge["singleCoreK"])
        if (
            k_chunks < 2
            or m_chunks * n_chunks * k_chunks
            != knowledge["usedCoreNum"]
        ):
            return False
    else:
        return False

    m_blocks = ceil_div(workload.m, knowledge["singleCoreM"])
    n_blocks = ceil_div(workload.n, knowledge["singleCoreN"])
    if knowledge["l2MTileCnt"] != ceil_div(m_blocks, knowledge["l2MTileBlock"]):
        return False
    if knowledge["l2NTileCnt"] != ceil_div(n_blocks, knowledge["l2NTileBlock"]):
        return False
    return True


def axis_values(total: int, target: int) -> list[int]:
    values = {
        1,
        total,
        max(1, min(total, target)),
        max(1, min(total, target - 1)),
        max(1, min(total, target + 1)),
        max(1, min(total, ceil_div(target, 2))),
        max(1, min(total, target * 2)),
    }
    return sorted(values)


def l2_schedules(
    workload: Workload,
    knowledge: dict[str, int],
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    m_total = ceil_div(workload.m, knowledge["singleCoreM"])
    n_total = ceil_div(workload.n, knowledge["singleCoreN"])
    seed_k = seed.knowledge
    target_m_elements = seed_k["singleCoreM"] * seed_k["l2MTileBlock"]
    target_n_elements = seed_k["singleCoreN"] * seed_k["l2NTileBlock"]
    target_m = ceil_div(target_m_elements, knowledge["singleCoreM"])
    target_n = ceil_div(target_n_elements, knowledge["singleCoreN"])

    schedules: list[tuple[float, dict[str, int]]] = []
    for m_block in axis_values(m_total, target_m):
        for n_block in axis_values(n_total, target_n):
            for order in (seed_k["l2IterateOrder"], 1 - seed_k["l2IterateOrder"]):
                candidate = dict(knowledge)
                candidate["l2MTileBlock"] = m_block
                candidate["l2NTileBlock"] = n_block
                candidate["l2MTileCnt"] = ceil_div(m_total, m_block)
                candidate["l2NTileCnt"] = ceil_div(n_total, n_block)
                candidate["l2IterateOrder"] = order

                m_extent = min(workload.m, m_block * knowledge["singleCoreM"])
                n_extent = min(workload.n, n_block * knowledge["singleCoreN"])
                in_bytes = INPUT_BYTES[workload.dtype]
                out_bytes = OUTPUT_BYTES[workload.dtype]
                working_set = (
                    m_extent * workload.k * in_bytes
                    + workload.k * n_extent * in_bytes
                    + m_extent * n_extent * out_bytes
                )
                # MatMulV3 scales its empirically safe 100 MiB working-set
                # threshold linearly from the 192 MiB Ascend910B L2.
                l2_working_set_limit = (
                    hardware.l2_bytes
                    / float(192 * 1024 * 1024)
                    * 100 * 1024 * 1024
                )
                capacity_overflow = max(
                    0.0, working_set / max(1.0, l2_working_set_limit) - 1.0
                )
                m_tail = m_total - (candidate["l2MTileCnt"] - 1) * m_block
                n_tail = n_total - (candidate["l2NTileCnt"] - 1) * n_block
                # Match MatmulV3BaseTiling::InitL2SplitParams: the outer
                # axis permits five-way conflict on a 20-AIC product; the
                # unfavorable inner layout permits four-way conflict.
                if knowledge["baseN"] >= knowledge["baseM"]:
                    m_conflict = 4 if workload.trans_a else 5
                    n_conflict = 5
                else:
                    m_conflict = 5
                    n_conflict = 4 if not workload.trans_b else 5
                tail_penalty = 0.0
                if (
                    m_total > m_block
                    and m_tail * m_conflict < hardware.aic_cores
                ):
                    tail_penalty += (
                        hardware.aic_cores - m_tail * m_conflict
                    ) / hardware.aic_cores
                if (
                    n_total > n_block
                    and n_tail * n_conflict < hardware.aic_cores
                ):
                    tail_penalty += (
                        hardware.aic_cores - n_tail * n_conflict
                    ) / hardware.aic_cores
                distance = (
                    abs(m_block - target_m) / max(1, target_m)
                    + abs(n_block - target_n) / max(1, target_n)
                )
                schedules.append(
                    (5.0 * capacity_overflow + 2.0 * tail_penalty + 0.01 * distance, candidate)
                )
    schedules.sort(key=lambda item: item[0])
    unique: list[dict[str, int]] = []
    seen: set[tuple[int, ...]] = set()
    for _, candidate in schedules:
        signature = tuple(candidate[field] for field in KNOWLEDGE_FIELDS)
        if signature in seen:
            continue
        seen.add(signature)
        unique.append(candidate)
        if len(unique) == 3:
            break
    return unique


def chunk_ceil_sum(total: int, chunk: int, unit: int) -> int:
    count = ceil_div(total, chunk)
    tail = total - (count - 1) * chunk
    return (count - 1) * ceil_div(chunk, unit) + ceil_div(tail, unit)


def chunk_aligned_sum(total: int, chunk: int, alignment: int) -> int:
    return chunk_ceil_sum(total, chunk, alignment) * alignment


def fixpipe_row_sum(
    total: int,
    single: int,
    base: int,
    out_bytes: int,
) -> int:
    def extent_bytes(extent: int) -> int:
        subtiles = ceil_div(extent, base)
        tail = extent - (subtiles - 1) * base
        return (
            (subtiles - 1) * align_up(base * out_bytes, 512)
            + align_up(tail * out_bytes, 512)
        )

    count = ceil_div(total, single)
    tail = total - (count - 1) * single
    return (count - 1) * extent_bytes(single) + extent_bytes(tail)


def analytical_score(
    workload: Workload,
    knowledge: dict[str, int],
    hardware: Hardware,
    callback: CallbackTiling | None = None,
) -> ModelEstimate:
    """Estimate the critical-core MatMulV3 pipeline, not wall-clock time.

    The objective follows the structure used by NPUMeter: model the execution
    sequence of every logical tile, overlap MTE2/MTE1/Cube/FixPipe according to
    buffer depth, and take the slowest core. L2/HBM traffic and ND->NZ vector
    conversion are then added at their shared-resource rates. Absolute cycles
    are intentionally not converted to milliseconds; only ratios between
    candidates of the same workload are used for search.
    """
    in_bytes = INPUT_BYTES[workload.dtype]
    out_bytes = OUTPUT_BYTES[workload.dtype]
    cores = max(1, knowledge["usedCoreNum"])
    base_m = knowledge["baseM"]
    base_n = knowledge["baseN"]
    base_k = knowledge["baseK"]
    single_m = knowledge["singleCoreM"]
    single_n = knowledge["singleCoreN"]
    single_k = knowledge["singleCoreK"]
    native_k = cube_k0(workload.dtype)

    m_output = ceil_div(workload.m, single_m)
    n_output = ceil_div(workload.n, single_n)
    k_output = (
        ceil_div(workload.k, single_k)
        if split_mode(knowledge) in (3, 4)
        else 1
    )
    logical_tiles = m_output * n_output * k_output

    # Closed-form axis sums avoid materializing millions of tile coordinates
    # for large shapes. They retain full/tail padding, transaction counts and
    # the number of whole AIC scheduling rounds.
    m_align_sum = chunk_aligned_sum(workload.m, single_m, 16)
    n_align_sum = chunk_aligned_sum(workload.n, single_n, 16)
    k_align_sum = chunk_aligned_sum(workload.k, single_k, native_k)
    m_cube_units = chunk_ceil_sum(workload.m, single_m, 16)
    n_cube_units = chunk_ceil_sum(workload.n, single_n, 16)
    k_cube_units = chunk_ceil_sum(workload.k, single_k, native_k)
    m_subtiles = chunk_ceil_sum(workload.m, single_m, base_m)
    n_subtiles = chunk_ceil_sum(workload.n, single_n, base_n)
    k_subtiles = chunk_ceil_sum(workload.k, single_k, base_k)

    total_cube = float(
        m_cube_units * n_cube_units * k_cube_units
        + 12 * m_subtiles * n_subtiles * k_output
    )
    l2_a_bytes = float(
        m_align_sum * k_align_sum * n_output * in_bytes
    )
    l2_b_bytes = float(
        n_align_sum * k_align_sum * m_output * in_bytes
    )
    l2_c_bytes = float(workload.m * workload.n * out_bytes * k_output)

    a_k_packets = chunk_ceil_sum(
        workload.k,
        single_k,
        base_k * knowledge["stepKa"],
    )
    b_k_packets = chunk_ceil_sum(
        workload.k,
        single_k,
        base_k * knowledge["stepKb"],
    )
    total_a_packets = m_subtiles * n_output * a_k_packets
    total_b_packets = n_subtiles * m_output * b_k_packets
    total_mte2 = (
        (l2_a_bytes + l2_b_bytes)
        / max(1.0, hardware.l2_bytes_per_cycle_per_core)
        + 12.0 * (total_a_packets + total_b_packets)
    )

    mte1_tiles = m_subtiles * n_subtiles * k_subtiles
    total_mte1 = (
        mte1_tiles
        * (base_m * base_k + base_n * base_k)
        * in_bytes
        / 128.0
        + 4.0 * mte1_tiles
    )
    total_fixpipe = (
        m_align_sum
        * fixpipe_row_sum(
            workload.n, single_n, base_n, out_bytes
        )
        * k_output
        / 64.0
        + 4.0 * m_subtiles * n_subtiles * k_output
    )
    total_issue = float(
        2 * mte1_tiles + total_a_packets + total_b_packets
    )

    active_cores = max(1, min(cores, logical_tiles))
    round_balance = (
        ceil_div(logical_tiles, active_cores)
        / max(1.0, logical_tiles / active_cores)
    )

    def critical(total: float) -> float:
        return total / active_cores * round_balance

    critical_cube = critical(total_cube)
    critical_mte2 = critical(total_mte2)
    critical_mte1 = critical(total_mte1)
    critical_fixpipe = critical(total_fixpipe)
    issue_cycles = critical(total_issue)
    input_stage = max(critical_mte2, critical_mte1)
    if knowledge["dbL0A"] == 2 and knowledge["dbL0B"] == 2:
        critical_pipeline = max(critical_cube, input_stage)
        critical_pipeline += 0.08 * min(critical_cube, input_stage)
    else:
        critical_pipeline = critical_cube + input_stage
    if knowledge["dbL0C"] == 2:
        critical_pipeline = max(critical_pipeline, critical_fixpipe)
    else:
        critical_pipeline += critical_fixpipe

    hbm_a = (
        workload.m * workload.k * in_bytes
        * knowledge["l2NTileCnt"]
    )
    hbm_b = (
        workload.k * workload.n * in_bytes
        * knowledge["l2MTileCnt"]
    )
    hbm_c = workload.m * workload.n * out_bytes
    hbm_bytes = float(hbm_a + hbm_b + hbm_c)

    l2_bytes = float(l2_a_bytes + l2_b_bytes + l2_c_bytes)
    hbm_cycles = hbm_bytes / max(
        1.0, hardware.hbm_bytes_per_cycle_per_core * cores
    )
    l2_cycles = l2_bytes / max(
        1.0, hardware.l2_bytes_per_cycle_per_core * cores
    )

    if split_mode(knowledge) == 3:
        workspace_bytes = (
            align_up(workload.m, 16) * align_up(workload.n, 16)
            * 4 * cores
        )
        reduction_bytes = workspace_bytes + workload.m * workload.n * out_bytes
        hbm_bytes += workspace_bytes
        l2_bytes += reduction_bytes
        hbm_cycles = hbm_bytes / max(
            1.0, hardware.hbm_bytes_per_cycle_per_core * cores
        )
        l2_cycles = l2_bytes / max(
            1.0, hardware.l2_bytes_per_cycle_per_core * cores
        )
        issue_cycles += k_output * m_output * n_output * 32.0 / cores
    elif split_mode(knowledge) == 4:
        # The direct atomic template accumulates every K slice into C. Include
        # the clear plus read/modify/write traffic instead of treating it like
        # a BASE output written once.
        atomic_c_bytes = workload.m * workload.n * out_bytes * (2 * k_output + 1)
        hbm_bytes += max(0.0, atomic_c_bytes - hbm_c)
        l2_bytes += max(0.0, atomic_c_bytes - l2_c_bytes)
        hbm_cycles = hbm_bytes / max(
            1.0, hardware.hbm_bytes_per_cycle_per_core * cores
        )
        l2_cycles = l2_bytes / max(
            1.0, hardware.l2_bytes_per_cycle_per_core * cores
        )
        issue_cycles += k_output * m_output * n_output * 8.0 / cores

    m_extent = min(
        workload.m,
        knowledge["l2MTileBlock"] * single_m,
    )
    n_extent = min(
        workload.n,
        knowledge["l2NTileBlock"] * single_n,
    )
    working_set = (
        m_extent * workload.k * in_bytes
        + workload.k * n_extent * in_bytes
        + m_extent * n_extent * out_bytes
    )
    safe_l2 = hardware.l2_bytes * (100.0 / 192.0)
    capacity_penalty = max(0.0, working_set / max(1.0, safe_l2) - 1.0)
    m_tail = (
        m_output
        - (knowledge["l2MTileCnt"] - 1) * knowledge["l2MTileBlock"]
    )
    n_tail = (
        n_output
        - (knowledge["l2NTileCnt"] - 1) * knowledge["l2NTileBlock"]
    )
    tail_parallelism = max(
        1,
        min(cores, max(1, m_tail) * max(1, n_tail)),
    )
    tail_smear = 1.0 + 0.20 * (1.0 - tail_parallelism / cores)
    l2_shared_cycles = (hbm_cycles + l2_cycles) * tail_smear
    l2_shared_cycles *= 1.0 + 2.0 * capacity_penalty

    nd2nz_cycles = 0.0
    confidence = "medium"
    if callback is not None and all(
        name in callback.derived
        for name in ("baseAN", "baseAD", "baseBN", "baseBD")
    ):
        # Zero means that the corresponding ND->NZ conversion side/axis does
        # not require an explicit split. The field names use logical MatMul
        # axes (A: M,K and B: N,K), independent of physical transpose.
        base_an = callback.derived["baseAN"] or workload.m
        base_ad = callback.derived["baseAD"] or workload.k
        base_bn = callback.derived["baseBN"] or workload.n
        base_bd = callback.derived["baseBD"] or workload.k
        convert_a = bool(
            callback.derived["baseAN"] or callback.derived["baseAD"]
        )
        convert_b = bool(
            callback.derived["baseBN"] or callback.derived["baseBD"]
        )
        a_vector_tiles = (
            ceil_div(workload.m, base_an)
            * ceil_div(workload.k, base_ad)
            if convert_a
            else 0
        )
        b_vector_tiles = (
            ceil_div(workload.n, base_bn)
            * ceil_div(workload.k, base_bd)
            if convert_b
            else 0
        )
        vector_cores = max(1, 2 * cores)
        nd2nz_bytes = (
            (workload.m * workload.k if convert_a else 0)
            + (workload.k * workload.n if convert_b else 0)
        ) * in_bytes
        nd2nz_cycles = (
            nd2nz_bytes / (128.0 * vector_cores)
            + 6.0 * (a_vector_tiles + b_vector_tiles) / vector_cores
        )
        confidence = "high" if split_mode(knowledge) == 0 else "medium"

    balance = round_balance * cores / active_cores
    score = (
        max(critical_pipeline, l2_shared_cycles)
        + nd2nz_cycles
        + issue_cycles
    )
    return ModelEstimate(
        cycles=score,
        hbm_bytes=hbm_bytes,
        l2_bytes=l2_bytes,
        cube_cycles=critical_cube,
        mte2_cycles=max(critical_mte2, l2_shared_cycles),
        mte1_cycles=critical_mte1,
        fixpipe_cycles=critical_fixpipe,
        nd2nz_cycles=nd2nz_cycles,
        issue_cycles=issue_cycles,
        balance=balance,
        confidence=confidence,
    )


def knowledge_signature(knowledge: dict[str, int]) -> tuple[int, ...]:
    return tuple(knowledge[field] for field in KNOWLEDGE_FIELDS)


def dominated_by_bank_seed(
    knowledge: dict[str, int],
    seed: Seed,
) -> bool:
    if knowledge["usedCoreNum"] >= seed.bank.knowledge["usedCoreNum"]:
        return False
    return all(
        knowledge[field] == seed.bank.knowledge[field]
        for field in KNOWLEDGE_FIELDS
        if field != "usedCoreNum"
    )


def row_from_state(
    fields: list[str],
    prototype: dict[str, str] | None,
    workload: Workload,
    knowledge: dict[str, int],
    source: str,
    template: str,
    score: float,
    hbm_bytes: float,
    l2_bytes: float,
    seed_key: int,
    guidance: str = "analytical_beam",
    candidate_role: str = "searched",
    estimate: ModelEstimate | None = None,
) -> dict[str, str]:
    row = {field: "" for field in fields}
    if prototype:
        row.update(prototype)
    row.update(
        {
            "workload_id": workload.workload_id,
            "m": str(workload.m),
            "n": str(workload.n),
            "k": str(workload.k),
            "dtype": workload.dtype,
            "trans_a": str(int(workload.trans_a)),
            "trans_b": str(int(workload.trans_b)),
            "max_cores": str(workload.max_cores),
            "source": source,
            "candidate_role": candidate_role,
            "source_iteration": "0",
            "valid": "1",
            "error": "",
            "execution_mode": (
                "deterministic_split_k"
                if split_mode(knowledge) == 3
                else "direct_atomic_split_k_fp32_nt"
                if split_mode(knowledge) == 4
                else "al1_full_load"
                if full_load_mode(knowledge) == 1
                else "bl1_full_load"
                if full_load_mode(knowledge) == 2
                else "base_iterate_all"
            ),
            "candidate_single_core_m": str(knowledge["singleCoreM"]),
            "candidate_single_core_n": str(knowledge["singleCoreN"]),
            "candidate_single_core_k": str(knowledge["singleCoreK"]),
            "candidate_base_m": str(knowledge["baseM"]),
            "candidate_base_n": str(knowledge["baseN"]),
            "candidate_base_k": str(knowledge["baseK"]),
            "candidate_traverse": str(knowledge["iterateOrder"]),
            "candidate_db_a": str(int(knowledge["dbL0A"] == 2)),
            "candidate_db_b": str(int(knowledge["dbL0B"] == 2)),
            "candidate_split_k": str(int(split_mode(knowledge) != 0)),
            "used_core_num": str(knowledge["usedCoreNum"]),
            "official_core_num": str(knowledge["usedCoreNum"]),
            "official_m_dim": str(ceil_div(workload.m, knowledge["singleCoreM"])),
            "official_n_dim": str(ceil_div(workload.n, knowledge["singleCoreN"])),
            "m_core_parts": str(ceil_div(workload.m, knowledge["singleCoreM"])),
            "n_core_parts": str(ceil_div(workload.n, knowledge["singleCoreN"])),
            "k_core_parts": str(ceil_div(workload.k, knowledge["singleCoreK"])),
            "single_core_m": str(knowledge["singleCoreM"]),
            "single_core_n": str(knowledge["singleCoreN"]),
            "single_core_k": str(knowledge["singleCoreK"]),
            "base_m": str(knowledge["baseM"]),
            "base_n": str(knowledge["baseN"]),
            "base_k": str(knowledge["baseK"]),
            "depth_a1": str(knowledge["depthA1"]),
            "depth_b1": str(knowledge["depthB1"]),
            "step_m": str(knowledge["stepM"]),
            "step_n": str(knowledge["stepN"]),
            "step_ka": str(knowledge["stepKa"]),
            "step_kb": str(knowledge["stepKb"]),
            "iterate_order": str(knowledge["iterateOrder"]),
            "db_l0a": str(knowledge["dbL0A"]),
            "db_l0b": str(knowledge["dbL0B"]),
            "db_l0c": str(knowledge["dbL0C"]),
            "official_return": "0",
            "tiling_signature": ":".join(map(str, knowledge_signature(knowledge))),
            "tiling_bin": "",
            "search_template": template,
            "search_guidance": guidance,
            "search_model_score": f"{score:.12g}",
            "search_model_cycles": (
                f"{estimate.cycles:.12g}" if estimate else ""
            ),
            "search_model_raw_ratio_vs_bank_seed": f"{score:.12g}",
            "search_model_ratio_vs_bank_seed": f"{score:.12g}",
            "search_model_calibration": "1",
            "search_model_confidence": estimate.confidence if estimate else "",
            "search_model_breakdown": estimate.breakdown() if estimate else "",
            "search_hbm_bytes": f"{hbm_bytes:.12g}",
            "search_l2_bytes": f"{l2_bytes:.12g}",
            "search_seed_key": str(seed_key),
            "search_history_match": "",
        }
    )
    for knowledge_name, column in BANK_COLUMNS.items():
        row[column] = str(knowledge[knowledge_name])
    return row


def update_callback_columns(
    state: State,
    callback: CallbackTiling,
    seed: Seed,
    bank_seed_estimate: ModelEstimate,
    hardware: Hardware,
    workload: Workload,
) -> None:
    estimate = analytical_score(
        workload, state.knowledge, hardware, callback
    )
    ratio = estimate.cycles / max(1.0, bank_seed_estimate.cycles)
    state.callback = callback
    state.estimate = estimate
    state.model_score = estimate.cycles
    state.normalized_score = ratio
    state.hbm_bytes = estimate.hbm_bytes
    state.l2_bytes = estimate.l2_bytes
    state.row.update(
        {
            "search_model_score": f"{ratio:.12g}",
            "search_model_cycles": f"{estimate.cycles:.12g}",
            "search_model_raw_ratio_vs_bank_seed": f"{ratio:.12g}",
            "search_model_ratio_vs_bank_seed": f"{ratio:.12g}",
            "search_model_calibration": "1",
            "search_model_confidence": estimate.confidence,
            "search_model_breakdown": estimate.breakdown(),
            "search_hbm_bytes": f"{estimate.hbm_bytes:.12g}",
            "search_l2_bytes": f"{estimate.l2_bytes:.12g}",
            "callback_tiling_sha256": callback.sha256,
            "callback_tiling_bytes": str(len(callback.blob)),
            "callback_tiling_key": str(callback.key),
            "callback_block_dim": str(callback.block_dim),
            "callback_workspace_bytes": str(sum(callback.workspaces)),
            "callback_l2_cache_flag": str(
                callback.derived.get("l2CacheFlag", "")
            ),
            "callback_base_an": str(callback.derived.get("baseAN", "")),
            "callback_base_ad": str(callback.derived.get("baseAD", "")),
            "callback_base_bn": str(callback.derived.get("baseBN", "")),
            "callback_base_bd": str(callback.derived.get("baseBD", "")),
            "callback_derived_diff_vs_default": callback_derived_diff(
                seed.default, callback
            ),
            "callback_derived_diff_vs_bank_seed": callback_derived_diff(
                seed.bank, callback
            ),
        }
    )


def deterministic_neighbors(
    fields: list[str],
    prototype: dict[str, str] | None,
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
    seed_score: float,
) -> list[State]:
    base = seed.knowledge
    if split_mode(base) != 3:
        return []

    states: list[State] = []
    k_chunks = ceil_div(workload.k, base["singleCoreK"])
    # The public MatMulV3 source defines deterministic Split-K as an MK33 or
    # NK33 template. Preserve that complete 3x3 contract and search only the
    # number of participating K-reduction cores, which the kernel distributes
    # with ceil(k_chunks / usedCoreNum).
    for cores in range(
        1, min(hardware.aic_cores, workload.max_cores, k_chunks) + 1
    ):
        state = dict(base)
        state["usedCoreNum"] = cores
        if not hard_legal(workload, state, hardware):
            continue
        if knowledge_signature(state) == knowledge_signature(base):
            continue
        estimate = analytical_score(workload, state, hardware)
        normalized = estimate.cycles / max(seed_score, 1.0)
        row = row_from_state(
            fields, prototype, workload, state,
            "template_beam_lns", "DETERMINISTIC_SPLIT_K",
            normalized, estimate.hbm_bytes, estimate.l2_bytes, seed.key,
            estimate=estimate,
        )
        states.append(
            State(
                row=row,
                knowledge=state,
                model_score=estimate.cycles,
                normalized_score=normalized,
                hbm_bytes=estimate.hbm_bytes,
                l2_bytes=estimate.l2_bytes,
                template="DETERMINISTIC_SPLIT_K",
                estimate=estimate,
            )
        )
    return states


def validate_callback(
    workload: Workload,
    state: State,
) -> CallbackTiling:
    callback = invoke_official_callback(workload, state.knowledge)
    observed = callback.knowledge
    mismatches = [
        f"{field}={observed[field]} expected={state.knowledge[field]}"
        for field in KNOWLEDGE_FIELDS
        if observed[field] != state.knowledge[field]
    ]
    if mismatches:
        raise SearchError("official callback changed candidate: " + "; ".join(mismatches))
    return callback


def source_guided_beam(
    states: list[State],
    hardware: Hardware,
    limit: int,
) -> list[State]:
    """Retain model leaders plus candidates aligned to whole AIC rounds.

    MatMulV3's public load-balance pass specializes this transformation for
    24 AICs. Ascend910B3 exposes 20 AICs to this operator, so derive the same
    target from the runtime platform instead of hard-coding 24.
    """
    if not states:
        return []
    model_leaders = sorted(
        states,
        key=lambda state: (
            state.normalized_score,
            knowledge_signature(state.knowledge),
        ),
    )
    if split_mode(states[0].knowledge) != 0:
        return model_leaders[:limit]
    max_blocks = max(
        ceil_div(
            int(state.row["m"]), state.knowledge["singleCoreM"]
        )
        * ceil_div(
            int(state.row["n"]), state.knowledge["singleCoreN"]
        )
        for state in states
    )
    max_round = min(8, ceil_div(max_blocks, hardware.aic_cores))
    guided: list[State] = []
    for rounds in range(1, max_round + 1):
        target = rounds * hardware.aic_cores

        def slot_key(state: State) -> tuple[float, float, float, tuple[int, ...]]:
            workload_m = int(state.row["m"])
            workload_n = int(state.row["n"])
            single_m = state.knowledge["singleCoreM"]
            single_n = state.knowledge["singleCoreN"]
            blocks = (
                ceil_div(workload_m, single_m)
                * ceil_div(workload_n, single_n)
            )
            padded = (
                ceil_div(workload_m, single_m) * single_m
                * ceil_div(workload_n, single_n) * single_n
            )
            tail_loss = 1.0 - (
                workload_m * workload_n / max(1.0, padded)
            )
            return (
                abs(blocks - target) / target,
                tail_loss,
                state.normalized_score,
                knowledge_signature(state.knowledge),
            )

        winner = min(states, key=slot_key)
        if not winner.guidance.startswith("core_slots"):
            winner.guidance = f"core_slots_{rounds}x{hardware.aic_cores}"
            winner.row["search_guidance"] = winner.guidance
        guided.append(winner)

    result: list[State] = []
    seen: set[tuple[int, ...]] = set()
    for state in [*guided, *model_leaders]:
        signature = knowledge_signature(state.knowledge)
        if signature in seen:
            continue
        seen.add(signature)
        result.append(state)
        if len(result) >= limit:
            break
    return result


def bank_seed_control(
    fields: list[str],
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> State:
    estimate = analytical_score(
        workload, seed.bank.knowledge, hardware, seed.bank
    )
    row = row_from_state(
        fields,
        None,
        workload,
        dict(seed.bank.knowledge),
        "official_seed_bank_roundtrip",
        template_name(seed.bank.knowledge),
        1.0,
        estimate.hbm_bytes,
        estimate.l2_bytes,
        seed.key,
        guidance="bank_path_control",
        candidate_role="bank_seed_control",
        estimate=estimate,
    )
    state = State(
        row=row,
        knowledge=dict(seed.bank.knowledge),
        model_score=estimate.cycles,
        normalized_score=1.0,
        hbm_bytes=estimate.hbm_bytes,
        l2_bytes=estimate.l2_bytes,
        template=template_name(seed.bank.knowledge),
        guidance="bank_path_control",
        callback=seed.bank,
        estimate=estimate,
    )
    update_callback_columns(
        state, seed.bank, seed, estimate, hardware, workload
    )
    state.row["search_model_ratio_vs_bank_seed"] = "1"
    state.row["search_model_score"] = "1"
    state.row["rank"] = "0"
    return state


def state_history_key(
    workload: Workload,
    knowledge: dict[str, int],
) -> tuple[str, ...]:
    m_blocks = ceil_div(workload.m, knowledge["singleCoreM"])
    n_blocks = ceil_div(workload.n, knowledge["singleCoreN"])
    return (
        workload.workload_id,
        f"{workload.m}x{workload.n}x{workload.k}",
        workload.dtype,
        template_name(knowledge),
        f"{knowledge['baseM']}x{knowledge['baseN']}x{knowledge['baseK']}",
        (
            f"{knowledge['singleCoreM']}x{knowledge['singleCoreN']}x"
            f"{knowledge['singleCoreK']}"
        ),
        str(knowledge["usedCoreNum"]),
        f"{m_blocks}x{n_blocks}",
        (
            f"{knowledge['l2MTileCnt']}x{knowledge['l2NTileCnt']}"
            f"({knowledge['l2MTileBlock']}x{knowledge['l2NTileBlock']})"
        ),
    )


def load_measurement_history(
    path: Path | None,
    soc: str,
    aic_cores: int,
) -> dict[tuple[str, ...], list[tuple[float, str]]]:
    if path is None or not path.is_file():
        return {}
    _, rows = read_csv(path)
    history: dict[tuple[str, ...], list[tuple[float, str]]] = {}
    for row in rows:
        if (
            row.get("record_type") != "candidate"
            or not truthy(row.get("ocr_complete"))
            or row.get("soc") != soc
            or int(row.get("aic") or 0) != aic_cores
        ):
            continue
        try:
            speedup = float(row.get("speedup_vs_official") or 0)
        except ValueError:
            continue
        if speedup <= 0:
            continue
        key = (
            row.get("workload_id", ""),
            row.get("shape", ""),
            row.get("dtype", "").lower(),
            row.get("template", ""),
            row.get("T", ""),
            row.get("S", ""),
            row.get("C", ""),
            row.get("G", ""),
            row.get("L2", ""),
        )
        history.setdefault(key, []).append(
            (1.0 / speedup, row.get("record_key", ""))
        )
    return history


def calibrate_from_history(
    workload: Workload,
    states: list[State],
    history: dict[tuple[str, ...], list[tuple[float, str]]],
    bank_path_diff: str,
) -> tuple[float, int]:
    # Historical measurements use the no-bank official operator as reference.
    # They cannot calibrate a workload where the bank path changes ND->NZ
    # fields until its new bank_seed_control has been measured.
    if bank_path_diff:
        return 1.0, 0

    exact: dict[tuple[str, ...], tuple[float, str]] = {}
    correction_by_key: dict[tuple[str, ...], float] = {}
    for state in states:
        key = state_history_key(workload, state.knowledge)
        records = history.get(key)
        if not records:
            continue
        actual_ratio = statistics.median(
            ratio for ratio, _ in records
        )
        record_ids = "|".join(
            sorted({record_id for _, record_id in records if record_id})
        )
        exact[key] = (actual_ratio, record_ids)
        correction_by_key[key] = (
            actual_ratio / max(1.0e-12, state.normalized_score)
        )

    correction = 1.0
    if len(correction_by_key) >= 2:
        correction = statistics.median(correction_by_key.values())
        # Residual calibration corrects local model bias; larger shifts require
        # a new bank control and are not extrapolated to unseen tilings.
        correction = min(1.15, max(0.85, correction))

    for state in states:
        key = state_history_key(workload, state.knowledge)
        raw_ratio = state.normalized_score
        if key in exact:
            adjusted, record_ids = exact[key]
            state.row["search_history_match"] = record_ids
            confidence = "measured_history"
        else:
            adjusted = raw_ratio * correction
            confidence = (
                "historically_calibrated"
                if len(correction_by_key) >= 2
                else state.row.get("search_model_confidence", "medium")
            )
        state.normalized_score = adjusted
        state.row.update(
            {
                "search_model_raw_ratio_vs_bank_seed": f"{raw_ratio:.12g}",
                "search_model_ratio_vs_bank_seed": f"{adjusted:.12g}",
                "search_model_score": f"{adjusted:.12g}",
                "search_model_calibration": f"{correction:.12g}",
                "search_model_confidence": confidence,
            }
        )
    return correction, len(exact)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-candidates", type=Path, required=True)
    parser.add_argument("--workloads", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--all-output", type=Path)
    parser.add_argument("--history", type=Path)
    parser.add_argument("--top-k", type=int, default=20)
    parser.add_argument("--beam-width", type=int, default=64)
    parser.add_argument("--model-ratio-limit", type=float, default=1.03)
    parser.add_argument("--soc", required=True)
    parser.add_argument("--aic-cores", type=int, required=True)
    parser.add_argument("--l0a-bytes", type=int, required=True)
    parser.add_argument("--l0b-bytes", type=int, required=True)
    parser.add_argument("--l0c-bytes", type=int, required=True)
    parser.add_argument("--l1-bytes", type=int, required=True)
    parser.add_argument("--l2-bytes", type=int, required=True)
    parser.add_argument(
        "--l2-bytes-per-cycle-per-core", type=float, required=True
    )
    parser.add_argument(
        "--hbm-bytes-per-cycle-per-core", type=float, required=True
    )
    args = parser.parse_args()
    hardware = Hardware(
        aic_cores=args.aic_cores,
        l0a_bytes=args.l0a_bytes,
        l0b_bytes=args.l0b_bytes,
        l0c_bytes=args.l0c_bytes,
        l1_bytes=args.l1_bytes,
        l2_bytes=args.l2_bytes,
        l2_bytes_per_cycle_per_core=args.l2_bytes_per_cycle_per_core,
        hbm_bytes_per_cycle_per_core=args.hbm_bytes_per_cycle_per_core,
    )
    if (
        args.top_k <= 0
        or args.beam_width <= 0
        or args.model_ratio_limit <= 0
        or any(
            value <= 0
            for value in (
                hardware.aic_cores,
                hardware.l0a_bytes,
                hardware.l0b_bytes,
                hardware.l0c_bytes,
                hardware.l1_bytes,
                hardware.l2_bytes,
                hardware.l2_bytes_per_cycle_per_core,
                hardware.hbm_bytes_per_cycle_per_core,
            )
        )
    ):
        raise SearchError("search limits and platform capacities must be positive")

    from tbe.common.platform import set_current_compile_soc_info
    from tbe.common.utils import op_tiling

    set_current_compile_soc_info(args.soc)
    op_tiling._RT_BANK_CACHE = {}

    raw_fields, raw_rows = read_csv(args.raw_candidates)
    output_fields = ["rank", *(field for field in raw_fields if field != "rank")]
    for column in EXTRA_COLUMNS:
        if column not in output_fields:
            output_fields.append(column)
    workloads = load_workloads(args.workloads)
    history = load_measurement_history(
        args.history, args.soc, hardware.aic_cores
    )

    # Capture both the no-bank default and the exact same 23 fields after the
    # RuntimeKb injection path. MatMulV3 derives ND->NZ fields after the bank
    # lookup, so these two blobs are not assumed to be identical.
    seeds: dict[str, Seed] = {}
    for workload in workloads:
        if workload.dtype in DTYPE_NAME:
            seeds[workload.workload_id] = parse_seed(workload)

    grouped: dict[str, list[dict[str, str]]] = {}
    for row in raw_rows:
        grouped.setdefault(row["workload_id"], []).append(row)

    selected_rows: list[dict[str, str]] = []
    all_rows: list[dict[str, str]] = []
    for workload in workloads:
        if workload.dtype not in DTYPE_NAME:
            continue
        seed = seeds[workload.workload_id]
        bank_path_diff = callback_derived_diff(
            seed.default, seed.bank
        )
        bank_seed_estimate = analytical_score(
            workload, seed.bank.knowledge, hardware, seed.bank
        )
        seed_score = bank_seed_estimate.cycles
        prototype = next(iter(grouped.get(workload.workload_id, [])), None)
        states: list[State] = []
        control = bank_seed_control(
            output_fields, workload, seed, hardware
        )
        selected_rows.append(dict(control.row))
        all_rows.append(dict(control.row))

        for raw in grouped.get(workload.workload_id, []):
            if (
                not truthy(raw.get("valid"))
                or raw.get("candidate_role") != "searched"
                or raw.get("execution_mode")
                not in {"base_iterate_all", "direct_atomic_split_k_fp32_nt"}
            ):
                continue
            knowledge = raw_knowledge(raw)
            for scheduled in l2_schedules(
                workload, knowledge, seed, hardware
            ):
                if not hard_legal(workload, scheduled, hardware):
                    continue
                if knowledge_signature(scheduled) == knowledge_signature(seed.knowledge):
                    continue
                estimate = analytical_score(workload, scheduled, hardware)
                normalized = estimate.cycles / max(seed_score, 1.0)
                row = row_from_state(
                    output_fields, raw, workload, scheduled,
                    "beam_lns_l2", template_name(scheduled), normalized,
                    estimate.hbm_bytes, estimate.l2_bytes, seed.key,
                    estimate=estimate,
                )
                states.append(
                    State(
                        row=row,
                        knowledge=scheduled,
                        model_score=estimate.cycles,
                        normalized_score=normalized,
                        hbm_bytes=estimate.hbm_bytes,
                        l2_bytes=estimate.l2_bytes,
                        template=template_name(scheduled),
                        estimate=estimate,
                    )
                )

        states.extend(
            deterministic_neighbors(
                output_fields, prototype, workload, seed,
                hardware, seed_score,
            )
        )
        unique_states: dict[tuple[int, ...], State] = {}
        for state in states:
            signature = knowledge_signature(state.knowledge)
            previous = unique_states.get(signature)
            if previous is None or state.normalized_score < previous.normalized_score:
                unique_states[signature] = state
        states = list(unique_states.values())
        states.sort(
            key=lambda state: (
                state.normalized_score,
                knowledge_signature(state.knowledge),
            )
        )

        # Keep a separate callback beam per kernel template. A single global
        # cutoff can otherwise erase a legal Split-K template behind many
        # nearly identical BASE states before template performance is compared.
        callback_limit = max(args.top_k * 3, args.beam_width)
        by_template: dict[str, list[State]] = {}
        for state in states:
            by_template.setdefault(state.template, []).append(state)
        callback_beams = {
            template: source_guided_beam(
                template_states, hardware, callback_limit
            )
            for template, template_states in by_template.items()
        }
        accepted: list[State] = []
        seen: set[tuple[int, ...]] = set()
        failures = 0
        first_failure = ""

        def try_callback(state: State) -> bool:
            nonlocal failures, first_failure
            signature = knowledge_signature(state.knowledge)
            if signature in seen:
                return False
            seen.add(signature)
            try:
                callback = validate_callback(workload, state)
            except Exception as exception:
                failures += 1
                if not first_failure:
                    first_failure = str(exception).replace("\n", " ")[:240]
                return False
            update_callback_columns(
                state,
                callback,
                seed,
                bank_seed_estimate,
                hardware,
                workload,
            )
            accepted.append(state)
            return True

        # First secure one valid representative of every generated template.
        for template in sorted(callback_beams):
            for state in callback_beams[template]:
                if try_callback(state):
                    break

        remaining = sorted(
            (
                state
                for template_states in callback_beams.values()
                for state in template_states
                if knowledge_signature(state.knowledge) not in seen
            ),
            key=lambda state: (
                state.normalized_score,
                knowledge_signature(state.knowledge),
            ),
        )
        for state in remaining:
            try_callback(state)
            if len(accepted) >= args.top_k:
                break

        history_correction, history_matches = calibrate_from_history(
            workload,
            accepted,
            history,
            bank_path_diff,
        )
        accepted.sort(
            key=lambda state: (
                state.normalized_score,
                knowledge_signature(state.knowledge),
            )
        )
        callback_valid = len(accepted)
        accepted = [
            state
            for state in accepted
            if (
                state.normalized_score <= args.model_ratio_limit
                and not dominated_by_bank_seed(state.knowledge, seed)
            )
        ][:args.top_k]

        for rank, state in enumerate(accepted, 1):
            state.row["rank"] = str(rank)
            selected_rows.append(dict(state.row))
        for rank, state in enumerate(states, 1):
            state.row["rank"] = str(rank)
            all_rows.append(dict(state.row))

        print(
            f"template_search: {workload.workload_id} "
            f"official={template_name(seed.knowledge)} "
            f"bank_seed_diff="
            f"{bank_path_diff or 'none'} "
            f"generated={len(states)} callback_valid={callback_valid} "
            f"selected_for_npu={len(accepted)} "
            f"model_ratio_limit={args.model_ratio_limit:.3g} "
            f"history_matches={history_matches} "
            f"history_correction={history_correction:.4g} "
            f"callback_rejected={failures}"
            f"{f' first_rejection={first_failure}' if first_failure else ''}",
            flush=True,
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=output_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(selected_rows)
    if args.all_output:
        args.all_output.parent.mkdir(parents=True, exist_ok=True)
        with args.all_output.open("w", newline="", encoding="utf-8") as destination:
            writer = csv.DictWriter(destination, fieldnames=output_fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(all_rows)
    print(
        f"template_search_completed: workloads={len(workloads)} "
        f"searched_selected="
        f"{sum(row.get('candidate_role') == 'searched' for row in selected_rows)} "
        f"bank_seed_controls="
        f"{sum(row.get('candidate_role') == 'bank_seed_control' for row in selected_rows)}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (SearchError, OSError, ValueError, KeyError) as exception:
        print(f"fatal: {exception}", flush=True)
        raise SystemExit(1)

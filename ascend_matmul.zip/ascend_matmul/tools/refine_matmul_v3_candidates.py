#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import struct
import warnings
from dataclasses import dataclass
from pathlib import Path


warnings.filterwarnings("ignore", category=Warning, module="requests")


KNOWLEDGE_FIELDS = (
    "usedCoreNum", "singleCoreM", "singleCoreN", "singleCoreK",
    "baseM", "baseN", "baseK", "depthA1", "depthB1", "stepM",
    "stepN", "iterateOrder", "stepKa", "stepKb", "dbL0A", "dbL0B",
    "dbL0C", "l2MTileCnt", "l2NTileCnt", "l2MTileBlock",
    "l2NTileBlock", "l2IterateOrder", "tilingEnable",
)

BANK_COLUMNS = {
    "tilingEnable": "bank_tiling_enable",
    "l2MTileCnt": "bank_l2_m_tile_count",
    "l2NTileCnt": "bank_l2_n_tile_count",
    "l2MTileBlock": "bank_l2_m_tile_block",
    "l2NTileBlock": "bank_l2_n_tile_block",
    "l2IterateOrder": "bank_l2_iterate_order",
}

EXTRA_COLUMNS = [
    *BANK_COLUMNS.values(),
    "search_template", "search_guidance", "search_model_score",
    "search_model_cycles", "search_model_raw_ratio_vs_bank_seed",
    "search_model_ratio_vs_bank_seed", "search_model_calibration",
    "search_model_confidence", "search_model_breakdown",
    "search_hbm_bytes", "search_l2_bytes", "search_seed_key",
    "callback_tiling_sha256", "callback_tiling_bytes",
    "callback_tiling_key", "callback_block_dim", "callback_workspace_bytes",
    "callback_l2_cache_flag", "callback_base_an", "callback_base_ad",
    "callback_base_bn", "callback_base_bd",
    "callback_kernel_suffix", "callback_kernel_variant",
    "callback_kernel_family",
    "callback_derived_diff_vs_default",
    "callback_derived_diff_vs_bank_seed",
    "search_history_match",
]

DTYPE_NAME = {
    "fp16": "float16",
    "bf16": "bfloat16",
    "fp32": "float32",
}

INPUT_BYTES = {"fp16": 2, "bf16": 2, "fp32": 4}
OUTPUT_BYTES = {"fp16": 2, "bf16": 2, "fp32": 4}

# These are the complete low-decimal suffixes dispatched by the installed
# CANN 8.1 MatMulV3 AscendC kernel on DAV C220. The suffix is authoritative:
# modes added by later CANN releases are deliberately not generated.
CANN81_KERNEL_VARIANTS = {
    0: ("BASE_UNALIGNED", "BASE"),
    1: ("BASE_ALIGNED", "BASE"),
    20: ("SINGLE_CORE_SPLIT_K_UNALIGNED", "SINGLE_CORE_SPLIT_K"),
    21: ("SINGLE_CORE_SPLIT_K_ALIGNED", "SINGLE_CORE_SPLIT_K"),
    30: ("DETERMINISTIC_SPLIT_K_UNALIGNED", "DETERMINISTIC_SPLIT_K"),
    31: ("DETERMINISTIC_SPLIT_K_ALIGNED", "DETERMINISTIC_SPLIT_K"),
    101: ("AL1_FULL_LOAD_ALIGNED", "AL1_FULL_LOAD"),
    200: ("BL1_FULL_LOAD_UNALIGNED", "BL1_FULL_LOAD"),
    201: ("BL1_FULL_LOAD_ALIGNED", "BL1_FULL_LOAD"),
    10200: ("BL1_FULL_LOAD_FIXPIPE_UNALIGNED", "BL1_FULL_LOAD_FIXPIPE"),
    10201: ("BL1_FULL_LOAD_FIXPIPE_ALIGNED", "BL1_FULL_LOAD_FIXPIPE"),
    20201: ("BL1_FULL_LOAD_VEC_NZ2ND", "BL1_FULL_LOAD_VEC_NZ2ND"),
}

# MatmulV3TilingData is TCubeTiling (50 words), L2CacheTilePara (5),
# seven run-info words, l2CacheFlag, then the ND->NZ vector tiling. These
# offsets are part of the public MatMulV3 tiling-data definition. Keep unknown
# trailing words in the hash even when a CANN release extends the structure.
DERIVED_WORDS = {
    62: "l2CacheFlag",
    63: "baseAN",
    64: "baseAD",
    65: "baseBN",
    66: "baseBD",
}


class SearchError(RuntimeError):
    pass


@dataclass(frozen=True)
class Workload:
    workload_id: str
    m: int
    n: int
    k: int
    dtype: str
    trans_a: bool
    trans_b: bool
    max_cores: int


@dataclass(frozen=True)
class Hardware:
    aic_cores: int
    l0a_bytes: int
    l0b_bytes: int
    l0c_bytes: int
    l1_bytes: int
    l2_bytes: int
    l2_bytes_per_cycle_per_core: float
    hbm_bytes_per_cycle_per_core: float


@dataclass(frozen=True)
class CallbackTiling:
    key: int
    block_dim: int
    workspaces: tuple[int, ...]
    blob: bytes
    sha256: str
    words: tuple[int, ...]
    cube: tuple[int, ...]
    l2: tuple[int, ...]
    knowledge: dict[str, int]
    derived: dict[str, int]


@dataclass
class Seed:
    default: CallbackTiling
    bank: CallbackTiling

    @property
    def key(self) -> int:
        return self.default.key

    @property
    def block_dim(self) -> int:
        return self.default.block_dim

    @property
    def workspace(self) -> int:
        return sum(self.default.workspaces)

    @property
    def knowledge(self) -> dict[str, int]:
        return self.default.knowledge


@dataclass(frozen=True)
class ModelEstimate:
    cycles: float
    hbm_bytes: float
    l2_bytes: float
    cube_cycles: float
    mte2_cycles: float
    mte1_cycles: float
    fixpipe_cycles: float
    nd2nz_cycles: float
    issue_cycles: float
    balance: float
    confidence: str

    def breakdown(self) -> str:
        values = {
            "cube": self.cube_cycles,
            "mte2": self.mte2_cycles,
            "mte1": self.mte1_cycles,
            "fixpipe": self.fixpipe_cycles,
            "nd2nz": self.nd2nz_cycles,
            "issue": self.issue_cycles,
            "balance": self.balance,
        }
        return json.dumps(values, separators=(",", ":"), sort_keys=True)


@dataclass
class State:
    row: dict[str, str]
    knowledge: dict[str, int]
    model_score: float
    normalized_score: float
    hbm_bytes: float
    l2_bytes: float
    template: str
    guidance: str = "analytical_beam"
    callback: CallbackTiling | None = None
    estimate: ModelEstimate | None = None


def truthy(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def ceil_div(value: int, divisor: int) -> int:
    return (value + divisor - 1) // divisor


def align_up(value: int, alignment: int) -> int:
    return ceil_div(value, alignment) * alignment


def cube_k0(dtype: str) -> int:
    return 8 if dtype == "fp32" else 16


def base_k_alignment(workload: Workload) -> int:
    # TCubeTiling permits FP32 K0 alignment only for ND x transposed-ND.
    # All other layouts use 16-element baseK alignment.
    if workload.dtype == "fp32" and not workload.trans_a and workload.trans_b:
        return 8
    return 16


def effective_l1_bytes(hardware: Hardware) -> int:
    # Ascend910B3 reports 512 KiB minus one 256-byte bookkeeping block through
    # platform_info, while the official MatMulV3 tiler legally emits a full
    # 512 KiB A1+B1 plan. Match that allocator-visible KiB granularity.
    return align_up(hardware.l1_bytes, 1024)


def callback_derived_diff(
    left: CallbackTiling,
    right: CallbackTiling,
) -> str:
    names: list[str] = []
    for index, name in DERIVED_WORDS.items():
        if index >= len(left.words) or index >= len(right.words):
            continue
        if left.words[index] != right.words[index]:
            names.append(
                f"{name}:{left.words[index]}->{right.words[index]}"
            )
    if len(left.words) != len(right.words):
        names.append(f"word_count:{len(left.words)}->{len(right.words)}")
    return "|".join(names)


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as source:
        reader = csv.DictReader(source)
        rows = list(reader)
        fields = list(reader.fieldnames or [])
    if not fields:
        raise SearchError(f"{path}: missing CSV header")
    return fields, rows


def load_workloads(path: Path) -> list[Workload]:
    _, rows = read_csv(path)
    workloads: list[Workload] = []
    for row in rows:
        dtype = row["dtype"].lower()
        workloads.append(
            Workload(
                workload_id=row.get("workload_id") or row["id"],
                m=int(row["m"]),
                n=int(row["n"]),
                k=int(row["k"]),
                dtype=dtype,
                trans_a=truthy(row.get("trans_a")),
                trans_b=truthy(row.get("trans_b")),
                max_cores=int(row.get("max_cores") or 24),
            )
        )
    return workloads


def decode_tiling_enable(tiling_key: int) -> int:
    # CANN 8.1 kernel key suffix is FIX,SPECIAL,FULL,SPLIT,MIX in decimal
    # positions 10^4..10^0. RuntimeKb omits MIX and encodes
    # split + 10*full + 1000*fix.
    suffix = tiling_key % 100000
    split = (suffix // 10) % 10
    full = (suffix // 100) % 10
    fix = (suffix // 10000) % 10
    return split + 10 * full + 1000 * fix


def kernel_suffix(tiling_key: int) -> int:
    return tiling_key % 100000


def kernel_variant(tiling_key: int) -> str:
    suffix = kernel_suffix(tiling_key)
    try:
        return CANN81_KERNEL_VARIANTS[suffix][0]
    except KeyError as exception:
        raise SearchError(
            f"CANN 8.1 MatMulV3 kernel has no dispatch for suffix {suffix}"
        ) from exception


def kernel_family(tiling_key: int) -> str:
    suffix = kernel_suffix(tiling_key)
    try:
        return CANN81_KERNEL_VARIANTS[suffix][1]
    except KeyError as exception:
        raise SearchError(
            f"CANN 8.1 MatMulV3 kernel has no dispatch for suffix {suffix}"
        ) from exception


def fix_mode(knowledge: dict[str, int]) -> int:
    return (knowledge["tilingEnable"] // 1000) % 10


def special_mode(knowledge: dict[str, int]) -> int:
    return (knowledge["tilingEnable"] // 10000) % 10


def split_mode(knowledge: dict[str, int]) -> int:
    return knowledge["tilingEnable"] % 10


def full_load_mode(knowledge: dict[str, int]) -> int:
    return (knowledge["tilingEnable"] // 10) % 10


def template_name(knowledge: dict[str, int]) -> str:
    split = split_mode(knowledge)
    full = full_load_mode(knowledge)
    fix = fix_mode(knowledge)
    if split == 3:
        return "DETERMINISTIC_SPLIT_K"
    if split == 2:
        return "SINGLE_CORE_SPLIT_K"
    if full == 1:
        return "AL1_FULL_LOAD"
    if full == 2:
        if fix == 1:
            return "BL1_FULL_LOAD_FIXPIPE"
        if fix == 2:
            return "BL1_FULL_LOAD_VEC_NZ2ND"
        return "BL1_FULL_LOAD"
    return "BASE"


def tensor_desc(name: str, shape: list[int], dtype: str) -> dict:
    return {
        "name": name,
        "shape": shape,
        "ori_shape": shape,
        "format": "ND",
        "ori_format": "ND",
        "dtype": DTYPE_NAME[dtype],
    }


def callback_knowledge(
    result: dict,
    cube: tuple[int, ...],
    l2: tuple[int, ...],
) -> dict[str, int]:
    return {
        "usedCoreNum": cube[0],
        "singleCoreM": cube[5],
        "singleCoreN": cube[6],
        "singleCoreK": cube[7],
        "baseM": cube[8],
        "baseN": cube[9],
        "baseK": cube[10],
        "depthA1": cube[11],
        "depthB1": cube[12],
        "stepM": cube[13],
        "stepN": cube[14],
        "iterateOrder": cube[17],
        "stepKa": cube[26],
        "stepKb": cube[27],
        "dbL0A": cube[30],
        "dbL0B": cube[31],
        "dbL0C": cube[32],
        "l2MTileCnt": l2[0],
        "l2NTileCnt": l2[1],
        "l2MTileBlock": l2[2],
        "l2NTileBlock": l2[3],
        "l2IterateOrder": l2[4],
        "tilingEnable": decode_tiling_enable(int(result["tiling_key"])),
    }


def parse_callback_result(result: dict) -> CallbackTiling:
    blob = bytes(result["tiling_data"])
    if len(blob) < 220 or len(blob) % 4:
        raise SearchError(
            f"unexpected MatMulV3 tiling_data size={len(blob)}"
        )
    cube = struct.unpack_from("<50i", blob, 0)
    l2 = struct.unpack_from("<5I", blob, 200)
    words = struct.unpack(f"<{len(blob) // 4}I", blob)
    derived = {
        name: int(words[index])
        for index, name in DERIVED_WORDS.items()
        if index < len(words)
    }
    workspaces = tuple(int(value) for value in (result.get("workspaces") or [0]))
    key = int(result["tiling_key"])
    kernel_variant(key)
    return CallbackTiling(
        key=key,
        block_dim=int(result["block_dim"]),
        workspaces=workspaces,
        blob=blob,
        sha256=hashlib.sha256(blob).hexdigest(),
        words=tuple(int(value) for value in words),
        cube=tuple(int(value) for value in cube),
        l2=tuple(int(value) for value in l2),
        knowledge=callback_knowledge(result, cube, l2),
        derived=derived,
    )


def invoke_official_callback(
    workload: Workload,
    injected: dict[str, int] | None = None,
) -> CallbackTiling:
    from tbe.common.utils import op_tiling

    shape_a = [workload.k, workload.m] if workload.trans_a else [workload.m, workload.k]
    shape_b = [workload.n, workload.k] if workload.trans_b else [workload.k, workload.n]
    attrs = [
        {"name": "transpose_x1", "dtype": "bool", "value": workload.trans_a},
        {"name": "transpose_x2", "dtype": "bool", "value": workload.trans_b},
        {"name": "offset_x", "dtype": "int", "value": 0},
        {"name": "enable_hf32", "dtype": "bool", "value": False},
    ]
    op_tiling._RT_BANK_CACHE = injected or {}
    result = op_tiling.do_op_tiling(
        "MatMulV3",
        {},
        [
            tensor_desc("x1", shape_a, workload.dtype),
            tensor_desc("x2", shape_b, workload.dtype),
            None,
            None,
        ],
        [tensor_desc("y", [workload.m, workload.n], workload.dtype)],
        attrs=attrs,
    )
    return parse_callback_result(result)


def parse_seed(workload: Workload) -> Seed:
    default = invoke_official_callback(workload)
    bank = invoke_official_callback(workload, default.knowledge)
    return Seed(default=default, bank=bank)


def raw_knowledge(row: dict[str, str]) -> dict[str, int]:
    return {
        "usedCoreNum": int(row["used_core_num"]),
        "singleCoreM": int(row["single_core_m"]),
        "singleCoreN": int(row["single_core_n"]),
        "singleCoreK": int(row["single_core_k"]),
        "baseM": int(row["base_m"]),
        "baseN": int(row["base_n"]),
        "baseK": int(row["base_k"]),
        "depthA1": int(row["depth_a1"]),
        "depthB1": int(row["depth_b1"]),
        "stepM": int(row["step_m"]),
        "stepN": int(row["step_n"]),
        "iterateOrder": int(row["iterate_order"]),
        "stepKa": int(row["step_ka"]),
        "stepKb": int(row["step_kb"]),
        "dbL0A": int(row["db_l0a"]),
        "dbL0B": int(row["db_l0b"]),
        "dbL0C": int(row["db_l0c"]),
        "l2MTileCnt": 1,
        "l2NTileCnt": 1,
        "l2MTileBlock": 1,
        "l2NTileBlock": 1,
        "l2IterateOrder": 0,
        "tilingEnable": 0,
    }


def l2_base_schedule_legal(
    workload: Workload,
    knowledge: dict[str, int],
) -> bool:
    m_total = ceil_div(workload.m, knowledge["singleCoreM"])
    n_total = ceil_div(workload.n, knowledge["singleCoreN"])
    m_block = knowledge["l2MTileBlock"]
    n_block = knowledge["l2NTileBlock"]
    if m_block == 0 or n_block == 0:
        return (
            m_block == 0
            and n_block == 0
            and knowledge["l2MTileCnt"] == 1
            and knowledge["l2NTileCnt"] == 1
        )
    if (
        knowledge["l2MTileCnt"] != ceil_div(m_total, m_block)
        or knowledge["l2NTileCnt"] != ceil_div(n_total, n_block)
    ):
        return False
    m_tail = m_total - (knowledge["l2MTileCnt"] - 1) * m_block
    n_tail = n_total - (knowledge["l2NTileCnt"] - 1) * n_block
    return 1 <= m_tail <= m_block and 1 <= n_tail <= n_block


def tiling_enable_legal(knowledge: dict[str, int]) -> bool:
    split = split_mode(knowledge)
    full = full_load_mode(knowledge)
    fix = fix_mode(knowledge)
    special = special_mode(knowledge)
    if special != 0 or split not in (0, 2, 3):
        return False
    if full not in (0, 1, 2) or fix not in (0, 1, 2):
        return False
    if split != 0:
        return full == 0 and fix == 0
    if full == 0:
        return fix == 0
    if full == 1:
        return fix == 0
    return True


def hard_legal(
    workload: Workload,
    knowledge: dict[str, int],
    hardware: Hardware,
) -> bool:
    required_positive = (
        "usedCoreNum", "singleCoreM", "singleCoreN", "singleCoreK",
        "baseM", "baseN", "baseK", "depthA1", "depthB1", "stepM",
        "stepN", "stepKa", "stepKb", "dbL0A", "dbL0B", "dbL0C",
        "l2MTileCnt", "l2NTileCnt",
    )
    if any(knowledge[name] <= 0 for name in required_positive):
        return False
    if knowledge["l2MTileBlock"] < 0 or knowledge["l2NTileBlock"] < 0:
        return False
    if not tiling_enable_legal(knowledge):
        return False
    if knowledge["usedCoreNum"] > min(workload.max_cores, hardware.aic_cores):
        return False
    if knowledge["iterateOrder"] not in (0, 1) or knowledge["l2IterateOrder"] not in (0, 1):
        return False
    if any(knowledge[name] not in (1, 2) for name in ("dbL0A", "dbL0B", "dbL0C")):
        return False

    k0 = base_k_alignment(workload)
    if (
        knowledge["baseM"] % 16
        or knowledge["baseN"] % 16
        or knowledge["baseK"] % k0
    ):
        return False

    in_bytes = INPUT_BYTES[workload.dtype]
    l0a = (
        knowledge["baseM"] * knowledge["baseK"] * in_bytes
        * knowledge["dbL0A"]
    )
    l0b = (
        knowledge["baseN"] * knowledge["baseK"] * in_bytes
        * knowledge["dbL0B"]
    )
    l0c = knowledge["baseM"] * knowledge["baseN"] * 4 * knowledge["dbL0C"]
    if (
        l0a > hardware.l0a_bytes
        or l0b > hardware.l0b_bytes
        or l0c > hardware.l0c_bytes
    ):
        return False

    one_a = knowledge["stepM"] * knowledge["stepKa"]
    one_b = knowledge["stepN"] * knowledge["stepKb"]
    if knowledge["depthA1"] % one_a or knowledge["depthB1"] % one_b:
        return False
    if knowledge["depthA1"] // one_a not in (1, 2):
        return False
    if knowledge["depthB1"] // one_b not in (1, 2):
        return False
    a1 = (
        knowledge["baseM"] * knowledge["baseK"]
        * knowledge["depthA1"] * in_bytes
    )
    b1 = (
        knowledge["baseN"] * knowledge["baseK"]
        * knowledge["depthB1"] * in_bytes
    )
    if a1 + b1 > effective_l1_bytes(hardware):
        return False

    if (
        knowledge["stepKa"] % knowledge["stepKb"]
        and knowledge["stepKb"] % knowledge["stepKa"]
    ):
        return False
    split = split_mode(knowledge)
    full = full_load_mode(knowledge)
    fix = fix_mode(knowledge)

    if split == 0 and full == 0:
        if (
            knowledge["singleCoreK"] != workload.k
            or knowledge["singleCoreM"] > knowledge["baseM"]
            or knowledge["singleCoreN"] > knowledge["baseN"]
            or knowledge["baseM"] > align_up(knowledge["singleCoreM"], 16)
            or knowledge["baseN"] > align_up(knowledge["singleCoreN"], 16)
            or knowledge["baseK"] > align_up(
                knowledge["singleCoreK"], k0
            )
            or not l2_base_schedule_legal(workload, knowledge)
        ):
            return False
    elif split == 2:
        if (
            knowledge["singleCoreK"]
            != knowledge["stepKa"] * knowledge["baseK"]
            or knowledge["stepKa"] != knowledge["stepKb"]
            or knowledge["singleCoreK"] >= workload.k
            or ceil_div(workload.k, knowledge["singleCoreK"]) < 2
            or knowledge["singleCoreM"]
            < knowledge["stepM"] * knowledge["baseM"]
        ):
            return False
        if (
            knowledge["l2IterateOrder"] == 1
            and knowledge["singleCoreN"]
            < knowledge["stepN"] * knowledge["baseN"]
        ):
            return False
    elif split == 3:
        expected_base_k = 256 // in_bytes
        if (
            knowledge["baseM"], knowledge["baseN"], knowledge["baseK"]
        ) != (128, 128, expected_base_k):
            return False
        mk33 = (
            knowledge["stepM"], knowledge["stepN"],
            knowledge["stepKa"], knowledge["stepKb"],
            knowledge["depthA1"], knowledge["depthB1"],
            knowledge["singleCoreM"],
        ) == (3, 1, 3, 3, 9, 6, 384)
        nk33 = (
            knowledge["stepM"], knowledge["stepN"],
            knowledge["stepKa"], knowledge["stepKb"],
            knowledge["depthA1"], knowledge["depthB1"],
            knowledge["singleCoreN"],
        ) == (1, 3, 3, 3, 6, 9, 384)
        k_chunks = ceil_div(workload.k, knowledge["singleCoreK"])
        if (
            not (mk33 or nk33)
            or knowledge["singleCoreK"] != 3 * knowledge["baseK"]
            or k_chunks < 2
            or knowledge["usedCoreNum"] > k_chunks
        ):
            return False
    elif split == 0 and full == 1:
        if (
            workload.dtype != "fp32"
            or workload.trans_a
            or not workload.trans_b
            or workload.m > 16
            or workload.n <= 16
            or workload.n > 16 * hardware.aic_cores
            or workload.k < 4096
            or workload.k % (512 // in_bytes)
            or knowledge["baseM"] != 16
            or knowledge["singleCoreM"] < workload.m
            or knowledge["singleCoreM"] > 16
            or knowledge["singleCoreN"] < knowledge["baseN"]
            or knowledge["singleCoreK"] < workload.k
            or knowledge["stepM"] != 1
            or knowledge["stepN"] != 1
            or knowledge["stepKa"] != ceil_div(
                workload.k, knowledge["baseK"]
            )
            or knowledge["stepKb"] != 1
            or knowledge["depthA1"] != knowledge["stepKa"]
            or knowledge["depthB1"] not in (1, 2)
            or not l2_base_schedule_legal(workload, knowledge)
        ):
            return False
        al1_bytes = (
            align_up(workload.m, 16)
            * align_up(workload.k, 32 // in_bytes)
            * in_bytes
        )
        if al1_bytes + b1 > effective_l1_bytes(hardware):
            return False
    elif split == 0 and full == 2:
        if (
            workload.m <= 16 * max(workload.k, workload.n)
            or workload.k > 256
            or knowledge["singleCoreK"] < workload.k
            or knowledge["singleCoreM"] < knowledge["baseM"]
            or knowledge["singleCoreN"] < workload.n
            or knowledge["stepM"] != 1
            or knowledge["stepN"] != ceil_div(
                workload.n, knowledge["baseN"]
            )
            or knowledge["stepKa"] != ceil_div(
                workload.k, knowledge["baseK"]
            )
            or knowledge["stepKb"] != knowledge["stepKa"]
            or knowledge["depthB1"]
            != knowledge["stepN"] * knowledge["stepKb"]
            or not l2_base_schedule_legal(workload, knowledge)
        ):
            return False
        c0 = 32 // in_bytes
        resident_b = (
            align_up(workload.k, 16)
            * align_up(knowledge["singleCoreN"], c0)
            * in_bytes
        )
        if b1 < resident_b:
            return False
        fixpipe_bound = bl1_fixpipe_bound(workload)
        if fix == 1 and not fixpipe_bound:
            return False
        if fix == 2 and (
            workload.dtype != "fp32"
            or workload.trans_a
            or workload.n > 192
            or workload.k % c0
        ):
            return False
        if fix in (1, 2) and (
            knowledge["l2MTileBlock"] != 0
            or knowledge["l2NTileBlock"] != 0
        ):
            return False
    else:
        return False

    if split in (2, 3):
        if (
            knowledge["l2MTileBlock"] <= 0
            or knowledge["l2NTileBlock"] <= 0
        ):
            return False
    if split == 3:
        k_chunks = ceil_div(workload.k, knowledge["singleCoreK"])
        if (
            knowledge["usedCoreNum"] > k_chunks
            or knowledge["usedCoreNum"] <= 0
        ):
            return False
    return True


def axis_values(total: int, target: int) -> list[int]:
    values = {
        1,
        total,
        max(1, min(total, target)),
        max(1, min(total, target - 1)),
        max(1, min(total, target + 1)),
        max(1, min(total, ceil_div(target, 2))),
        max(1, min(total, target * 2)),
    }
    return sorted(values)


def l2_schedules(
    workload: Workload,
    knowledge: dict[str, int],
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    m_total = ceil_div(workload.m, knowledge["singleCoreM"])
    n_total = ceil_div(workload.n, knowledge["singleCoreN"])
    seed_k = seed.knowledge
    target_m_elements = seed_k["singleCoreM"] * seed_k["l2MTileBlock"]
    target_n_elements = seed_k["singleCoreN"] * seed_k["l2NTileBlock"]
    target_m = ceil_div(target_m_elements, knowledge["singleCoreM"])
    target_n = ceil_div(target_n_elements, knowledge["singleCoreN"])

    schedules: list[tuple[float, dict[str, int]]] = []
    for m_block in axis_values(m_total, target_m):
        for n_block in axis_values(n_total, target_n):
            for order in (seed_k["l2IterateOrder"], 1 - seed_k["l2IterateOrder"]):
                candidate = dict(knowledge)
                candidate["l2MTileBlock"] = m_block
                candidate["l2NTileBlock"] = n_block
                candidate["l2MTileCnt"] = ceil_div(m_total, m_block)
                candidate["l2NTileCnt"] = ceil_div(n_total, n_block)
                candidate["l2IterateOrder"] = order

                m_extent = min(workload.m, m_block * knowledge["singleCoreM"])
                n_extent = min(workload.n, n_block * knowledge["singleCoreN"])
                in_bytes = INPUT_BYTES[workload.dtype]
                out_bytes = OUTPUT_BYTES[workload.dtype]
                working_set = (
                    m_extent * workload.k * in_bytes
                    + workload.k * n_extent * in_bytes
                    + m_extent * n_extent * out_bytes
                )
                # MatMulV3 scales its empirically safe 100 MiB working-set
                # threshold linearly from the 192 MiB Ascend910B L2.
                l2_working_set_limit = (
                    hardware.l2_bytes
                    / float(192 * 1024 * 1024)
                    * 100 * 1024 * 1024
                )
                capacity_overflow = max(
                    0.0, working_set / max(1.0, l2_working_set_limit) - 1.0
                )
                m_tail = m_total - (candidate["l2MTileCnt"] - 1) * m_block
                n_tail = n_total - (candidate["l2NTileCnt"] - 1) * n_block
                # Match MatmulV3BaseTiling::InitL2SplitParams: the outer
                # axis permits five-way conflict on a 20-AIC product; the
                # unfavorable inner layout permits four-way conflict.
                if knowledge["baseN"] >= knowledge["baseM"]:
                    m_conflict = 4 if workload.trans_a else 5
                    n_conflict = 5
                else:
                    m_conflict = 5
                    n_conflict = 4 if not workload.trans_b else 5
                tail_penalty = 0.0
                if (
                    m_total > m_block
                    and m_tail * m_conflict < hardware.aic_cores
                ):
                    tail_penalty += (
                        hardware.aic_cores - m_tail * m_conflict
                    ) / hardware.aic_cores
                if (
                    n_total > n_block
                    and n_tail * n_conflict < hardware.aic_cores
                ):
                    tail_penalty += (
                        hardware.aic_cores - n_tail * n_conflict
                    ) / hardware.aic_cores
                distance = (
                    abs(m_block - target_m) / max(1, target_m)
                    + abs(n_block - target_n) / max(1, target_n)
                )
                schedules.append(
                    (5.0 * capacity_overflow + 2.0 * tail_penalty + 0.01 * distance, candidate)
                )
    schedules.sort(key=lambda item: item[0])
    unique: list[dict[str, int]] = []
    seen: set[tuple[int, ...]] = set()
    for _, candidate in schedules:
        signature = tuple(candidate[field] for field in KNOWLEDGE_FIELDS)
        if signature in seen:
            continue
        seen.add(signature)
        unique.append(candidate)
        if len(unique) == 3:
            break
    return unique


def deduplicate_knowledge(
    candidates: list[dict[str, int]],
) -> list[dict[str, int]]:
    result: list[dict[str, int]] = []
    seen: set[tuple[int, ...]] = set()
    for candidate in candidates:
        signature = knowledge_signature(candidate)
        if signature in seen:
            continue
        seen.add(signature)
        result.append(candidate)
    return result


def partition_pairs(
    workload: Workload,
    hardware: Hardware,
    max_rounds: int = 8,
) -> list[tuple[int, int]]:
    core_limit = max(
        1, min(workload.max_cores, hardware.aic_cores)
    )
    max_m_parts = max(1, min(8 * core_limit, ceil_div(workload.m, 16)))
    max_n_parts = max(1, min(8 * core_limit, ceil_div(workload.n, 16)))
    pairs: set[tuple[int, int]] = {(1, 1)}
    for rounds in range(1, max_rounds + 1):
        target = rounds * core_limit
        ideal_m = math.sqrt(
            target * max(1.0, workload.m) / max(1.0, workload.n)
        )
        probes = {
            1,
            min(max_m_parts, target),
            max(1, min(max_m_parts, int(ideal_m))),
            max(1, min(max_m_parts, int(math.ceil(ideal_m)))),
        }
        for divisor in range(1, int(math.sqrt(target)) + 1):
            if target % divisor == 0:
                probes.add(min(max_m_parts, divisor))
                probes.add(min(max_m_parts, target // divisor))
        for m_parts in probes:
            for n_parts in {
                max(1, min(max_n_parts, target // max(1, m_parts))),
                max(1, min(max_n_parts, ceil_div(target, max(1, m_parts)))),
            }:
                pairs.add((m_parts, n_parts))
    return sorted(
        pairs,
        key=lambda pair: (
            abs(pair[0] * pair[1] - core_limit),
            abs(
                pair[0] / max(1.0, pair[1])
                - workload.m / max(1.0, workload.n)
            ),
            pair,
        ),
    )


def base_candidate_space(
    workload: Workload,
    seed: Seed,
    raw_rows: list[dict[str, str]],
    hardware: Hardware,
    beam_width: int,
) -> list[dict[str, int]]:
    anchors: list[dict[str, int]] = []
    if template_name(seed.bank.knowledge) == "BASE":
        anchors.append(dict(seed.bank.knowledge))
    raw_limit = max(beam_width * 2, 32)
    for row in raw_rows:
        if len(anchors) >= raw_limit:
            break
        if (
            not truthy(row.get("valid"))
            or row.get("candidate_role") != "searched"
            or row.get("execution_mode") != "base_iterate_all"
        ):
            continue
        anchors.append(raw_knowledge(row))

    candidates: list[dict[str, int]] = []
    for anchor in deduplicate_knowledge(anchors):
        single_shapes = {
            (anchor["baseM"], anchor["baseN"]),
        }
        if (
            anchor["singleCoreM"] <= anchor["baseM"]
            and anchor["singleCoreN"] <= anchor["baseN"]
        ):
            single_shapes.add(
                (anchor["singleCoreM"], anchor["singleCoreN"])
            )
        for single_m, single_n in single_shapes:
            candidate = dict(anchor)
            candidate.update(
                {
                    "singleCoreM": single_m,
                    "singleCoreN": single_n,
                    "singleCoreK": workload.k,
                    "usedCoreNum": min(
                        hardware.aic_cores,
                        workload.max_cores,
                        ceil_div(workload.m, single_m)
                        * ceil_div(workload.n, single_n),
                    ),
                    "tilingEnable": 0,
                }
            )
            for scheduled in l2_schedules(
                workload, candidate, seed, hardware
            ):
                for db_a, db_b, db_c in {
                    (
                        scheduled["dbL0A"],
                        scheduled["dbL0B"],
                        scheduled["dbL0C"],
                    ),
                    (1, 1, 1),
                    (2, 2, 1),
                    (2, 2, 2),
                }:
                    variant = dict(scheduled)
                    variant.update(
                        dbL0A=db_a,
                        dbL0B=db_b,
                        dbL0C=db_c,
                    )
                    if hard_legal(workload, variant, hardware):
                        candidates.append(variant)
    return deduplicate_knowledge(candidates)


def skinny_n_large_k_applicable(
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> bool:
    """Select the one CANN 8.1 BASE case covered by the current NPU evidence."""
    core_limit = min(workload.max_cores, hardware.aic_cores)
    balanced_m = align_up(ceil_div(workload.m, core_limit), 16)
    return (
        workload.dtype == "fp16"
        and not workload.trans_a
        and not workload.trans_b
        and template_name(seed.bank.knowledge) == "BASE"
        and 16 < workload.n <= 32
        and workload.k >= 8192
        and workload.k % 64 == 0
        and 128 < balanced_m <= 256
        and ceil_div(workload.m, balanced_m) == core_limit
    )


def official_l1_for_base(
    workload: Workload,
    knowledge: dict[str, int],
    hardware: Hardware,
) -> tuple[int, int, int, int]:
    """Reproduce MatMulV3 CalL1Tiling for a proposed BASE shape."""
    total_l1 = effective_l1_bytes(hardware)
    in_bytes = INPUT_BYTES[workload.dtype]
    base_m = knowledge["baseM"]
    base_n = knowledge["baseN"]
    base_k = knowledge["baseK"]
    depth_a = total_l1 // 2 // base_m // base_k // in_bytes
    depth_b = total_l1 // 2 // base_n // base_k // in_bytes
    size_a = depth_a * base_m * base_k * in_bytes
    size_b = depth_b * base_n * base_k * in_bytes
    if size_a + size_b > total_l1:
        if base_m <= base_n:
            depth_a //= 2
        else:
            depth_b //= 2
    step_ka = max(1, depth_a // 2)
    step_kb = max(1, depth_b // 2)
    if step_ka >= step_kb:
        step_ka = max(step_kb, step_ka // step_kb * step_kb)
    else:
        step_kb = max(step_ka, step_kb // step_ka * step_ka)
    return 2 * step_ka, 2 * step_kb, step_ka, step_kb


def skinny_n_large_k_candidate_space(
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    """Four ablations around the measured 20-core skinny-N winner.

    MatMulV3 caps the normal no-transpose baseM at 128. For one N block, use
    the smallest aligned M block that creates exactly one output block per
    AIC, then isolate the effects of L1 allocation, L0C double buffering, and
    L2 traversal. This is a constrained local extension of the official BASE
    schedule, not a generic raw-MultiCoreMatmulTiling anchor sweep.
    """
    if not skinny_n_large_k_applicable(workload, seed, hardware):
        return []

    core_limit = min(workload.max_cores, hardware.aic_cores)
    base_m = align_up(ceil_div(workload.m, core_limit), 16)
    base_n = align_up(workload.n, 16)
    base_k = 64
    m_blocks = ceil_div(workload.m, base_m)
    n_blocks = ceil_div(workload.n, base_n)
    m_tile_block = min(4, m_blocks)
    n_tile_block = min(max(1, core_limit // 4), n_blocks)

    common = dict(seed.bank.knowledge)
    common.update(
        {
            "usedCoreNum": min(core_limit, m_blocks * n_blocks),
            "singleCoreM": base_m,
            "singleCoreN": base_n,
            "singleCoreK": workload.k,
            "baseM": base_m,
            "baseN": base_n,
            "baseK": base_k,
            "stepM": 1,
            "stepN": 1,
            "iterateOrder": 0,
            "dbL0A": 2,
            "dbL0B": 2,
            "l2MTileCnt": ceil_div(m_blocks, m_tile_block),
            "l2NTileCnt": ceil_div(n_blocks, n_tile_block),
            "l2MTileBlock": m_tile_block,
            "l2NTileBlock": n_tile_block,
            "tilingEnable": 0,
        }
    )

    official_depth_a, official_depth_b, official_step_a, official_step_b = (
        official_l1_for_base(workload, common, hardware)
    )
    balance_only = dict(common)
    balance_only.update(
        {
            "depthA1": official_depth_a,
            "depthB1": official_depth_b,
            "stepKa": official_step_a,
            "stepKb": official_step_b,
            "dbL0C": 1,
            "l2IterateOrder": 0,
        }
    )

    # N occupies one 32-column block. Reallocate L1 depth toward A while
    # retaining a double-buffered four-step B window.
    l1_rebalanced = dict(common)
    l1_rebalanced.update(
        {
            "depthA1": 16,
            "depthB1": 8,
            "stepKa": 8,
            "stepKb": 4,
            "dbL0C": 1,
            "l2IterateOrder": 0,
        }
    )
    l0c_double_buffered = dict(l1_rebalanced)
    l0c_double_buffered["dbL0C"] = 2
    l2_reordered = dict(l0c_double_buffered)
    l2_reordered["l2IterateOrder"] = 1

    return [
        candidate
        for candidate in (
            balance_only,
            l1_rebalanced,
            l0c_double_buffered,
            l2_reordered,
        )
        if hard_legal(workload, candidate, hardware)
    ]


def focused_candidate_guidance(knowledge: dict[str, int]) -> str:
    if knowledge["depthB1"] >= 32:
        return "skinny_n_ablation_core_balance"
    if knowledge["dbL0C"] == 1:
        return "skinny_n_ablation_l1_rebalance"
    if knowledge["l2IterateOrder"] == 0:
        return "skinny_n_ablation_l0c_double_buffer"
    return "skinny_n_ablation_l2_order"


def al1_full_load_applicable(
    workload: Workload,
    hardware: Hardware,
) -> bool:
    if (
        workload.dtype != "fp32"
        or workload.trans_a
        or not workload.trans_b
        or workload.m > 16
        or workload.n <= 16
        or workload.n > 16 * hardware.aic_cores
        or workload.k < 4096
        or workload.k % 128
    ):
        return False
    al1_bytes = align_up(workload.m, 16) * workload.k * 4
    return (
        al1_bytes + 16 * 256 * 4 * 2
        <= effective_l1_bytes(hardware)
    )


def al1_candidate_space(
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    if not al1_full_load_applicable(workload, hardware):
        return []
    candidates: list[dict[str, int]] = []
    seed_k = (
        seed.bank.knowledge
        if template_name(seed.bank.knowledge) == "AL1_FULL_LOAD"
        else None
    )
    if seed_k is not None:
        candidates.append(dict(seed_k))
    base_n_values = {16, 32, 64}
    base_k_values = {64, 128, 256}
    if seed_k is not None:
        base_n_values.add(seed_k["baseN"])
        base_k_values.add(seed_k["baseK"])
    max_parts = min(
        hardware.aic_cores,
        workload.max_cores,
        ceil_div(workload.n, 16),
    )
    for base_n in sorted(base_n_values):
        for base_k in sorted(base_k_values):
            for n_parts in range(1, max_parts + 1):
                single_n = max(
                    base_n,
                    align_up(ceil_div(workload.n, n_parts), 16),
                )
                n_chunks = ceil_div(workload.n, single_n)
                for depth_b in (1, 2):
                    for db_c in (1, 2):
                        step_ka = ceil_div(workload.k, base_k)
                        candidate = {
                            "usedCoreNum": min(
                                hardware.aic_cores,
                                workload.max_cores,
                                n_chunks,
                            ),
                            "singleCoreM": workload.m,
                            "singleCoreN": single_n,
                            "singleCoreK": workload.k,
                            "baseM": 16,
                            "baseN": base_n,
                            "baseK": base_k,
                            "depthA1": step_ka,
                            "depthB1": depth_b,
                            "stepM": 1,
                            "stepN": 1,
                            "iterateOrder": (
                                seed_k["iterateOrder"] if seed_k else 0
                            ),
                            "stepKa": step_ka,
                            "stepKb": 1,
                            "dbL0A": 2,
                            "dbL0B": 2,
                            "dbL0C": db_c,
                            "l2MTileCnt": 1,
                            "l2NTileCnt": 1,
                            "l2MTileBlock": 1,
                            "l2NTileBlock": n_chunks,
                            "l2IterateOrder": 1,
                            "tilingEnable": 10,
                        }
                        if hard_legal(workload, candidate, hardware):
                            candidates.append(candidate)
    return deduplicate_knowledge(candidates)


def bl1_fixpipe_bound(workload: Workload) -> bool:
    output_bytes = OUTPUT_BYTES[workload.dtype]
    align_elements = 32 // output_bytes
    return (
        workload.n < 256
        and workload.n % align_elements != 0
        and align_elements % workload.n != 0
    )


def bl1_full_load_applicable(
    workload: Workload,
    hardware: Hardware,
) -> bool:
    if (
        workload.m <= 16 * max(workload.k, workload.n)
        or workload.k > 256
    ):
        return False
    in_bytes = INPUT_BYTES[workload.dtype]
    c0 = 32 // in_bytes
    resident_b = (
        align_up(workload.k, 16)
        * align_up(workload.n, c0)
        * in_bytes
    )
    return resident_b < effective_l1_bytes(hardware)


def bl1_fix_modes(workload: Workload) -> list[int]:
    if not bl1_fixpipe_bound(workload):
        return [0]
    modes = [1]
    c0 = 32 // INPUT_BYTES[workload.dtype]
    if (
        workload.dtype == "fp32"
        and not workload.trans_a
        and workload.n <= 192
        and workload.k % c0 == 0
    ):
        modes.append(2)
    return modes


def bl1_candidate_space(
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    if not bl1_full_load_applicable(workload, hardware):
        return []
    candidates: list[dict[str, int]] = []
    seed_k = (
        seed.bank.knowledge
        if template_name(seed.bank.knowledge).startswith("BL1_FULL_LOAD")
        else None
    )
    if seed_k is not None:
        candidates.append(dict(seed_k))

    in_bytes = INPUT_BYTES[workload.dtype]
    c0 = 32 // in_bytes
    n_alignment = 16 if workload.trans_b else c0
    base_m_values = {16, 32, 64, 128, 256}
    base_n_values = {
        align_up(workload.n, n_alignment),
        *(
            value
            for value in (16, 32, 64, 128, 192, 256)
            if value >= workload.n
        ),
    }
    base_k_values = {
        align_up(workload.k, base_k_alignment(workload)),
        32,
        64,
        128,
        256,
    }
    if seed_k is not None:
        base_m_values.add(seed_k["baseM"])
        base_n_values.add(seed_k["baseN"])
        base_k_values.add(seed_k["baseK"])

    core_limit = min(hardware.aic_cores, workload.max_cores)
    m_parts_values = {
        1, 2, 4, 5, 10, core_limit,
        2 * core_limit, 4 * core_limit, 8 * core_limit,
    }
    for base_m in sorted(base_m_values):
        for base_n in sorted(base_n_values):
            for base_k in sorted(base_k_values):
                if base_k % base_k_alignment(workload):
                    continue
                step_n = ceil_div(workload.n, base_n)
                step_k = ceil_div(workload.k, base_k)
                single_n = max(workload.n, base_n)
                for m_parts in sorted(m_parts_values):
                    partition_m = align_up(
                        ceil_div(workload.m, max(1, m_parts)), 16
                    )
                    for single_m in {
                        base_m,
                        2 * base_m,
                        4 * base_m,
                        8 * base_m,
                        max(base_m, partition_m),
                    }:
                        m_chunks = ceil_div(workload.m, single_m)
                        n_chunks = ceil_div(workload.n, single_n)
                        for a1_buffers in (1, 2):
                            for fix in bl1_fix_modes(workload):
                                for db_c in (1, 2):
                                    if fix:
                                        l2_m_block = 0
                                        l2_n_block = 0
                                        l2_order = 0
                                    else:
                                        l2_m_block = m_chunks
                                        l2_n_block = n_chunks
                                        l2_order = 1
                                    candidate = {
                                        "usedCoreNum": min(
                                            core_limit,
                                            m_chunks * n_chunks,
                                        ),
                                        "singleCoreM": single_m,
                                        "singleCoreN": single_n,
                                        "singleCoreK": workload.k,
                                        "baseM": base_m,
                                        "baseN": base_n,
                                        "baseK": base_k,
                                        "depthA1": (
                                            a1_buffers * step_k
                                        ),
                                        "depthB1": step_n * step_k,
                                        "stepM": 1,
                                        "stepN": step_n,
                                        "iterateOrder": (
                                            seed_k["iterateOrder"]
                                            if seed_k else 0
                                        ),
                                        "stepKa": step_k,
                                        "stepKb": step_k,
                                        "dbL0A": 2,
                                        "dbL0B": 2,
                                        "dbL0C": db_c,
                                        "l2MTileCnt": 1,
                                        "l2NTileCnt": 1,
                                        "l2MTileBlock": l2_m_block,
                                        "l2NTileBlock": l2_n_block,
                                        "l2IterateOrder": l2_order,
                                        "tilingEnable": 20 + fix * 1000,
                                    }
                                    if hard_legal(
                                        workload, candidate, hardware
                                    ):
                                        candidates.append(candidate)
    return deduplicate_knowledge(candidates)


def single_core_split_k_applicable(
    workload: Workload,
    seed: Seed,
) -> bool:
    return (
        template_name(seed.bank.knowledge) == "SINGLE_CORE_SPLIT_K"
        or (
            workload.k >= 32768
            and workload.m >= 128
            and workload.n >= 128
        )
    )


def single_core_split_k_candidate_space(
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    if not single_core_split_k_applicable(workload, seed):
        return []
    candidates: list[dict[str, int]] = []
    seed_k = (
        seed.bank.knowledge
        if template_name(seed.bank.knowledge) == "SINGLE_CORE_SPLIT_K"
        else None
    )
    if seed_k is not None:
        candidates.append(dict(seed_k))

    base_k = 256 // INPUT_BYTES[workload.dtype]
    algorithms = (
        # name, stepM, stepN, stepK, depthA, depthB, iterate, L2 order
        ("MK33", 3, 1, 3, 9, 6, 1, 0),
        ("NK33", 1, 3, 3, 6, 9, 0, 1),
        ("MK24", 2, 1, 4, 8, 8, 1, 0),
        ("MK14", 1, 1, 4, 8, 8, 1, 0),
    )
    align_m = max(16, 64 // INPUT_BYTES[workload.dtype])
    align_n = max(16, 256 // INPUT_BYTES[workload.dtype])
    pairs = partition_pairs(workload, hardware, max_rounds=4)
    for _, step_m, step_n, step_k, depth_a, depth_b, order, l2_order in algorithms:
        inner_m = step_m * 128
        inner_n = step_n * 128
        single_k = step_k * base_k
        if single_k >= workload.k:
            continue
        for m_parts, n_parts in pairs:
            single_m = max(
                inner_m,
                align_up(ceil_div(workload.m, m_parts), align_m),
            )
            single_n = max(
                inner_n,
                align_up(ceil_div(workload.n, n_parts), align_n),
            )
            m_chunks = ceil_div(workload.m, single_m)
            n_chunks = ceil_div(workload.n, single_n)
            if seed_k is not None:
                l2_m_count = seed_k["l2MTileCnt"]
                l2_n_count = seed_k["l2NTileCnt"]
                l2_m_block = seed_k["l2MTileBlock"]
                l2_n_block = seed_k["l2NTileBlock"]
            else:
                l2_m_count = 1
                l2_n_count = 1
                l2_m_block = max(1, m_chunks)
                l2_n_block = max(1, n_chunks)
            candidate = {
                "usedCoreNum": min(
                    hardware.aic_cores,
                    workload.max_cores,
                    m_chunks * n_chunks,
                ),
                "singleCoreM": single_m,
                "singleCoreN": single_n,
                "singleCoreK": single_k,
                "baseM": 128,
                "baseN": 128,
                "baseK": base_k,
                "depthA1": depth_a,
                "depthB1": depth_b,
                "stepM": step_m,
                "stepN": step_n,
                "iterateOrder": order,
                "stepKa": step_k,
                "stepKb": step_k,
                "dbL0A": 2,
                "dbL0B": 2,
                "dbL0C": 2,
                "l2MTileCnt": l2_m_count,
                "l2NTileCnt": l2_n_count,
                "l2MTileBlock": l2_m_block,
                "l2NTileBlock": l2_n_block,
                "l2IterateOrder": l2_order,
                "tilingEnable": 2,
            }
            if hard_legal(workload, candidate, hardware):
                candidates.append(candidate)
    return deduplicate_knowledge(candidates)


def deterministic_split_k_applicable(
    workload: Workload,
    seed: Seed,
) -> bool:
    return (
        template_name(seed.bank.knowledge) == "DETERMINISTIC_SPLIT_K"
        or (
            workload.m <= 128
            and workload.n <= 128
            and workload.k >= 8192
        )
    )


def deterministic_split_k_candidate_space(
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> list[dict[str, int]]:
    if not deterministic_split_k_applicable(workload, seed):
        return []
    candidates: list[dict[str, int]] = []
    seed_k = (
        seed.bank.knowledge
        if template_name(seed.bank.knowledge) == "DETERMINISTIC_SPLIT_K"
        else None
    )
    if seed_k is not None:
        candidates.append(dict(seed_k))
    base_k = 256 // INPUT_BYTES[workload.dtype]
    single_k = 3 * base_k
    k_chunks = ceil_div(workload.k, single_k)
    core_limit = min(
        hardware.aic_cores, workload.max_cores, k_chunks
    )
    core_values = {
        1, 2, 4, 5, 8, 10, 16, core_limit,
        max(1, core_limit - 1),
    }
    layouts = (
        (3, 1, 9, 6, 1, 384, max(128, workload.n), 0),
        (1, 3, 6, 9, 0, max(128, workload.m), 384, 1),
    )
    for step_m, step_n, depth_a, depth_b, order, single_m, single_n, l2_order in layouts:
        for cores in sorted(value for value in core_values if value <= core_limit):
            if seed_k is not None:
                l2_m_count = seed_k["l2MTileCnt"]
                l2_n_count = seed_k["l2NTileCnt"]
                l2_m_block = seed_k["l2MTileBlock"]
                l2_n_block = seed_k["l2NTileBlock"]
            else:
                l2_m_count = 1
                l2_n_count = 1
                l2_m_block = max(1, ceil_div(workload.m, single_m))
                l2_n_block = max(1, ceil_div(workload.n, single_n))
            candidate = {
                "usedCoreNum": cores,
                "singleCoreM": single_m,
                "singleCoreN": single_n,
                "singleCoreK": single_k,
                "baseM": 128,
                "baseN": 128,
                "baseK": base_k,
                "depthA1": depth_a,
                "depthB1": depth_b,
                "stepM": step_m,
                "stepN": step_n,
                "iterateOrder": order,
                "stepKa": 3,
                "stepKb": 3,
                "dbL0A": 2,
                "dbL0B": 2,
                "dbL0C": 2,
                "l2MTileCnt": l2_m_count,
                "l2NTileCnt": l2_n_count,
                "l2MTileBlock": l2_m_block,
                "l2NTileBlock": l2_n_block,
                "l2IterateOrder": l2_order,
                "tilingEnable": 3,
            }
            if hard_legal(workload, candidate, hardware):
                candidates.append(candidate)
    return deduplicate_knowledge(candidates)


def all_template_candidate_spaces(
    workload: Workload,
    seed: Seed,
    raw_rows: list[dict[str, str]],
    hardware: Hardware,
    beam_width: int,
    optimization_scope: str,
) -> dict[str, list[dict[str, int]]]:
    if optimization_scope == "skinny_n_large_k_v1":
        focused = skinny_n_large_k_candidate_space(
            workload, seed, hardware
        )
        return {"BASE": focused} if focused else {}

    spaces = {
        "BASE": base_candidate_space(
            workload, seed, raw_rows, hardware, beam_width
        ),
        "SINGLE_CORE_SPLIT_K": single_core_split_k_candidate_space(
            workload, seed, hardware
        ),
        "DETERMINISTIC_SPLIT_K": deterministic_split_k_candidate_space(
            workload, seed, hardware
        ),
        "AL1_FULL_LOAD": al1_candidate_space(
            workload, seed, hardware
        ),
    }
    for candidate in bl1_candidate_space(workload, seed, hardware):
        spaces.setdefault(template_name(candidate), []).append(candidate)
    return {
        template: deduplicate_knowledge(candidates)
        for template, candidates in spaces.items()
        if candidates
    }


def chunk_ceil_sum(total: int, chunk: int, unit: int) -> int:
    count = ceil_div(total, chunk)
    tail = total - (count - 1) * chunk
    return (count - 1) * ceil_div(chunk, unit) + ceil_div(tail, unit)


def chunk_aligned_sum(total: int, chunk: int, alignment: int) -> int:
    return chunk_ceil_sum(total, chunk, alignment) * alignment


def fixpipe_row_sum(
    total: int,
    single: int,
    base: int,
    out_bytes: int,
) -> int:
    def extent_bytes(extent: int) -> int:
        subtiles = ceil_div(extent, base)
        tail = extent - (subtiles - 1) * base
        return (
            (subtiles - 1) * align_up(base * out_bytes, 512)
            + align_up(tail * out_bytes, 512)
        )

    count = ceil_div(total, single)
    tail = total - (count - 1) * single
    return (count - 1) * extent_bytes(single) + extent_bytes(tail)


def analytical_score(
    workload: Workload,
    knowledge: dict[str, int],
    hardware: Hardware,
    callback: CallbackTiling | None = None,
) -> ModelEstimate:
    """Estimate the critical-core MatMulV3 pipeline, not wall-clock time.

    The objective follows the structure used by NPUMeter: model the execution
    sequence of every logical tile, overlap MTE2/MTE1/Cube/FixPipe according to
    buffer depth, and take the slowest core. L2/HBM traffic and ND->NZ vector
    conversion are then added at their shared-resource rates. Absolute cycles
    are intentionally not converted to milliseconds; only ratios between
    candidates of the same workload are used for search.
    """
    in_bytes = INPUT_BYTES[workload.dtype]
    out_bytes = OUTPUT_BYTES[workload.dtype]
    cores = max(1, knowledge["usedCoreNum"])
    base_m = knowledge["baseM"]
    base_n = knowledge["baseN"]
    base_k = knowledge["baseK"]
    single_m = knowledge["singleCoreM"]
    single_n = knowledge["singleCoreN"]
    single_k = knowledge["singleCoreK"]
    native_k = cube_k0(workload.dtype)
    split = split_mode(knowledge)
    full = full_load_mode(knowledge)
    fix = fix_mode(knowledge)

    m_output = ceil_div(workload.m, single_m)
    n_output = ceil_div(workload.n, single_n)
    k_passes = (
        ceil_div(workload.k, single_k)
        if split in (2, 3)
        else 1
    )
    logical_tiles = (
        m_output * n_output * k_passes
        if split == 3
        else m_output * n_output
    )

    # Closed-form axis sums avoid materializing millions of tile coordinates
    # for large shapes. They retain full/tail padding, transaction counts and
    # the number of whole AIC scheduling rounds.
    m_align_sum = chunk_aligned_sum(workload.m, single_m, 16)
    n_align_sum = chunk_aligned_sum(workload.n, single_n, 16)
    k_align_sum = chunk_aligned_sum(workload.k, single_k, native_k)
    m_cube_units = chunk_ceil_sum(workload.m, single_m, 16)
    n_cube_units = chunk_ceil_sum(workload.n, single_n, 16)
    k_cube_units = chunk_ceil_sum(workload.k, single_k, native_k)
    m_subtiles = chunk_ceil_sum(workload.m, single_m, base_m)
    n_subtiles = chunk_ceil_sum(workload.n, single_n, base_n)
    k_subtiles = chunk_ceil_sum(workload.k, single_k, base_k)

    total_cube = float(
        m_cube_units * n_cube_units * k_cube_units
        + 12 * m_subtiles * n_subtiles * k_passes
    )

    # stepM/stepN are the L1 reuse window. Count L2->L1 transfers by the
    # number of such windows, not merely by output-core tiles. This is
    # This also covers specialized families where singleCoreM/N can span
    # multiple base tiles.
    m_l1_groups = chunk_ceil_sum(
        workload.m, single_m, base_m * knowledge["stepM"]
    )
    n_l1_groups = chunk_ceil_sum(
        workload.n, single_n, base_n * knowledge["stepN"]
    )
    l2_a_bytes = float(
        m_align_sum * k_align_sum * n_l1_groups * in_bytes
    )
    l2_b_bytes = float(
        n_align_sum * k_align_sum * m_l1_groups * in_bytes
    )
    l2_c_bytes = float(workload.m * workload.n * out_bytes)

    a_k_packets = chunk_ceil_sum(
        workload.k,
        single_k,
        base_k * knowledge["stepKa"],
    )
    b_k_packets = chunk_ceil_sum(
        workload.k,
        single_k,
        base_k * knowledge["stepKb"],
    )
    total_a_packets = m_subtiles * n_l1_groups * a_k_packets
    total_b_packets = n_subtiles * m_l1_groups * b_k_packets

    # The full-load kernels copy one complete operand into each active AIC's
    # L1 before processing all rounds assigned to that core.
    output_tasks = m_output * n_output
    output_active_cores = max(1, min(cores, output_tasks))
    aligned_a_bytes = (
        align_up(workload.m, 16)
        * align_up(workload.k, native_k)
        * in_bytes
    )
    aligned_b_bytes = (
        align_up(workload.k, native_k)
        * align_up(workload.n, max(16, 32 // in_bytes))
        * in_bytes
    )
    if full == 1:
        l2_a_bytes = float(aligned_a_bytes * output_active_cores)
        l2_b_bytes = float(
            n_align_sum * k_align_sum * m_l1_groups * in_bytes
        )
        total_a_packets = output_active_cores
    elif full == 2:
        l2_a_bytes = float(
            m_align_sum * k_align_sum * n_l1_groups * in_bytes
        )
        l2_b_bytes = float(aligned_b_bytes * output_active_cores)
        total_b_packets = output_active_cores

    total_mte2 = (
        (l2_a_bytes + l2_b_bytes)
        / max(1.0, hardware.l2_bytes_per_cycle_per_core)
        + 12.0 * (total_a_packets + total_b_packets)
    )

    mte1_tiles = m_subtiles * n_subtiles * k_subtiles
    total_mte1 = (
        mte1_tiles
        * (base_m * base_k + base_n * base_k)
        * in_bytes
        / 128.0
        + 4.0 * mte1_tiles
    )
    total_fixpipe = (
        m_align_sum
        * fixpipe_row_sum(
            workload.n, single_n, base_n, out_bytes
        )
        / 64.0
        + 4.0 * m_subtiles * n_subtiles
    )
    fix_workspace = 0
    if full == 2 and fix:
        nz_c_bytes = (
            align_up(workload.m, 16)
            * align_up(workload.n, max(16, 256 // out_bytes))
            * out_bytes
        )
        fix_workspace = 2 * nz_c_bytes
        if fix == 2:
            fix_workspace += aligned_a_bytes
        total_fixpipe += fix_workspace / max(
            1.0, 128.0 * 2.0 * output_active_cores
        )
    total_issue = float(
        2 * mte1_tiles + total_a_packets + total_b_packets
    )

    active_cores = max(1, min(cores, logical_tiles))
    round_balance = (
        ceil_div(logical_tiles, active_cores)
        / max(1.0, logical_tiles / active_cores)
    )

    def critical(total: float) -> float:
        return total / active_cores * round_balance

    critical_cube = critical(total_cube)
    critical_mte2 = critical(total_mte2)
    critical_mte1 = critical(total_mte1)
    critical_fixpipe = critical(total_fixpipe)
    issue_cycles = critical(total_issue)
    input_stage = max(critical_mte2, critical_mte1)
    if knowledge["dbL0A"] == 2 and knowledge["dbL0B"] == 2:
        critical_pipeline = max(critical_cube, input_stage)
        critical_pipeline += 0.08 * min(critical_cube, input_stage)
    else:
        critical_pipeline = critical_cube + input_stage
    if knowledge["dbL0C"] == 2:
        critical_pipeline = max(critical_pipeline, critical_fixpipe)
    else:
        critical_pipeline += critical_fixpipe

    hbm_a = workload.m * workload.k * in_bytes
    hbm_b = workload.k * workload.n * in_bytes
    if full == 0:
        hbm_a *= knowledge["l2NTileCnt"]
        hbm_b *= knowledge["l2MTileCnt"]
    hbm_c = workload.m * workload.n * out_bytes
    hbm_bytes = float(hbm_a + hbm_b + hbm_c)

    l2_bytes = float(l2_a_bytes + l2_b_bytes + l2_c_bytes)

    if split == 2:
        # Each output-owning AIC executes K slices sequentially. The first
        # slice writes FP32 and the following IterateAll calls atomically
        # accumulate into the same workspace; AIV then casts once to C.
        workspace_one = (
            align_up(workload.m, 16)
            * align_up(workload.n, max(16, 256 // out_bytes))
            * 4
        )
        workspace_traffic = workspace_one * max(1, 2 * k_passes - 1)
        cast_traffic = workspace_one + workload.m * workload.n * out_bytes
        hbm_bytes += workspace_one
        l2_bytes += workspace_traffic + cast_traffic
        issue_cycles += (
            (k_passes - 1) * m_output * n_output * 12.0
            + workload.m * workload.n / 64.0
        ) / output_active_cores
    elif split == 3:
        # Deterministic Split-K writes one FP32 partial per active K core and
        # reduces those partials in UB before the final cast/store.
        split_active = max(1, min(cores, k_passes))
        workspace_one = (
            align_up(workload.m, 16)
            * align_up(workload.n, 16)
            * 4
        )
        workspace_bytes = workspace_one * split_active
        reduction_bytes = (
            workspace_bytes
            + workspace_one
            + workload.m * workload.n * out_bytes
        )
        hbm_bytes += workspace_bytes
        l2_bytes += reduction_bytes
        issue_cycles += (
            split_active * 32.0
            + workload.m * workload.n * split_active / 64.0
        ) / cores

    if full == 2 and fix:
        # Optimized Fixpipe first writes NZ output to workspace, then the AIV
        # path converts/copies it to the user ND tensor. Vec NZ2ND also stages
        # A in workspace before Cube consumes it.
        hbm_bytes += fix_workspace
        l2_bytes += 2 * fix_workspace
        issue_cycles += output_tasks * (24.0 if fix == 2 else 16.0) / cores

    hbm_cycles = hbm_bytes / max(
        1.0, hardware.hbm_bytes_per_cycle_per_core * active_cores
    )
    l2_cycles = l2_bytes / max(
        1.0, hardware.l2_bytes_per_cycle_per_core * active_cores
    )

    m_extent = min(
        workload.m,
        max(1, knowledge["l2MTileBlock"]) * single_m,
    )
    n_extent = min(
        workload.n,
        max(1, knowledge["l2NTileBlock"]) * single_n,
    )
    working_set = (
        m_extent * workload.k * in_bytes
        + workload.k * n_extent * in_bytes
        + m_extent * n_extent * out_bytes
    )
    safe_l2 = hardware.l2_bytes * (100.0 / 192.0)
    capacity_penalty = max(0.0, working_set / max(1.0, safe_l2) - 1.0)
    m_tail = (
        m_output
        - (knowledge["l2MTileCnt"] - 1)
        * max(1, knowledge["l2MTileBlock"])
    )
    n_tail = (
        n_output
        - (knowledge["l2NTileCnt"] - 1)
        * max(1, knowledge["l2NTileBlock"])
    )
    tail_parallelism = max(
        1,
        min(cores, max(1, m_tail) * max(1, n_tail)),
    )
    tail_smear = 1.0 + 0.20 * (1.0 - tail_parallelism / cores)
    l2_shared_cycles = (hbm_cycles + l2_cycles) * tail_smear
    l2_shared_cycles *= 1.0 + 2.0 * capacity_penalty

    nd2nz_cycles = 0.0
    confidence = "medium"
    if callback is not None and all(
        name in callback.derived
        for name in ("baseAN", "baseAD", "baseBN", "baseBD")
    ):
        # Zero means that the corresponding ND->NZ conversion side/axis does
        # not require an explicit split. The field names use logical MatMul
        # axes (A: M,K and B: N,K), independent of physical transpose.
        base_an = callback.derived["baseAN"] or workload.m
        base_ad = callback.derived["baseAD"] or workload.k
        base_bn = callback.derived["baseBN"] or workload.n
        base_bd = callback.derived["baseBD"] or workload.k
        convert_a = bool(
            callback.derived["baseAN"] or callback.derived["baseAD"]
        )
        convert_b = bool(
            callback.derived["baseBN"] or callback.derived["baseBD"]
        )
        a_vector_tiles = (
            ceil_div(workload.m, base_an)
            * ceil_div(workload.k, base_ad)
            if convert_a
            else 0
        )
        b_vector_tiles = (
            ceil_div(workload.n, base_bn)
            * ceil_div(workload.k, base_bd)
            if convert_b
            else 0
        )
        vector_cores = max(1, 2 * cores)
        nd2nz_bytes = (
            (workload.m * workload.k if convert_a else 0)
            + (workload.k * workload.n if convert_b else 0)
        ) * in_bytes
        nd2nz_cycles = (
            nd2nz_bytes / (128.0 * vector_cores)
            + 6.0 * (a_vector_tiles + b_vector_tiles) / vector_cores
        )
        confidence = "high"

    balance = round_balance * cores / active_cores
    score = (
        max(critical_pipeline, l2_shared_cycles)
        + nd2nz_cycles
        + issue_cycles
    )
    return ModelEstimate(
        cycles=score,
        hbm_bytes=hbm_bytes,
        l2_bytes=l2_bytes,
        cube_cycles=critical_cube,
        mte2_cycles=max(critical_mte2, l2_shared_cycles),
        mte1_cycles=critical_mte1,
        fixpipe_cycles=critical_fixpipe,
        nd2nz_cycles=nd2nz_cycles,
        issue_cycles=issue_cycles,
        balance=balance,
        confidence=confidence,
    )


def knowledge_signature(knowledge: dict[str, int]) -> tuple[int, ...]:
    return tuple(knowledge[field] for field in KNOWLEDGE_FIELDS)


def dominated_by_bank_seed(
    knowledge: dict[str, int],
    seed: Seed,
) -> bool:
    if knowledge["usedCoreNum"] >= seed.bank.knowledge["usedCoreNum"]:
        return False
    return all(
        knowledge[field] == seed.bank.knowledge[field]
        for field in KNOWLEDGE_FIELDS
        if field != "usedCoreNum"
    )


def row_from_state(
    fields: list[str],
    prototype: dict[str, str] | None,
    workload: Workload,
    knowledge: dict[str, int],
    source: str,
    template: str,
    score: float,
    hbm_bytes: float,
    l2_bytes: float,
    seed_key: int,
    guidance: str = "analytical_beam",
    candidate_role: str = "searched",
    estimate: ModelEstimate | None = None,
) -> dict[str, str]:
    row = {field: "" for field in fields}
    if prototype:
        row.update(prototype)
    row.update(
        {
            "workload_id": workload.workload_id,
            "m": str(workload.m),
            "n": str(workload.n),
            "k": str(workload.k),
            "dtype": workload.dtype,
            "trans_a": str(int(workload.trans_a)),
            "trans_b": str(int(workload.trans_b)),
            "max_cores": str(workload.max_cores),
            "source": source,
            "candidate_role": candidate_role,
            "source_iteration": "0",
            "valid": "1",
            "error": "",
            "execution_mode": (
                "deterministic_split_k"
                if split_mode(knowledge) == 3
                else "single_core_split_k"
                if split_mode(knowledge) == 2
                else "al1_full_load"
                if full_load_mode(knowledge) == 1
                else "bl1_full_load_fixpipe"
                if full_load_mode(knowledge) == 2
                and fix_mode(knowledge) == 1
                else "bl1_full_load_vec_nz2nd"
                if full_load_mode(knowledge) == 2
                and fix_mode(knowledge) == 2
                else "bl1_full_load"
                if full_load_mode(knowledge) == 2
                else "base_iterate_all"
            ),
            "candidate_single_core_m": str(knowledge["singleCoreM"]),
            "candidate_single_core_n": str(knowledge["singleCoreN"]),
            "candidate_single_core_k": str(knowledge["singleCoreK"]),
            "candidate_base_m": str(knowledge["baseM"]),
            "candidate_base_n": str(knowledge["baseN"]),
            "candidate_base_k": str(knowledge["baseK"]),
            "candidate_traverse": str(knowledge["iterateOrder"]),
            "candidate_db_a": str(int(knowledge["dbL0A"] == 2)),
            "candidate_db_b": str(int(knowledge["dbL0B"] == 2)),
            "candidate_split_k": str(int(split_mode(knowledge) != 0)),
            "used_core_num": str(knowledge["usedCoreNum"]),
            "official_core_num": str(knowledge["usedCoreNum"]),
            "official_m_dim": str(ceil_div(workload.m, knowledge["singleCoreM"])),
            "official_n_dim": str(ceil_div(workload.n, knowledge["singleCoreN"])),
            "m_core_parts": str(ceil_div(workload.m, knowledge["singleCoreM"])),
            "n_core_parts": str(ceil_div(workload.n, knowledge["singleCoreN"])),
            "k_core_parts": str(ceil_div(workload.k, knowledge["singleCoreK"])),
            "single_core_m": str(knowledge["singleCoreM"]),
            "single_core_n": str(knowledge["singleCoreN"]),
            "single_core_k": str(knowledge["singleCoreK"]),
            "base_m": str(knowledge["baseM"]),
            "base_n": str(knowledge["baseN"]),
            "base_k": str(knowledge["baseK"]),
            "depth_a1": str(knowledge["depthA1"]),
            "depth_b1": str(knowledge["depthB1"]),
            "step_m": str(knowledge["stepM"]),
            "step_n": str(knowledge["stepN"]),
            "step_ka": str(knowledge["stepKa"]),
            "step_kb": str(knowledge["stepKb"]),
            "iterate_order": str(knowledge["iterateOrder"]),
            "db_l0a": str(knowledge["dbL0A"]),
            "db_l0b": str(knowledge["dbL0B"]),
            "db_l0c": str(knowledge["dbL0C"]),
            "official_return": "0",
            "tiling_signature": ":".join(map(str, knowledge_signature(knowledge))),
            "tiling_bin": "",
            "search_template": template,
            "search_guidance": guidance,
            "search_model_score": f"{score:.12g}",
            "search_model_cycles": (
                f"{estimate.cycles:.12g}" if estimate else ""
            ),
            "search_model_raw_ratio_vs_bank_seed": f"{score:.12g}",
            "search_model_ratio_vs_bank_seed": f"{score:.12g}",
            "search_model_calibration": "1",
            "search_model_confidence": estimate.confidence if estimate else "",
            "search_model_breakdown": estimate.breakdown() if estimate else "",
            "search_hbm_bytes": f"{hbm_bytes:.12g}",
            "search_l2_bytes": f"{l2_bytes:.12g}",
            "search_seed_key": str(seed_key),
            "search_history_match": "",
        }
    )
    for knowledge_name, column in BANK_COLUMNS.items():
        row[column] = str(knowledge[knowledge_name])
    return row


def update_callback_columns(
    state: State,
    callback: CallbackTiling,
    seed: Seed,
    bank_seed_estimate: ModelEstimate,
    hardware: Hardware,
    workload: Workload,
) -> None:
    estimate = analytical_score(
        workload, state.knowledge, hardware, callback
    )
    ratio = estimate.cycles / max(1.0, bank_seed_estimate.cycles)
    state.callback = callback
    state.estimate = estimate
    state.model_score = estimate.cycles
    state.normalized_score = ratio
    state.hbm_bytes = estimate.hbm_bytes
    state.l2_bytes = estimate.l2_bytes
    state.row.update(
        {
            "search_model_score": f"{ratio:.12g}",
            "search_model_cycles": f"{estimate.cycles:.12g}",
            "search_model_raw_ratio_vs_bank_seed": f"{ratio:.12g}",
            "search_model_ratio_vs_bank_seed": f"{ratio:.12g}",
            "search_model_calibration": "1",
            "search_model_confidence": estimate.confidence,
            "search_model_breakdown": estimate.breakdown(),
            "search_hbm_bytes": f"{estimate.hbm_bytes:.12g}",
            "search_l2_bytes": f"{estimate.l2_bytes:.12g}",
            "callback_tiling_sha256": callback.sha256,
            "callback_tiling_bytes": str(len(callback.blob)),
            "callback_tiling_key": str(callback.key),
            "callback_block_dim": str(callback.block_dim),
            "callback_workspace_bytes": str(sum(callback.workspaces)),
            "callback_l2_cache_flag": str(
                callback.derived.get("l2CacheFlag", "")
            ),
            "callback_base_an": str(callback.derived.get("baseAN", "")),
            "callback_base_ad": str(callback.derived.get("baseAD", "")),
            "callback_base_bn": str(callback.derived.get("baseBN", "")),
            "callback_base_bd": str(callback.derived.get("baseBD", "")),
            "callback_kernel_suffix": str(kernel_suffix(callback.key)),
            "callback_kernel_variant": kernel_variant(callback.key),
            "callback_kernel_family": kernel_family(callback.key),
            "callback_derived_diff_vs_default": callback_derived_diff(
                seed.default, callback
            ),
            "callback_derived_diff_vs_bank_seed": callback_derived_diff(
                seed.bank, callback
            ),
        }
    )


def validate_callback(
    workload: Workload,
    state: State,
) -> CallbackTiling:
    callback = invoke_official_callback(workload, state.knowledge)
    observed_family = kernel_family(callback.key)
    if observed_family != state.template:
        raise SearchError(
            "official callback selected a different kernel family: "
            f"{observed_family} expected={state.template} "
            f"suffix={kernel_suffix(callback.key)}"
        )
    observed = callback.knowledge
    mismatches = [
        f"{field}={observed[field]} expected={state.knowledge[field]}"
        for field in KNOWLEDGE_FIELDS
        if observed[field] != state.knowledge[field]
    ]
    if mismatches:
        raise SearchError("official callback changed candidate: " + "; ".join(mismatches))
    return callback


BEAM_LAYERS = (
    (
        "tilingEnable", "usedCoreNum", "singleCoreM",
        "singleCoreN", "singleCoreK",
    ),
    ("baseM", "baseN", "baseK"),
    (
        "stepM", "stepN", "stepKa", "stepKb",
        "depthA1", "depthB1", "iterateOrder",
    ),
    ("dbL0A", "dbL0B", "dbL0C"),
    (
        "l2MTileCnt", "l2NTileCnt", "l2MTileBlock",
        "l2NTileBlock", "l2IterateOrder",
    ),
)

NEIGHBOR_GROUPS = (
    (
        "usedCoreNum", "singleCoreM", "singleCoreN", "singleCoreK",
    ),
    (
        "baseM", "baseN", "baseK", "stepM", "stepN",
        "stepKa", "stepKb", "depthA1", "depthB1",
        "dbL0A", "dbL0B", "dbL0C",
    ),
    ("iterateOrder",),
    (
        "l2MTileCnt", "l2NTileCnt", "l2MTileBlock",
        "l2NTileBlock", "l2IterateOrder",
    ),
)


def state_sort_key(state: State) -> tuple[float, tuple[int, ...]]:
    return (
        state.normalized_score,
        knowledge_signature(state.knowledge),
    )


def prefix_signature(
    state: State,
    fields: tuple[str, ...],
) -> tuple[int, ...]:
    return tuple(state.knowledge[field] for field in fields)


def constraint_aware_beam(
    states: list[State],
    width: int,
) -> list[State]:
    """Beam-search legal completions of the coupled MatMulV3 contract.

    Every prefix is represented only by candidates that already satisfy the
    complete kernel-template contract. The minimum analytical score among its
    legal completions is therefore an admissible completion bound for pruning;
    no repair or floating-point rounding can create an invalid tiling.
    """
    if not states:
        return []
    active = list(states)
    prefix_fields: tuple[str, ...] = ()
    for layer_index, layer in enumerate(BEAM_LAYERS, 1):
        prefix_fields += layer
        best_completion: dict[tuple[int, ...], State] = {}
        for state in active:
            prefix = prefix_signature(state, prefix_fields)
            previous = best_completion.get(prefix)
            if previous is None or state_sort_key(state) < state_sort_key(previous):
                best_completion[prefix] = state
        retained_prefixes = {
            prefix
            for prefix, _ in sorted(
                best_completion.items(),
                key=lambda item: state_sort_key(item[1]),
            )[:width]
        }
        active = [
            state
            for state in active
            if prefix_signature(state, prefix_fields) in retained_prefixes
        ]
        if not active:
            break
        for state in active:
            if not state.row.get("search_guidance", "").startswith(
                "skinny_n_ablation_"
            ):
                state.guidance = f"constraint_beam_layer_{layer_index}"
                state.row["search_guidance"] = state.guidance
    return sorted(active, key=state_sort_key)[:width]


def semantic_signature(
    state: State,
) -> tuple[tuple[int, ...], ...]:
    return tuple(
        prefix_signature(state, fields)
        for fields in NEIGHBOR_GROUPS
    )


def semantic_distance(left: State, right: State) -> int:
    return sum(
        left_group != right_group
        for left_group, right_group in zip(
            semantic_signature(left), semantic_signature(right)
        )
    )


def tabu_lns_search(
    pool: list[State],
    beam: list[State],
    tabu_iterations: int,
    lns_rounds: int,
    limit: int,
) -> list[State]:
    """Improve/diversify a legal beam with discrete Tabu and LNS moves."""
    if not beam:
        return []
    ordered_pool = sorted(pool, key=state_sort_key)
    seed_count = min(4, len(beam))
    iterations_per_seed = max(
        1, ceil_div(max(0, tabu_iterations), seed_count)
    )
    lns_period = max(
        1, ceil_div(iterations_per_seed, max(1, lns_rounds))
    )
    discovered: list[State] = []
    discovered_signatures: set[tuple[int, ...]] = set()

    def remember(state: State, guidance: str) -> None:
        signature = knowledge_signature(state.knowledge)
        if signature in discovered_signatures:
            return
        discovered_signatures.add(signature)
        if not state.row.get("search_guidance", "").startswith(
            "skinny_n_ablation_"
        ):
            state.guidance = guidance
            state.row["search_guidance"] = guidance
        discovered.append(state)

    for seed_index, start in enumerate(beam[:seed_count]):
        current = start
        best = start
        tabu_queue: list[tuple[int, ...]] = []
        tabu: set[tuple[int, ...]] = set()

        def mark_tabu(state: State) -> None:
            signature = knowledge_signature(state.knowledge)
            if signature in tabu:
                return
            tabu.add(signature)
            tabu_queue.append(signature)
            if len(tabu_queue) > 32:
                tabu.discard(tabu_queue.pop(0))

        mark_tabu(current)
        for iteration in range(iterations_per_seed):
            use_lns = lns_rounds > 0 and iteration % lns_period == 0
            current_groups = semantic_signature(current)
            if use_lns:
                first = (iteration // lns_period + seed_index) % len(
                    NEIGHBOR_GROUPS
                )
                relaxed = {first}
                if (iteration // lns_period) % 2:
                    relaxed.add((first + 1) % len(NEIGHBOR_GROUPS))
                neighborhood = [
                    candidate
                    for candidate in ordered_pool
                    if all(
                        index in relaxed
                        or candidate_group == current_groups[index]
                        for index, candidate_group in enumerate(
                            semantic_signature(candidate)
                        )
                    )
                ]
                guidance = "lns_relax_" + "_".join(
                    str(index) for index in sorted(relaxed)
                )
            else:
                neighborhood = [
                    candidate
                    for candidate in ordered_pool
                    if semantic_distance(current, candidate) == 1
                ]
                guidance = "tabu_neighbor"
            if not neighborhood:
                neighborhood = [
                    candidate
                    for candidate in ordered_pool
                    if semantic_distance(current, candidate) <= 2
                ]
            next_state = None
            for candidate in neighborhood:
                signature = knowledge_signature(candidate.knowledge)
                aspiration = state_sort_key(candidate) < state_sort_key(best)
                if signature not in tabu or aspiration:
                    next_state = candidate
                    break
            if next_state is None:
                break
            current = next_state
            if state_sort_key(current) < state_sort_key(best):
                best = current
            mark_tabu(current)
            remember(current, guidance)

    # Preserve the model leaders, then add legal neighborhood alternatives
    # that exercise different coupled parameter groups.
    result: list[State] = []
    seen: set[tuple[int, ...]] = set()
    leader_count = min(len(beam), max(1, limit // 2))
    for state in [
        *beam[:leader_count],
        *discovered,
        *beam[leader_count:],
    ]:
        signature = knowledge_signature(state.knowledge)
        if signature in seen:
            continue
        seen.add(signature)
        result.append(state)
        if len(result) >= limit:
            break
    return result


def bank_seed_control(
    fields: list[str],
    workload: Workload,
    seed: Seed,
    hardware: Hardware,
) -> State:
    estimate = analytical_score(
        workload, seed.bank.knowledge, hardware, seed.bank
    )
    row = row_from_state(
        fields,
        None,
        workload,
        dict(seed.bank.knowledge),
        "official_seed_bank_roundtrip",
        template_name(seed.bank.knowledge),
        1.0,
        estimate.hbm_bytes,
        estimate.l2_bytes,
        seed.key,
        guidance="bank_path_control",
        candidate_role="bank_seed_control",
        estimate=estimate,
    )
    state = State(
        row=row,
        knowledge=dict(seed.bank.knowledge),
        model_score=estimate.cycles,
        normalized_score=1.0,
        hbm_bytes=estimate.hbm_bytes,
        l2_bytes=estimate.l2_bytes,
        template=template_name(seed.bank.knowledge),
        guidance="bank_path_control",
        callback=seed.bank,
        estimate=estimate,
    )
    update_callback_columns(
        state, seed.bank, seed, estimate, hardware, workload
    )
    state.row["search_model_ratio_vs_bank_seed"] = "1"
    state.row["search_model_score"] = "1"
    state.row["rank"] = "0"
    return state


def state_history_key(
    workload: Workload,
    knowledge: dict[str, int],
) -> tuple[str, ...]:
    m_blocks = ceil_div(workload.m, knowledge["singleCoreM"])
    n_blocks = ceil_div(workload.n, knowledge["singleCoreN"])
    return (
        workload.workload_id,
        f"{workload.m}x{workload.n}x{workload.k}",
        workload.dtype,
        template_name(knowledge),
        f"{knowledge['baseM']}x{knowledge['baseN']}x{knowledge['baseK']}",
        (
            f"{knowledge['singleCoreM']}x{knowledge['singleCoreN']}x"
            f"{knowledge['singleCoreK']}"
        ),
        str(knowledge["usedCoreNum"]),
        f"{m_blocks}x{n_blocks}",
        (
            f"{knowledge['l2MTileCnt']}x{knowledge['l2NTileCnt']}"
            f"({knowledge['l2MTileBlock']}x{knowledge['l2NTileBlock']})"
        ),
        str(knowledge["iterateOrder"]),
        f"{knowledge['depthA1']}x{knowledge['depthB1']}",
        f"{knowledge['dbL0A']}x{knowledge['dbL0B']}x{knowledge['dbL0C']}",
        str(knowledge["l2IterateOrder"]),
        str(int(workload.trans_a)),
        str(int(workload.trans_b)),
    )


def load_measurement_history(
    path: Path | None,
    soc: str,
    aic_cores: int,
) -> dict[tuple[str, ...], list[tuple[float, str]]]:
    if path is None or not path.is_file():
        return {}
    _, rows = read_csv(path)
    history: dict[tuple[str, ...], list[tuple[float, str]]] = {}
    for row in rows:
        if (
            row.get("record_type") != "candidate"
            or not truthy(row.get("ocr_complete"))
            or row.get("preflight_contract") != "grid9_v1"
            or row.get("soc") != soc
            or int(row.get("aic") or 0) != aic_cores
        ):
            continue
        try:
            speedup = float(row.get("speedup_vs_official") or 0)
        except ValueError:
            continue
        if speedup <= 0:
            continue
        key = (
            row.get("workload_id", ""),
            row.get("shape", ""),
            row.get("dtype", "").lower(),
            row.get("template", ""),
            row.get("T", ""),
            row.get("S", ""),
            row.get("C", ""),
            row.get("G", ""),
            row.get("L2", ""),
            row.get("I", ""),
            row.get("L1", ""),
            row.get("DB", ""),
            row.get("L2O", ""),
            row.get("trans_a", ""),
            row.get("trans_b", ""),
        )
        history.setdefault(key, []).append(
            (1.0 / speedup, row.get("record_key", ""))
        )
    return history


def calibrate_from_history(
    workload: Workload,
    states: list[State],
    history: dict[tuple[str, ...], list[tuple[float, str]]],
    bank_path_diff: str,
) -> tuple[float, int]:
    # Historical measurements use the no-bank official operator as reference.
    # They cannot calibrate a workload where the bank path changes ND->NZ
    # fields until its new bank_seed_control has been measured.
    if bank_path_diff:
        return 1.0, 0

    exact: dict[tuple[str, ...], tuple[float, str]] = {}
    correction_by_key: dict[tuple[str, ...], float] = {}
    for state in states:
        key = state_history_key(workload, state.knowledge)
        records = history.get(key)
        if not records:
            continue
        actual_ratio = statistics.median(
            ratio for ratio, _ in records
        )
        record_ids = "|".join(
            sorted({record_id for _, record_id in records if record_id})
        )
        exact[key] = (actual_ratio, record_ids)
        correction_by_key[key] = (
            actual_ratio / max(1.0e-12, state.normalized_score)
        )

    correction = 1.0
    if len(correction_by_key) >= 2:
        correction = statistics.median(correction_by_key.values())
        # Residual calibration corrects local model bias; larger shifts require
        # a new bank control and are not extrapolated to unseen tilings.
        correction = min(1.15, max(0.85, correction))

    for state in states:
        key = state_history_key(workload, state.knowledge)
        raw_ratio = state.normalized_score
        if key in exact:
            adjusted, record_ids = exact[key]
            state.row["search_history_match"] = record_ids
            confidence = "measured_history"
        else:
            adjusted = raw_ratio * correction
            confidence = (
                "historically_calibrated"
                if len(correction_by_key) >= 2
                else state.row.get("search_model_confidence", "medium")
            )
        state.normalized_score = adjusted
        state.row.update(
            {
                "search_model_raw_ratio_vs_bank_seed": f"{raw_ratio:.12g}",
                "search_model_ratio_vs_bank_seed": f"{adjusted:.12g}",
                "search_model_score": f"{adjusted:.12g}",
                "search_model_calibration": f"{correction:.12g}",
                "search_model_confidence": confidence,
            }
        )
    return correction, len(exact)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-candidates", type=Path, required=True)
    parser.add_argument("--workloads", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--all-output", type=Path)
    parser.add_argument("--history", type=Path)
    parser.add_argument("--top-k", type=int, default=20)
    parser.add_argument("--beam-width", type=int, default=64)
    parser.add_argument("--tabu-iters", type=int, default=64)
    parser.add_argument("--lns-rounds", type=int, default=8)
    parser.add_argument("--model-ratio-limit", type=float, default=1.03)
    parser.add_argument(
        "--optimization-scope",
        choices=("skinny_n_large_k_v1", "all_templates_validation"),
        default="skinny_n_large_k_v1",
    )
    parser.add_argument("--soc", required=True)
    parser.add_argument("--aic-cores", type=int, required=True)
    parser.add_argument("--l0a-bytes", type=int, required=True)
    parser.add_argument("--l0b-bytes", type=int, required=True)
    parser.add_argument("--l0c-bytes", type=int, required=True)
    parser.add_argument("--l1-bytes", type=int, required=True)
    parser.add_argument("--l2-bytes", type=int, required=True)
    parser.add_argument(
        "--l2-bytes-per-cycle-per-core", type=float, required=True
    )
    parser.add_argument(
        "--hbm-bytes-per-cycle-per-core", type=float, required=True
    )
    args = parser.parse_args()
    hardware = Hardware(
        aic_cores=args.aic_cores,
        l0a_bytes=args.l0a_bytes,
        l0b_bytes=args.l0b_bytes,
        l0c_bytes=args.l0c_bytes,
        l1_bytes=args.l1_bytes,
        l2_bytes=args.l2_bytes,
        l2_bytes_per_cycle_per_core=args.l2_bytes_per_cycle_per_core,
        hbm_bytes_per_cycle_per_core=args.hbm_bytes_per_cycle_per_core,
    )
    if (
        args.top_k <= 0
        or args.beam_width <= 0
        or args.tabu_iters < 0
        or args.lns_rounds < 0
        or args.model_ratio_limit <= 0
        or any(
            value <= 0
            for value in (
                hardware.aic_cores,
                hardware.l0a_bytes,
                hardware.l0b_bytes,
                hardware.l0c_bytes,
                hardware.l1_bytes,
                hardware.l2_bytes,
                hardware.l2_bytes_per_cycle_per_core,
                hardware.hbm_bytes_per_cycle_per_core,
            )
        )
    ):
        raise SearchError("search limits and platform capacities must be positive")

    from tbe.common.platform import set_current_compile_soc_info
    from tbe.common.utils import op_tiling

    set_current_compile_soc_info(args.soc)
    op_tiling._RT_BANK_CACHE = {}

    raw_fields, raw_rows = read_csv(args.raw_candidates)
    output_fields = ["rank", *(field for field in raw_fields if field != "rank")]
    for column in EXTRA_COLUMNS:
        if column not in output_fields:
            output_fields.append(column)
    workloads = load_workloads(args.workloads)
    history = load_measurement_history(
        args.history, args.soc, hardware.aic_cores
    )

    # Capture both the no-bank default and the exact same 23 fields after the
    # RuntimeKb injection path. MatMulV3 derives ND->NZ fields after the bank
    # lookup, so these two blobs are not assumed to be identical.
    seeds: dict[str, Seed] = {}
    for workload in workloads:
        if workload.dtype in DTYPE_NAME:
            seeds[workload.workload_id] = parse_seed(workload)

    grouped: dict[str, list[dict[str, str]]] = {}
    for row in raw_rows:
        grouped.setdefault(row["workload_id"], []).append(row)

    selected_rows: list[dict[str, str]] = []
    all_destination = None
    all_writer = None
    if args.all_output:
        args.all_output.parent.mkdir(parents=True, exist_ok=True)
        all_destination = args.all_output.open(
            "w", newline="", encoding="utf-8"
        )
        all_writer = csv.DictWriter(
            all_destination,
            fieldnames=output_fields,
            extrasaction="ignore",
        )
        all_writer.writeheader()

    def write_all(row: dict[str, str]) -> None:
        if all_writer is not None:
            all_writer.writerow(row)

    for workload in workloads:
        if workload.dtype not in DTYPE_NAME:
            continue
        seed = seeds[workload.workload_id]
        bank_path_diff = callback_derived_diff(
            seed.default, seed.bank
        )
        bank_seed_estimate = analytical_score(
            workload, seed.bank.knowledge, hardware, seed.bank
        )
        seed_score = bank_seed_estimate.cycles
        prototype = next(iter(grouped.get(workload.workload_id, [])), None)
        states: list[State] = []
        control = bank_seed_control(
            output_fields, workload, seed, hardware
        )
        selected_rows.append(dict(control.row))
        write_all(control.row)

        callback_limit = max(args.top_k * 3, args.beam_width)
        template_spaces = all_template_candidate_spaces(
            workload,
            seed,
            grouped.get(workload.workload_id, []),
            hardware,
            args.beam_width,
            args.optimization_scope,
        )
        callback_beams: dict[str, list[State]] = {}
        search_counts: dict[str, tuple[int, int, int]] = {}
        seed_signature = knowledge_signature(seed.bank.knowledge)
        for template, candidates in sorted(template_spaces.items()):
            template_states: list[State] = []
            for knowledge in candidates:
                if (
                    not hard_legal(workload, knowledge, hardware)
                    or knowledge_signature(knowledge) == seed_signature
                ):
                    continue
                estimate = analytical_score(
                    workload, knowledge, hardware
                )
                normalized = estimate.cycles / max(seed_score, 1.0)
                guidance = (
                    focused_candidate_guidance(knowledge)
                    if args.optimization_scope == "skinny_n_large_k_v1"
                    else "constraint_generated"
                )
                row = row_from_state(
                    output_fields,
                    prototype,
                    workload,
                    knowledge,
                    (
                        "cann81_skinny_n_v1_beam_tabu_lns"
                        if args.optimization_scope == "skinny_n_large_k_v1"
                        else "cann81_constraint_beam_tabu_lns"
                    ),
                    template,
                    normalized,
                    estimate.hbm_bytes,
                    estimate.l2_bytes,
                    seed.key,
                    guidance=guidance,
                    estimate=estimate,
                )
                template_states.append(
                    State(
                        row=row,
                        knowledge=knowledge,
                        model_score=estimate.cycles,
                        normalized_score=normalized,
                        hbm_bytes=estimate.hbm_bytes,
                        l2_bytes=estimate.l2_bytes,
                        template=template,
                        guidance=guidance,
                        estimate=estimate,
                    )
                )
            template_states.sort(key=state_sort_key)
            beam = constraint_aware_beam(
                template_states, args.beam_width
            )
            frontier = tabu_lns_search(
                template_states,
                beam,
                args.tabu_iters,
                args.lns_rounds,
                callback_limit,
            )
            if frontier:
                callback_beams[template] = frontier
            search_counts[template] = (
                len(template_states), len(beam), len(frontier)
            )
            states.extend(template_states)
        states.sort(key=state_sort_key)

        accepted: list[State] = []
        seen: set[tuple[int, ...]] = set()
        failures = 0
        first_failure = ""

        def try_callback(state: State) -> bool:
            nonlocal failures, first_failure
            signature = knowledge_signature(state.knowledge)
            if signature in seen:
                return False
            seen.add(signature)
            try:
                callback = validate_callback(workload, state)
            except Exception as exception:
                failures += 1
                if not first_failure:
                    first_failure = str(exception).replace("\n", " ")[:240]
                return False
            update_callback_columns(
                state,
                callback,
                seed,
                bank_seed_estimate,
                hardware,
                workload,
            )
            accepted.append(state)
            return True

        # First secure one valid representative of every generated template.
        for template in sorted(callback_beams):
            for state in callback_beams[template]:
                if try_callback(state):
                    break

        remaining = sorted(
            (
                state
                for template_states in callback_beams.values()
                for state in template_states
                if knowledge_signature(state.knowledge) not in seen
            ),
            key=lambda state: (
                state.normalized_score,
                knowledge_signature(state.knowledge),
            ),
        )
        for state in remaining:
            try_callback(state)
            if len(accepted) >= args.top_k:
                break

        history_correction, history_matches = calibrate_from_history(
            workload,
            accepted,
            history,
            bank_path_diff,
        )
        accepted.sort(
            key=state_sort_key
        )
        callback_valid = len(accepted)
        eligible = [
            state
            for state in accepted
            if not dominated_by_bank_seed(state.knowledge, seed)
        ]
        template_leaders: list[State] = []
        leader_templates: set[str] = set()
        for state in eligible:
            if state.template in leader_templates:
                continue
            leader_templates.add(state.template)
            template_leaders.append(state)
        preferred = [
            state
            for state in eligible
            if state.normalized_score <= args.model_ratio_limit
        ]
        chosen: list[State] = []
        chosen_signatures: set[tuple[int, ...]] = set()
        for state in [*template_leaders, *preferred, *eligible]:
            signature = knowledge_signature(state.knowledge)
            if signature in chosen_signatures:
                continue
            chosen_signatures.add(signature)
            chosen.append(state)
            if len(chosen) >= args.top_k:
                break

        for rank, state in enumerate(chosen, 1):
            state.row["rank"] = str(rank)
            selected_rows.append(dict(state.row))
        for rank, state in enumerate(states, 1):
            state.row["rank"] = str(rank)
            write_all(state.row)
        if all_destination is not None:
            all_destination.flush()

        print(
            f"template_search: {workload.workload_id} "
            f"scope={args.optimization_scope} "
            f"official={template_name(seed.knowledge)} "
            f"bank_seed_diff="
            f"{bank_path_diff or 'none'} "
            f"families="
            f"{','.join(f'{name}:{counts[0]}/{counts[1]}/{counts[2]}' for name, counts in search_counts.items()) or 'none'} "
            f"generated={len(states)} callback_valid={callback_valid} "
            f"selected_for_npu={len(chosen)} "
            f"preferred_model_ratio={args.model_ratio_limit:.3g} "
            f"history_matches={history_matches} "
            f"history_correction={history_correction:.4g} "
            f"callback_rejected={failures}"
            f"{f' first_rejection={first_failure}' if first_failure else ''}",
            flush=True,
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as destination:
        writer = csv.DictWriter(destination, fieldnames=output_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(selected_rows)
    if all_destination is not None:
        all_destination.close()
    print(
        f"template_search_completed: workloads={len(workloads)} "
        f"searched_selected="
        f"{sum(row.get('candidate_role') == 'searched' for row in selected_rows)} "
        f"bank_seed_controls="
        f"{sum(row.get('candidate_role') == 'bank_seed_control' for row in selected_rows)}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (SearchError, OSError, ValueError, KeyError) as exception:
        print(f"fatal: {exception}", flush=True)
        raise SystemExit(1)

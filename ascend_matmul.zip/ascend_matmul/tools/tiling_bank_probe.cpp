#include <cstdint>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "platform/platform_info.h"

namespace tuningtiling {
class TuningTilingDef;
}

namespace RuntimeKb {
bool InitBank(fe::PlatFormInfos *platformInfo);
uint32_t CommonHash(const void *input, uint32_t size, uint32_t seed);
uint32_t QueryBank(const void *input, size_t size, const std::string &opType,
                   std::shared_ptr<tuningtiling::TuningTilingDef> &tiling);
}

namespace {

constexpr uint32_t kRuntimeBankHashSeed = 271828;
constexpr size_t kMatMulV3InputBytes = 183;

std::vector<uint8_t> ReadBinary(const std::string &path)
{
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("cannot open input key: " + path);
    }
    return std::vector<uint8_t>(
        std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
}

void PrintUsage()
{
    std::cerr
        << "Usage:\n"
        << "  tiling_bank_probe --hash INPUT_BIN\n"
        << "  tiling_bank_probe --query INPUT_BIN SOC AIC_CORES\n";
}

}  // namespace

int main(int argc, char **argv)
{
    try {
        if (argc < 3) {
            PrintUsage();
            return 2;
        }
        const std::string mode = argv[1];
        const auto key = ReadBinary(argv[2]);
        if (key.size() != kMatMulV3InputBytes) {
            throw std::runtime_error(
                "MatMulV3 input key must be 183 bytes, got " +
                std::to_string(key.size()));
        }
        const uint32_t hash = RuntimeKb::CommonHash(
            key.data(), static_cast<uint32_t>(key.size()), kRuntimeBankHashSeed);
        if (mode == "--hash") {
            if (argc != 3) {
                PrintUsage();
                return 2;
            }
            std::cout << hash << '\n';
            return 0;
        }
        if (mode != "--query" || argc != 5) {
            PrintUsage();
            return 2;
        }

        const std::string soc = argv[3];
        const uint32_t expectedCores = static_cast<uint32_t>(std::stoul(argv[4]));
        auto &platformManager = fe::PlatformInfoManager::GeInstance();
        const uint32_t initializeRc = platformManager.InitializePlatformInfo();
        if (initializeRc != 0) {
            throw std::runtime_error(
                "InitializePlatformInfo failed, rc=" +
                std::to_string(initializeRc));
        }
        fe::PlatFormInfos platformInfo;
        fe::OptionalInfos optionalInfo;
        const uint32_t platformRc =
            platformManager.GetPlatformInfos(soc, platformInfo, optionalInfo);
        if (platformRc != 0) {
            throw std::runtime_error(
                "GetPlatformInfos failed, rc=" + std::to_string(platformRc));
        }
        const uint32_t platformCores = optionalInfo.GetAICoreNum();
        if (platformCores != 0 && platformCores != expectedCores) {
            throw std::runtime_error(
                "platform AIC count mismatch: expected=" +
                std::to_string(expectedCores) + " actual=" +
                std::to_string(platformCores));
        }
        if (!RuntimeKb::InitBank(&platformInfo)) {
            throw std::runtime_error("RuntimeKb::InitBank failed");
        }

        std::shared_ptr<tuningtiling::TuningTilingDef> tiling;
        const uint32_t rc = RuntimeKb::QueryBank(
            key.data(), key.size(), "MatMulV3", tiling);
        const bool found = rc == 0 && tiling != nullptr;
        std::cout << "hash=" << hash << " query_rc=" << rc
                  << " found=" << (found ? 1 : 0) << '\n';
        return found ? 0 : 3;
    } catch (const std::exception &exception) {
        std::cerr << "fatal: " << exception.what() << '\n';
        return 1;
    }
}

#include <cstdint>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace tuningtiling {
class TuningTilingDef;
}

namespace RuntimeKb {
uint32_t CommonHash(const void *input, uint32_t size, uint32_t seed);
uint32_t QueryBank(const void *input, size_t size, const std::string &opType,
                   std::shared_ptr<tuningtiling::TuningTilingDef> &tiling)
    __attribute__((weak));
uint32_t QueryBank(const void *input, size_t size, const std::string &opType,
                   uint32_t coreNum,
                   std::shared_ptr<tuningtiling::TuningTilingDef> &tiling)
    __attribute__((weak));
uint32_t QueryBank(const void *input, size_t size, const std::string &opType,
                   const std::string &socVersion, uint32_t coreNum,
                   std::shared_ptr<tuningtiling::TuningTilingDef> &tiling)
    __attribute__((weak));
}

namespace {

constexpr uint32_t kRuntimeBankHashSeed = 271828;
constexpr size_t kMatMulV3InputBytes = 183;

std::vector<uint8_t> ReadBinary(const std::string &path)
{
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("cannot open input key: " + path);
    }
    return std::vector<uint8_t>(
        std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>());
}

void PrintUsage()
{
    std::cerr
        << "Usage:\n"
        << "  tiling_bank_probe --hash INPUT_BIN\n"
        << "  tiling_bank_probe --query INPUT_BIN SOC AIC_CORES\n";
}

}  // namespace

int main(int argc, char **argv)
{
    try {
        if (argc < 3) {
            PrintUsage();
            return 2;
        }
        const std::string mode = argv[1];
        const auto key = ReadBinary(argv[2]);
        if (key.size() != kMatMulV3InputBytes) {
            throw std::runtime_error(
                "MatMulV3 input key must be 183 bytes, got " +
                std::to_string(key.size()));
        }
        const uint32_t hash = RuntimeKb::CommonHash(
            key.data(), static_cast<uint32_t>(key.size()), kRuntimeBankHashSeed);
        if (mode == "--hash") {
            if (argc != 3) {
                PrintUsage();
                return 2;
            }
            std::cout << hash << '\n';
            return 0;
        }
        if (mode != "--query" || argc != 5) {
            PrintUsage();
            return 2;
        }

        const std::string soc = argv[3];
        const uint32_t cores = static_cast<uint32_t>(std::stoul(argv[4]));
        std::shared_ptr<tuningtiling::TuningTilingDef> tiling;
        using QueryWithSoc = uint32_t (*)(
            const void *, size_t, const std::string &, const std::string &,
            uint32_t, std::shared_ptr<tuningtiling::TuningTilingDef> &);
        using QueryWithCore = uint32_t (*)(
            const void *, size_t, const std::string &, uint32_t,
            std::shared_ptr<tuningtiling::TuningTilingDef> &);

        const auto queryWithSoc =
            static_cast<QueryWithSoc>(RuntimeKb::QueryBank);
        const auto queryWithCore =
            static_cast<QueryWithCore>(RuntimeKb::QueryBank);
        uint32_t rc = 0;
        const char *queryApi = nullptr;
        if (queryWithSoc != nullptr) {
            queryApi = "explicit_soc_core";
            rc = queryWithSoc(
                key.data(), key.size(), "MatMulV3", soc, cores, tiling);
        } else if (queryWithCore != nullptr) {
            queryApi = "explicit_core";
            rc = queryWithCore(
                key.data(), key.size(), "MatMulV3", cores, tiling);
        } else {
            std::cout << "hash=" << hash
                      << " query_api=public_requires_platform"
                      << " query_deferred=1\n";
            return 0;
        }

        const bool found = rc == 0 && tiling != nullptr;
        std::cout << "hash=" << hash << " query_api=" << queryApi
                  << " query_rc=" << rc
                  << " found=" << (found ? 1 : 0) << '\n';
        return found ? 0 : 3;
    } catch (const std::exception &exception) {
        std::cerr << "fatal: " << exception.what() << '\n';
        return 1;
    }
}

# 驗證狀態

## 已完成

- CANN 8.3 RC2 Host 編譯：通過
- 官方 `MultiCoreMatmulTiling::GetTiling()` 實際執行：通過
- 約束感知 Beam Search + Tabu/LNS：通過
- 28 組大型、極瘦、轉置、尾塊與多資料型別工作負載：通過
- 完整搜索共記錄 38,435 個評估結果，輸出 292 個去重後 Top Tiling
- AscendC `dav-c220-cube` Kernel 編譯：通過
- FP16/BF16/FP32/INT8 × NN/TN/NT/TT 共 16 個 Kernel 入口：通過
- ACL Event NPU profiling Runner 編譯：通過
- CANN `tikicpulib::Ascend910B1` V220 CPU Debug FP16 MatMul Kernel：執行與零矩陣結果檢查通過
- CSV 與原始 `TCubeTiling` 二進位輸出：通過

## 目前未在交付工作區執行

- 真實 Ascend 910B Kernel Launch
- 真機延遲、吞吐與 msprof 指標

本工作區沒有昇騰 NPU 和驅動；真機 Runner、ACL Event CSV 和 msprof 腳本均已包含。最終 Tiling 排名應以真機 `median_ms` 為準。

## 已驗證輸出

```text
results/candidates.csv             292 個候選 + 標題列
results/all_evaluated.csv          38,435 個評估結果 + 標題列
results/search_summary.csv         28 組工作負載 + 標題列
results/tilings/*.bin              292 份官方 TCubeTiling
results/cpu_kernel_smoke.log       CANN CPU Debug 成功日誌
results/final_validation.log       編譯、官方 API 搜索、符號與腳本驗證
```

# NPU 快速執行

```bash
cd ascend_matmul_beam_lns
./run_npu.sh --mode smoke
```

Smoke 模式只跑一個小型 NPU workload，少量候選和少量 ACL Event samples，用來確認：

- CANN 路徑正確
- Host tiling search 可執行
- AscendC host-stub kernel 可 register/launch
- ACL launch/profiling 可執行

執行時會自動寫日誌到：

```text
results/logs/run_npu_*.log
```

預設終端只顯示階段狀態和錯誤摘要。需要完整中間輸出時使用：

```bash
RUN_VERBOSE=1 ./run_npu.sh --mode smoke
```

`[0/3] Detect NPU SoC` 會先從 NPU/driver 查實際 SoC，並自動設定
AscendC build 使用的 `ASCENDC_SOC_VERSION`。如果 `npu-smi` 存在但出現
symbol lookup、undefined symbol 或其他執行錯誤，腳本默認中斷，因為這類
錯誤通常會影響後續 ACL runtime。只有你已確認 ACL 不受 `npu-smi` 影響時，
才使用：

```bash
ALLOW_NPU_SMI_FAILURE=1 ./run_npu.sh --mode smoke
```

如果失敗但終端輸出太少，直接查看最後一個日誌：

```bash
ls -t results/logs/run_npu_*.log | head -1
tail -120 "$(ls -t results/logs/run_npu_*.log | head -1)"
```

確認 smoke 可跑後，再執行完整 NPU profiling：

```bash
./run_npu.sh --mode full
```

本工程固定使用：

```text
/usr/local/Ascend/ascend-toolkit/latest
```

如目標機 CANN 安裝位置不同，只改一次：

```text
scripts/env.sh
```

腳本會按執行機器架構自動使用：

```text
/usr/local/Ascend/ascend-toolkit/latest/$(uname -m)-linux
```

如果看到：

```text
aclInit failed, rc=507008
```

`507008` 是 `ACL_ERROR_RT_SOC_VERSION`，代表 runtime 判斷 SoC 版本不匹配。
優先確認 `scripts/env.sh` 指向的 CANN toolkit 與當前 driver/runtime 匹配，
以及下方的 `ASCENDC_SOC_VERSION` 是否需要按實際 910B 型號覆蓋。

AscendC host-stub 編譯需要具體 910B 型號。腳本會自動偵測
`Ascend910B1/B2/B2C/B3/B4/B4-1` 並傳給 build。只有硬體查詢只能回報泛化
`Ascend910B` 時，才會使用 CANN 模板的官方默認 `Ascend910B1`，並在 log 裡標出。

第一輪對每個工作負載測量前 12 個候選：

```bash
RANK_LIMIT=12 WARMUP=10 REPEAT=50 SAMPLES=15 \
./scripts/profile_npu.sh results/candidates.csv results/npu_round1
```

輸出：

```text
results/npu_round1_profile.csv
results/npu_round1_samples.csv
results/npu_round1_ranked.csv
results/npu_round1_best.csv
results/npu_round1_proxy_comparison.csv
```

精測前 3 名：

```bash
RANK_LIMIT=3 WARMUP=30 REPEAT=200 SAMPLES=30 \
./scripts/profile_npu.sh results/candidates.csv results/npu_precise
```

單一候選取得 msprof：

```bash
./scripts/profile_one_msprof.sh llm_full_4096_ffn_up 1 results/candidates.csv
```

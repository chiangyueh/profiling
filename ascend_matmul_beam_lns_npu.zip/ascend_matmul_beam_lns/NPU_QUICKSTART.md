# NPU 快速執行

```bash
cd ascend_matmul_beam_lns
./run_npu.sh --mode smoke
```

Smoke 模式只跑一個小型 NPU workload，少量候選和少量 ACL Event samples，用來確認：

- CANN 路徑正確
- Host tiling search 可執行
- AscendC kernel 可載入
- ACL launch/profiling 可執行

執行時會自動寫日誌到：

```text
results/logs/run_npu_*.log
```

如果失敗但終端輸出太少，直接查看最後一個日誌：

```bash
ls -t results/logs/run_npu_*.log | head -1
tail -120 "$(ls -t results/logs/run_npu_*.log | head -1)"
```

確認 smoke 可跑後，再執行完整 NPU profiling：

```bash
./run_npu.sh --mode full
```

本工程固定使用：

```text
/usr/local/Ascend/ascend-toolkit/latest
```

如目標機 CANN 安裝位置不同，只改一次：

```text
scripts/env.sh
```

第一輪對每個工作負載測量前 12 個候選：

```bash
RANK_LIMIT=12 WARMUP=10 REPEAT=50 SAMPLES=15 \
./scripts/profile_npu.sh results/candidates.csv results/npu_round1
```

輸出：

```text
results/npu_round1_profile.csv
results/npu_round1_samples.csv
results/npu_round1_ranked.csv
results/npu_round1_best.csv
results/npu_round1_proxy_comparison.csv
```

精測前 3 名：

```bash
RANK_LIMIT=3 WARMUP=30 REPEAT=200 SAMPLES=30 \
./scripts/profile_npu.sh results/candidates.csv results/npu_precise
```

單一候選取得 msprof：

```bash
./scripts/profile_one_msprof.sh llm_full_4096_ffn_up 1 results/candidates.csv
```

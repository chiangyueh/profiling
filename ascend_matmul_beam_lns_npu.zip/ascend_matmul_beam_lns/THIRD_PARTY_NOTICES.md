# Third-Party Notices

`compat/` 內的相容頭文件保留原始 Huawei CANN Open Software 版權與授權聲明。
其用途僅是補足 CANN 8.3 RC2 此安裝包中 Host Tiling 頭文件的相依項，使本工程能直接編譯。
其餘 `host/`、`kernel/`、`runner/`、`cpu_smoke/`、`scripts/` 與 `tools/` 為本工程實作。

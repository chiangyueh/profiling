#include "kernel_operator.h"
#include "tikicpulib.h"

#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

extern "C" void matmul_search_fp16_nn(
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, GM_ADDR tiling);

namespace {

std::vector<uint8_t> ReadBinary(const std::string &path)
{
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    if (!input) throw std::runtime_error("cannot open " + path);
    const std::streamsize size = input.tellg();
    if (size <= 0) throw std::runtime_error("empty binary " + path);
    input.seekg(0, std::ios::beg);
    std::vector<uint8_t> data(static_cast<size_t>(size));
    if (!input.read(reinterpret_cast<char *>(data.data()), size)) {
        throw std::runtime_error("cannot read " + path);
    }
    return data;
}

}  // namespace

int main(int argc, char **argv)
{
    try {
        if (argc != 3) {
            std::cerr << "usage: matmul_cpu_smoke TILING_BIN BLOCK_DIM\n";
            return 2;
        }
        constexpr int32_t m = 32;
        constexpr int32_t n = 32;
        constexpr int32_t k = 32;
        constexpr size_t elementBytes = sizeof(uint16_t);
        const uint32_t blockDim = static_cast<uint32_t>(std::stoul(argv[2]));
        const auto tilingHost = ReadBinary(argv[1]);

        const size_t aBytes = static_cast<size_t>(m) * k * elementBytes;
        const size_t bBytes = static_cast<size_t>(k) * n * elementBytes;
        const size_t cBytes = static_cast<size_t>(m) * n * elementBytes;
        const size_t workspaceBytes = 2 * 1024 * 1024;

        auto *a = static_cast<uint8_t *>(AscendC::GmAlloc(aBytes));
        auto *b = static_cast<uint8_t *>(AscendC::GmAlloc(bBytes));
        auto *c = static_cast<uint8_t *>(AscendC::GmAlloc(cBytes));
        auto *workspace = static_cast<uint8_t *>(AscendC::GmAlloc(workspaceBytes));
        auto *tiling = static_cast<uint8_t *>(AscendC::GmAlloc(tilingHost.size()));
        if (!a || !b || !c || !workspace || !tiling) {
            throw std::runtime_error("GmAlloc failed");
        }
        std::memset(a, 0, aBytes);
        std::memset(b, 0, bBytes);
        std::memset(c, 0x5a, cBytes);
        std::memset(workspace, 0, workspaceBytes);
        std::memcpy(tiling, tilingHost.data(), tilingHost.size());

        ICPU_RUN_KF(matmul_search_fp16_nn, blockDim, a, b, c, workspace, tiling);

        bool correct = true;
        for (size_t i = 0; i < cBytes; ++i) {
            if (c[i] != 0) {
                correct = false;
                std::cerr << "nonzero output at byte " << i << ": " << static_cast<int>(c[i]) << '\n';
                break;
            }
        }

        AscendC::GmFree(a);
        AscendC::GmFree(b);
        AscendC::GmFree(c);
        AscendC::GmFree(workspace);
        AscendC::GmFree(tiling);

        if (!correct) return 1;
        std::cout << "CANN CPU kernel smoke passed: M=32 N=32 K=32 blockDim=" << blockDim << '\n';
        return 0;
    } catch (const std::exception &ex) {
        std::cerr << "fatal: " << ex.what() << '\n';
        return 1;
    }
}

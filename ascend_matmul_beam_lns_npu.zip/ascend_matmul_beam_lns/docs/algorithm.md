# 搜索算法

## 1. 合法離散空間

候選集合不是連續空間：

```text
baseM ∈ 16 的正整數倍
baseN ∈ 16 的正整數倍
baseK ∈ K0 的正整數倍
```

其中：

```text
K0 = (32 / input_bit_width) × 8
```

所以：

```text
FP16/BF16: K0 = 16
FP32:      K0 = 8
INT8:      K0 = 32
```

搜索前執行硬約束剪枝：

```text
baseM × baseK × input_bytes × dbA ≤ L0A
baseN × baseK × input_bytes × dbB ≤ L0B
baseM × baseN × accumulator_bytes ≤ L0C
```

通過外部剪枝後，每個完整候選仍必須調用：

```cpp
matmul_tiling::MultiCoreMatmulTiling::GetTiling()
```

只有官方 API 成功返回的候選才進入代理評分。

## 2. Beam Search

按以下階段擴展：

```text
baseM → baseN → baseK → traverse/DB/Split-K
```

每一層：

1. 產生合法離散後繼。
2. 使用低成本粗略分數排序。
3. 去除重複候選。
4. 僅保留前 `beamWidth` 個。

最後一層的完整候選調用官方 API，再用完整代理模型排序。

## 3. CPU 代理模型

代理模型直接讀取官方 `TCubeTiling`，而不是使用搜索提示值。

主要項目：

```text
Cube 計算週期
GM 輸入與輸出流量
L1→L0A/L0B 搬運
官方 singleCoreM/N/K 造成的尾塊
實際 usedCoreNum 與可用核心數
Base block 迴圈與啟動成本
Split-K 額外同步與歸約成本
```

Cube 理論量採用：

```text
MAC/cycle = (256 / input_bit_width) × 256
```

主路徑採用計算與 GM 搬運重疊：

```text
main_cycles = max(cube_cycles, gm_cycles)
```

完整分數：

```text
total = main_cycles
      + 0.35 × l1_cycles
      + launch_cycles
      + tail_penalty
      + balance_penalty
      + split_k_penalty
```

此模型只負責候選預排序。真機資料取得後，應根據代理排名與 NPU 延遲的相關性更新權重。

## 4. Tabu Search

Beam Top 種子會進一步做離散鄰域搜索：

```text
baseM/baseN/baseK 移動到相鄰合法值
切換遍歷順序
切換 L0A/L0B 雙緩衝
切換 Split-K
```

Tabu 表保存最近訪問的候選，防止在相鄰點之間循環。當候選優於當前最佳值時，使用 aspiration 規則允許打破 Tabu。

## 5. Large Neighborhood Search

LNS 輪流破壞並重建三類參數：

```text
重新搜索 baseM/baseN
重新搜索 baseK/DB
重新搜索局部 M/N + traverse/Split-K
```

每個 LNS 候選仍需通過硬約束與官方 API。

## 6. 去重

不同提示可能被官方 API 調整成同一份最終 Tiling。因此 Top-K 不是按照提示去重，而是按照以下官方字段建立簽名：

```text
usedCoreNum
singleCoreM/N/K
baseM/N/K
depthA1/B1
stepM/N/Ka/Kb
iterateOrder
dbL0A/B/C
```

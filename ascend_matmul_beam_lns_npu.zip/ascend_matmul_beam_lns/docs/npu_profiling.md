# NPU Profiling

## ACL Event 測量

每個候選執行：

```text
warmup 次 Kernel
同步 Stream
建立 start/end Event
每個 sample 連續啟動 repeat 次 Kernel
用 Event 計算平均單次 Kernel 延遲
重複 samples 組
```

輸出統計：

```text
min_ms
mean_ms
median_ms
stddev_ms
p95_ms
max_ms
tflops
```

推薦以 `median_ms` 作為最終排序指標，並使用 `stddev_ms` 判斷噪聲。

## 推薦第一輪

```bash
RANK_LIMIT=12 WARMUP=10 REPEAT=50 SAMPLES=15 \
./scripts/profile_npu.sh results/candidates.csv results/npu_round1
```

## 推薦精測

第一輪每個工作負載保留前 3 名後：

```bash
RANK_LIMIT=3 WARMUP=30 REPEAT=200 SAMPLES=30 \
./scripts/profile_npu.sh results/candidates.csv results/npu_precise
```

## msprof

不要對所有候選都執行完整 msprof。先用 ACL Event 找到前幾名，再對代表性候選取得：

```text
Cube Pipeline 使用率
MTE Pipeline 使用率
Runtime API 時間
Task 時間
```

例如：

```bash
./scripts/profile_one_msprof.sh llm_full_4096_ffn_up 1 results/candidates.csv
```

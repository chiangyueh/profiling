#pragma once

#include "search_types.h"

namespace matmul_search {

struct ProxyWeights {
    double gmBytesPerCycle = 2048.0;
    double l1BytesPerCycle = 4096.0;
    double launchPerCoreCycles = 6.0;
    double blockLoopCycles = 16.0;
    double tailWeight = 0.35;
    double balanceWeight = 0.20;
    double splitKBaseCycles = 180.0;
    double splitKPerCoreCycles = 12.0;
};

class ProxyModel {
public:
    ProxyModel(PlatformCaps caps, ProxyWeights weights = {});
    ProxyBreakdown Score(const Workload &workload, const Candidate &candidate, const TCubeTiling &tiling) const;

private:
    PlatformCaps caps_;
    ProxyWeights weights_;
};

}  // namespace matmul_search

#include <filesystem>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "beam_lns_search.h"
#include "csv_io.h"

namespace {

void PrintUsage()
{
    std::cout
        << "matmul_tiling_search [options]\n"
        << "  --workloads FILE            workload CSV\n"
        << "  --m M --n N --k K           single workload\n"
        << "  --dtype fp16|bf16|fp32|int8\n"
        << "  --trans-a 0|1 --trans-b 0|1\n"
        << "  --cores N                   maximum AI Core count\n"
        << "  --beam-width N              beam width\n"
        << "  --tabu-iters N              tabu/LNS iterations\n"
        << "  --lns-rounds N              large-neighborhood rounds\n"
        << "  --top-k N                   candidates saved per workload\n"
        << "  --max-base-m N --max-base-n N --max-base-k N\n"
        << "  --search-split-k 0|1\n"
        << "  --soc VERSION               default Ascend910B\n"
        << "  --output FILE               top-candidate CSV\n"
        << "  --all-output FILE           all evaluated candidates CSV\n"
        << "  --tiling-dir DIR            raw TCubeTiling files\n";
}

bool ToBool(const std::string &value)
{
    return value == "1" || value == "true" || value == "yes" || value == "on";
}

std::unordered_map<std::string, std::string> ParseArgs(int argc, char **argv)
{
    std::unordered_map<std::string, std::string> args;
    for (int i = 1; i < argc; ++i) {
        const std::string key = argv[i];
        if (key == "--help" || key == "-h") {
            args[key] = "1";
            continue;
        }
        if (key.rfind("--", 0) != 0 || i + 1 >= argc) {
            throw std::runtime_error("invalid argument: " + key);
        }
        args[key] = argv[++i];
    }
    return args;
}

std::string Get(const std::unordered_map<std::string, std::string> &args,
                const std::string &key, const std::string &fallback)
{
    const auto it = args.find(key);
    return it == args.end() ? fallback : it->second;
}

int32_t GetInt(const std::unordered_map<std::string, std::string> &args,
               const std::string &key, int32_t fallback)
{
    const auto it = args.find(key);
    return it == args.end() ? fallback : std::stoi(it->second);
}

}  // namespace

int main(int argc, char **argv)
{
    using namespace matmul_search;
    try {
        const auto args = ParseArgs(argc, argv);
        if (args.count("--help") || args.count("-h")) {
            PrintUsage();
            return 0;
        }

        const std::string output = Get(args, "--output", "results/candidates.csv");
        const std::string allOutput = Get(args, "--all-output", "results/all_evaluated.csv");
        const std::string tilingDir = Get(args, "--tiling-dir", "results/tilings");
        const std::string soc = Get(args, "--soc", "Ascend910B");

        OfficialTilingEngine engine(soc);
        if (!engine.IsReady()) {
            std::cerr << "CANN platform initialization failed: " << engine.Error() << '\n';
            return 2;
        }
        const auto &caps = engine.Caps();
        std::cout << "CANN platform=" << soc << " cores=" << caps.coreNum
                  << " L0A=" << caps.l0aBytes << " L0B=" << caps.l0bBytes
                  << " L0C=" << caps.l0cBytes << " L1=" << caps.l1Bytes
                  << " UB=" << caps.ubBytes << '\n';

        std::vector<Workload> workloads;
        std::string error;
        const auto workloadIt = args.find("--workloads");
        if (workloadIt != args.end()) {
            if (!LoadWorkloadsCsv(workloadIt->second, workloads, error)) {
                std::cerr << error << '\n';
                return 3;
            }
        } else {
            if (args.count("--m") == 0 || args.count("--n") == 0 || args.count("--k") == 0) {
                PrintUsage();
                return 3;
            }
            Workload w;
            w.id = Get(args, "--id", "single");
            w.m = GetInt(args, "--m", 1);
            w.n = GetInt(args, "--n", 1);
            w.k = GetInt(args, "--k", 1);
            if (!ParseDType(Get(args, "--dtype", "fp16"), w.dtype)) {
                std::cerr << "unsupported dtype\n";
                return 3;
            }
            w.transA = ToBool(Get(args, "--trans-a", "0"));
            w.transB = ToBool(Get(args, "--trans-b", "0"));
            w.maxCores = GetInt(args, "--cores", caps.coreNum);
            workloads.push_back(w);
        }

        SearchOptions options;
        options.beamWidth = GetInt(args, "--beam-width", options.beamWidth);
        options.tabuIterations = GetInt(args, "--tabu-iters", options.tabuIterations);
        options.lnsRounds = GetInt(args, "--lns-rounds", options.lnsRounds);
        options.topK = GetInt(args, "--top-k", options.topK);
        options.seedCount = GetInt(args, "--seed-count", options.seedCount);
        options.maxBaseM = GetInt(args, "--max-base-m", options.maxBaseM);
        options.maxBaseN = GetInt(args, "--max-base-n", options.maxBaseN);
        options.maxBaseK = GetInt(args, "--max-base-k", options.maxBaseK);
        options.searchSplitK = ToBool(Get(args, "--search-split-k", "1"));

        std::vector<Evaluation> allEvaluations;
        std::vector<Evaluation> allTop;
        for (const auto &workload : workloads) {
            std::cout << "search " << workload.id << " M=" << workload.m << " N=" << workload.n
                      << " K=" << workload.k << " dtype=" << DTypeToString(workload.dtype) << std::endl;
            BeamLnsSearcher searcher(engine, options);
            SearchResult result = searcher.Search(workload);
            allEvaluations.insert(allEvaluations.end(), result.evaluated.begin(), result.evaluated.end());
            allTop.insert(allTop.end(), result.top.begin(), result.top.end());
            if (!result.top.empty()) {
                const auto &best = result.top.front();
                std::cout << "  evaluated=" << result.evaluated.size()
                          << " valid_top=" << result.top.size()
                          << " best_hint=" << best.candidate.baseM << 'x' << best.candidate.baseN << 'x'
                          << best.candidate.baseK
                          << " official=" << best.tiling.baseM << 'x' << best.tiling.baseN << 'x'
                          << best.tiling.baseK << " cores=" << best.tiling.usedCoreNum
                          << " score=" << best.proxy.total << '\n';
            } else {
                std::cout << "  no valid candidates\n";
            }
        }

        if (!WriteEvaluationsCsv(output, allTop, true, tilingDir, error)) {
            std::cerr << error << '\n';
            return 4;
        }
        if (!WriteEvaluationsCsv(allOutput, allEvaluations, false, "", error)) {
            std::cerr << error << '\n';
            return 4;
        }
        std::cout << "top CSV: " << output << '\n'
                  << "all CSV: " << allOutput << '\n'
                  << "tiling binaries: " << tilingDir << '\n';
        return 0;
    } catch (const std::exception &ex) {
        std::cerr << "fatal: " << ex.what() << '\n';
        return 1;
    }
}

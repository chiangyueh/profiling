#include "official_tiling.h"

#include <algorithm>
#include <exception>
#include <sstream>

namespace matmul_search {
namespace {

matmul_tiling::DataType ToCannInputType(DType dtype)
{
    switch (dtype) {
        case DType::FP16: return matmul_tiling::DataType::DT_FLOAT16;
        case DType::BF16: return matmul_tiling::DataType::DT_BF16;
        case DType::FP32: return matmul_tiling::DataType::DT_FLOAT;
        case DType::INT8: return matmul_tiling::DataType::DT_INT8;
    }
    return matmul_tiling::DataType::DT_FLOAT16;
}

matmul_tiling::DataType ToCannOutputType(DType dtype)
{
    if (dtype == DType::INT8) {
        return matmul_tiling::DataType::DT_INT32;
    }
    return ToCannInputType(dtype);
}

void AppendSetterError(std::ostringstream &os, const char *name, int32_t rc)
{
    if (rc != 0) {
        if (os.tellp() > 0) {
            os << '|';
        }
        os << name << '=' << rc;
    }
}

}  // namespace

OfficialTilingEngine::OfficialTilingEngine(const std::string &socVersion)
{
    platform_ = platform_ascendc::PlatformAscendCManager::GetInstance(socVersion.c_str());
    if (platform_ == nullptr) {
        error_ = "PlatformAscendCManager returned null";
        return;
    }

    caps_.coreNum = static_cast<int32_t>(platform_->GetCoreNumAic());
    if (caps_.coreNum <= 0) {
        caps_.coreNum = static_cast<int32_t>(platform_->GetCoreNum());
    }
    if (caps_.coreNum <= 0) {
        caps_.coreNum = 24;
    }

    auto readSize = [this](platform_ascendc::CoreMemType type, uint64_t fallback) {
        uint64_t size = 0;
        platform_->GetCoreMemSize(type, size);
        return size == 0 ? fallback : size;
    };
    caps_.l0aBytes = readSize(platform_ascendc::CoreMemType::L0_A, caps_.l0aBytes);
    caps_.l0bBytes = readSize(platform_ascendc::CoreMemType::L0_B, caps_.l0bBytes);
    caps_.l0cBytes = readSize(platform_ascendc::CoreMemType::L0_C, caps_.l0cBytes);
    caps_.l1Bytes = readSize(platform_ascendc::CoreMemType::L1, caps_.l1Bytes);
    caps_.ubBytes = readSize(platform_ascendc::CoreMemType::UB, caps_.ubBytes);
}

bool OfficialTilingEngine::IsReady() const
{
    return platform_ != nullptr;
}

const std::string &OfficialTilingEngine::Error() const
{
    return error_;
}

const PlatformCaps &OfficialTilingEngine::Caps() const
{
    return caps_;
}

Evaluation OfficialTilingEngine::Evaluate(const Workload &workload, const Candidate &candidate) const
{
    Evaluation result;
    result.workload = workload;
    result.candidate = candidate;

    if (platform_ == nullptr) {
        result.error = error_;
        return result;
    }
    if (workload.m <= 0 || workload.n <= 0 || workload.k <= 0) {
        result.error = "shape must be positive";
        return result;
    }

    try {
        matmul_tiling::MultiCoreMatmulTiling tiler(*platform_);
        std::ostringstream setterErrors;
        const auto inputType = ToCannInputType(workload.dtype);
        const auto outputType = ToCannOutputType(workload.dtype);

        AppendSetterError(setterErrors, "SetDim", tiler.SetDim(std::min(workload.maxCores, caps_.coreNum)));
        AppendSetterError(setterErrors, "SetAType", tiler.SetAType(
            matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND, inputType, workload.transA));
        AppendSetterError(setterErrors, "SetBType", tiler.SetBType(
            matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND, inputType, workload.transB));
        AppendSetterError(setterErrors, "SetCType", tiler.SetCType(
            matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND, outputType));
        AppendSetterError(setterErrors, "SetShape", tiler.SetShape(workload.m, workload.n, workload.k));
        AppendSetterError(setterErrors, "SetOrgShape", tiler.SetOrgShape(workload.m, workload.n, workload.k));
        AppendSetterError(setterErrors, "SetFixSplit", tiler.SetFixSplit(
            candidate.baseM, candidate.baseN, candidate.baseK));
        AppendSetterError(setterErrors, "SetDoubleBuffer", tiler.SetDoubleBuffer(
            candidate.dbA, candidate.dbB, false, false, true, true));

        if (candidate.traverse == 1) {
            AppendSetterError(setterErrors, "SetTraverseM", tiler.SetTraverse(matmul_tiling::MatrixTraverse::FIRSTM));
        } else if (candidate.traverse == 2) {
            AppendSetterError(setterErrors, "SetTraverseN", tiler.SetTraverse(matmul_tiling::MatrixTraverse::FIRSTN));
        }
        tiler.EnableMultiCoreSplitK(candidate.splitK);

        if (setterErrors.tellp() > 0) {
            result.error = setterErrors.str();
            return result;
        }

        result.officialReturn = tiler.GetTiling(result.tiling);
        if (result.officialReturn == -1) {
            result.error = "MultiCoreMatmulTiling::GetTiling returned -1";
            return result;
        }
        if (result.tiling.usedCoreNum <= 0 || result.tiling.baseM <= 0 ||
            result.tiling.baseN <= 0 || result.tiling.baseK <= 0 ||
            result.tiling.singleCoreM <= 0 || result.tiling.singleCoreN <= 0 ||
            result.tiling.singleCoreK <= 0) {
            result.error = "official tiling contains non-positive dimensions";
            return result;
        }

        result.valid = true;
        result.tilingSignature = TilingSignature(result.tiling);
        return result;
    } catch (const std::exception &ex) {
        result.error = std::string("exception:") + ex.what();
        return result;
    } catch (...) {
        result.error = "unknown exception";
        return result;
    }
}

}  // namespace matmul_search

#include "proxy_model.h"

#include <algorithm>
#include <cmath>

namespace matmul_search {
namespace {

template <typename T>
T CeilDiv(T x, T y)
{
    return y <= 0 ? 0 : (x + y - 1) / y;
}

double SafeRatio(double num, double den)
{
    return den <= 0.0 ? 0.0 : num / den;
}

}  // namespace

ProxyModel::ProxyModel(PlatformCaps caps, ProxyWeights weights)
    : caps_(caps), weights_(weights)
{
}

ProxyBreakdown ProxyModel::Score(
    const Workload &w, const Candidate &candidate, const TCubeTiling &t) const
{
    ProxyBreakdown out;
    const double inputBytes = static_cast<double>(DTypeBytes(w.dtype));
    const double outputBytes = static_cast<double>(OutputBytes(w.dtype));
    const double bits = static_cast<double>(DTypeBits(w.dtype));
    const double cubeMacPerCycle = (256.0 / bits) * 256.0;
    const int64_t mParts = std::max<int64_t>(1, CeilDiv<int64_t>(w.m, t.singleCoreM));
    const int64_t nParts = std::max<int64_t>(1, CeilDiv<int64_t>(w.n, t.singleCoreN));
    const int64_t kParts = std::max<int64_t>(1, CeilDiv<int64_t>(w.k, t.singleCoreK));

    const int64_t paddedM = mParts * static_cast<int64_t>(t.singleCoreM);
    const int64_t paddedN = nParts * static_cast<int64_t>(t.singleCoreN);
    const int64_t paddedK = kParts * static_cast<int64_t>(t.singleCoreK);
    const double actualMac = static_cast<double>(w.m) * w.n * w.k;
    const double paddedMac = static_cast<double>(paddedM) * paddedN * paddedK;
    out.tailEfficiency = std::min(1.0, SafeRatio(actualMac, paddedMac));

    const double usedCores = std::max(1, t.usedCoreNum);
    const double availableCores = std::max(1, std::min(w.maxCores, caps_.coreNum));
    out.coreUtilization = std::min(1.0, SafeRatio(usedCores, availableCores));
    out.cubeCycles = paddedMac / (cubeMacPerCycle * usedCores);

    const double aBytes = static_cast<double>(w.m) * w.k * inputBytes * nParts;
    const double bBytes = static_cast<double>(w.k) * w.n * inputBytes * mParts;
    const double cBytes = static_cast<double>(w.m) * w.n * outputBytes;
    out.estimatedGmBytes = aBytes + bBytes + cBytes;
    out.gmCycles = out.estimatedGmBytes / std::max(1.0, weights_.gmBytesPerCycle);

    const int64_t mBaseLoops = std::max<int64_t>(1, CeilDiv<int64_t>(t.singleCoreM, t.baseM));
    const int64_t nBaseLoops = std::max<int64_t>(1, CeilDiv<int64_t>(t.singleCoreN, t.baseN));
    const int64_t kBaseLoops = std::max<int64_t>(1, CeilDiv<int64_t>(t.singleCoreK, t.baseK));
    const double aL1 = static_cast<double>(t.baseM) * t.baseK * inputBytes;
    const double bL1 = static_cast<double>(t.baseN) * t.baseK * inputBytes;
    const double l1Traffic = usedCores * mBaseLoops * nBaseLoops * kBaseLoops * (aL1 + bL1);
    out.l1Cycles = l1Traffic / (std::max(1.0, weights_.l1BytesPerCycle) * usedCores);

    const double idealParts = static_cast<double>(mParts * nParts * kParts);
    const double excessCoreMapping = std::max(0.0, usedCores - idealParts) / usedCores;
    const double mRemainder = static_cast<double>(paddedM - w.m) / std::max<int64_t>(1, paddedM);
    const double nRemainder = static_cast<double>(paddedN - w.n) / std::max<int64_t>(1, paddedN);
    const double underutilization = 1.0 - out.coreUtilization;
    out.balancePenalty = out.cubeCycles * weights_.balanceWeight *
        std::min(1.0, excessCoreMapping + underutilization + 0.5 * (mRemainder + nRemainder));
    out.tailPenalty = out.cubeCycles * weights_.tailWeight * (1.0 - out.tailEfficiency);

    const double blockLoops = static_cast<double>(mBaseLoops * nBaseLoops * kBaseLoops);
    out.launchCycles = usedCores * weights_.launchPerCoreCycles +
        blockLoops * weights_.blockLoopCycles;

    if (candidate.splitK || kParts > 1) {
        out.splitKPenalty = weights_.splitKBaseCycles +
            weights_.splitKPerCoreCycles * usedCores +
            static_cast<double>(w.m) * w.n * outputBytes / 4096.0;
    }

    const double overlappedMain = std::max(out.cubeCycles, out.gmCycles);
    out.total = overlappedMain + 0.35 * out.l1Cycles + out.launchCycles +
        out.tailPenalty + out.balancePenalty + out.splitKPenalty;
    out.arithmeticIntensity = SafeRatio(2.0 * actualMac, out.estimatedGmBytes);
    return out;
}

}  // namespace matmul_search

#include "kernel_operator.h"
#include "lib/matmul_intf.h"

namespace {

__aicore__ inline void LoadCubeTiling(const __gm__ uint8_t *srcBytes, TCubeTiling &dst)
{
    const __gm__ uint32_t *src = reinterpret_cast<const __gm__ uint32_t *>(srcBytes);
    uint32_t *out = reinterpret_cast<uint32_t *>(&dst);
    for (uint32_t i = 0; i < sizeof(TCubeTiling) / sizeof(uint32_t); ++i) {
        out[i] = src[i];
    }
}

template <typename InputT, typename OutputT, bool TRANS_A, bool TRANS_B>
__aicore__ inline void RunMatmul(
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, GM_ADDR tiling)
{
#if defined(__CCE_KT_TEST__) && defined(MATMUL_CPU_SMOKE_ONLY)
    if (g_coreType != AscendC::AIC_TYPE) {
        return;
    }
#endif
    using AType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, InputT, TRANS_A>;
    using BType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, InputT, TRANS_B>;
    using CType = AscendC::MatmulType<AscendC::TPosition::GM, CubeFormat::ND, OutputT, false>;

    TCubeTiling tilingData{};
    LoadCubeTiling(reinterpret_cast<const __gm__ uint8_t *>(tiling), tilingData);

    AscendC::TPipe pipe;
    AscendC::Matmul<AType, BType, CType> mm;
    REGIST_MATMUL_OBJ(&pipe, workspace, mm, &tilingData);

    AscendC::GlobalTensor<InputT> aGm;
    AscendC::GlobalTensor<InputT> bGm;
    AscendC::GlobalTensor<OutputT> cGm;
    aGm.SetGlobalBuffer(reinterpret_cast<__gm__ InputT *>(a));
    bGm.SetGlobalBuffer(reinterpret_cast<__gm__ InputT *>(b));
    cGm.SetGlobalBuffer(reinterpret_cast<__gm__ OutputT *>(c));

    mm.SetTensorA(aGm, TRANS_A);
    mm.SetTensorB(bGm, TRANS_B);
    mm.IterateAll(cGm);
    mm.End();
}

}  // namespace

#define DEFINE_MATMUL_KERNEL(NAME, INPUT_T, OUTPUT_T, TRANS_A, TRANS_B) \
extern "C" __global__ __aicore__ void NAME(                              \
    GM_ADDR a, GM_ADDR b, GM_ADDR c, GM_ADDR workspace, GM_ADDR tiling)  \
{                                                                         \
    RunMatmul<INPUT_T, OUTPUT_T, TRANS_A, TRANS_B>(a, b, c, workspace, tiling); \
}

#ifdef MATMUL_CPU_SMOKE_ONLY
DEFINE_MATMUL_KERNEL(matmul_search_fp16_nn, half, half, false, false)
#else
DEFINE_MATMUL_KERNEL(matmul_search_fp16_nn, half, half, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp16_tn, half, half, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp16_nt, half, half, false, true)
DEFINE_MATMUL_KERNEL(matmul_search_fp16_tt, half, half, true, true)

DEFINE_MATMUL_KERNEL(matmul_search_bf16_nn, bfloat16_t, bfloat16_t, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_bf16_tn, bfloat16_t, bfloat16_t, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_bf16_nt, bfloat16_t, bfloat16_t, false, true)
DEFINE_MATMUL_KERNEL(matmul_search_bf16_tt, bfloat16_t, bfloat16_t, true, true)

DEFINE_MATMUL_KERNEL(matmul_search_fp32_nn, float, float, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp32_tn, float, float, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_fp32_nt, float, float, false, true)
DEFINE_MATMUL_KERNEL(matmul_search_fp32_tt, float, float, true, true)

DEFINE_MATMUL_KERNEL(matmul_search_int8_nn, int8_t, int32_t, false, false)
DEFINE_MATMUL_KERNEL(matmul_search_int8_tn, int8_t, int32_t, true, false)
DEFINE_MATMUL_KERNEL(matmul_search_int8_nt, int8_t, int32_t, false, true)
DEFINE_MATMUL_KERNEL(matmul_search_int8_tt, int8_t, int32_t, true, true)
#endif

#undef DEFINE_MATMUL_KERNEL

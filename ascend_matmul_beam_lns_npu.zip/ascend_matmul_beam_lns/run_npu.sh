#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "${ROOT}/results/logs"
RUN_LOG="${ROOT}/results/logs/run_npu_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "${RUN_LOG}") 2>&1

if [[ "${RUN_DEBUG:-0}" == "1" ]]; then
    export PS4='+ ${BASH_SOURCE}:${LINENO}: '
    set -x
fi

on_error() {
    local rc=$?
    local line=${BASH_LINENO[0]:-unknown}
    local cmd=${BASH_COMMAND:-unknown}
    echo
    echo "NPU run failed"
    echo "  exit_code: ${rc}"
    echo "  line:      ${line}"
    echo "  command:   ${cmd}"
    echo "  log:       ${RUN_LOG}"
    if [[ -s "${RUN_LOG}" ]]; then
        echo
        echo "Last 160 lines of ${RUN_LOG}:"
        tail -160 "${RUN_LOG}"
    fi
    if [[ -d "${ROOT}/build" ]]; then
        for log in "${ROOT}/build/host_build.log" "${ROOT}/build/kernel_build.log" "${ROOT}/build/runner_build.log"; do
            if [[ -s "${log}" ]]; then
                echo
                echo "Last 80 lines of ${log}:"
                tail -80 "${log}"
            fi
        done
    fi
    exit "${rc}"
}
trap on_error ERR

source "${ROOT}/scripts/env.sh"
cd "${ROOT}"

usage() {
    cat <<'USAGE'
Usage:
  ./run_npu.sh --mode smoke [--workloads FILE] [--output-stem STEM]
  ./run_npu.sh --mode full  [--workloads FILE] [--output-stem STEM]

Modes:
  smoke  NPU-only quick validation. One small fp16 workload, rank 1, few samples.
  full   NPU-only full run. Full workload CSV, Top-K candidates, default samples.

Environment overrides:
  DEVICE_ID, SOC_VERSION, WORKSPACE_MIB
  BEAM_WIDTH, TABU_ITERS, LNS_ROUNDS, TOP_K
  RANK_LIMIT, WARMUP, REPEAT, SAMPLES

This script never falls back to CPU smoke.
USAGE
}

MODE="${MODE:-smoke}"
WORKLOADS_CSV=""
RESULT_STEM=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode)
            MODE="${2:?missing value for --mode}"
            shift 2
            ;;
        --workloads)
            WORKLOADS_CSV="${2:?missing value for --workloads}"
            shift 2
            ;;
        --output-stem)
            RESULT_STEM="${2:?missing value for --output-stem}"
            shift 2
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            usage >&2
            exit 1
            ;;
    esac
done

case "${MODE}" in
    smoke)
        WORKLOADS_CSV="${WORKLOADS_CSV:-${WORKLOADS:-config/workloads_smoke.csv}}"
        RESULT_STEM="${RESULT_STEM:-results/npu_smoke}"
        DEFAULT_BEAM_WIDTH=16
        DEFAULT_TABU_ITERS=8
        DEFAULT_LNS_ROUNDS=2
        DEFAULT_TOP_K=2
        DEFAULT_RANK_LIMIT=1
        DEFAULT_WARMUP=2
        DEFAULT_REPEAT=5
        DEFAULT_SAMPLES=3
        DEFAULT_WORKSPACE_MIB=32
        DEFAULT_SEARCH_SPLIT_K=0
        ;;
    full)
        WORKLOADS_CSV="${WORKLOADS_CSV:-${WORKLOADS:-config/workloads.csv}}"
        RESULT_STEM="${RESULT_STEM:-results/npu_full}"
        DEFAULT_BEAM_WIDTH=64
        DEFAULT_TABU_ITERS=64
        DEFAULT_LNS_ROUNDS=8
        DEFAULT_TOP_K=20
        DEFAULT_RANK_LIMIT=20
        DEFAULT_WARMUP=10
        DEFAULT_REPEAT=50
        DEFAULT_SAMPLES=15
        DEFAULT_WORKSPACE_MIB=64
        DEFAULT_SEARCH_SPLIT_K=1
        ;;
    *)
        echo "Invalid --mode: ${MODE}. Expected smoke or full." >&2
        usage >&2
        exit 1
        ;;
esac

if [[ ! -f "${WORKLOADS_CSV}" ]]; then
    echo "Workload CSV not found: ${WORKLOADS_CSV}" >&2
    exit 1
fi

mkdir -p results

echo "NPU run"
echo "  project:   ${ROOT}"
echo "  CANN_ROOT: ${CANN_ROOT}"
echo "  SOC:       ${SOC_VERSION}"
echo "  mode:      ${MODE}"
echo "  workloads: ${WORKLOADS_CSV}"
echo "  output:    ${RESULT_STEM}_*.csv"
echo "  log:       ${RUN_LOG}"
echo

echo "[0/3] NPU visibility"
if ! command -v npu-smi >/dev/null 2>&1; then
    echo "npu-smi not found. This script is NPU-only and will not fall back to CPU." >&2
    exit 2
fi
npu-smi info

echo "[1/3] Build host, AscendC kernel and NPU runner"
"${ROOT}/scripts/build_all.sh"

echo "[2/3] Search tiling candidates with official CANN tiling API"
BEAM_WIDTH="${BEAM_WIDTH:-${DEFAULT_BEAM_WIDTH}}" \
TABU_ITERS="${TABU_ITERS:-${DEFAULT_TABU_ITERS}}" \
LNS_ROUNDS="${LNS_ROUNDS:-${DEFAULT_LNS_ROUNDS}}" \
TOP_K="${TOP_K:-${DEFAULT_TOP_K}}" \
SEARCH_SPLIT_K="${SEARCH_SPLIT_K:-${DEFAULT_SEARCH_SPLIT_K}}" \
"${ROOT}/scripts/run_search.sh" "${WORKLOADS_CSV}"

if [[ ! -s results/candidates.csv ]]; then
    echo "Search did not produce results/candidates.csv" >&2
    exit 1
fi

echo "[3/3] Run NPU ACL Event profiling"
RANK_LIMIT="${RANK_LIMIT:-${DEFAULT_RANK_LIMIT}}" \
WARMUP="${WARMUP:-${DEFAULT_WARMUP}}" \
REPEAT="${REPEAT:-${DEFAULT_REPEAT}}" \
SAMPLES="${SAMPLES:-${DEFAULT_SAMPLES}}" \
WORKSPACE_MIB="${WORKSPACE_MIB:-${DEFAULT_WORKSPACE_MIB}}" \
DEVICE_ID="${DEVICE_ID:-0}" \
"${ROOT}/scripts/profile_npu.sh" results/candidates.csv "${RESULT_STEM}"

echo
echo "NPU run completed"
echo "  mode:              ${MODE}"
echo "  candidates:        ${ROOT}/results/candidates.csv"
echo "  all evaluations:   ${ROOT}/results/all_evaluated.csv"
echo "  NPU profile:       ${ROOT}/${RESULT_STEM}_profile.csv"
echo "  NPU ranked:        ${ROOT}/${RESULT_STEM}_ranked.csv"
echo "  NPU best:          ${ROOT}/${RESULT_STEM}_best.csv"
echo "  log:               ${RUN_LOG}"

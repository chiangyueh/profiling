#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "${ROOT}/results/logs"
RUN_LOG="${ROOT}/results/logs/run_npu_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "${RUN_LOG}") 2>&1
RUN_VERBOSE="${RUN_VERBOSE:-0}"
LAST_PHASE_LOG=""
ERROR_ALREADY_REPORTED=0
ERROR_PATTERN='\[ERROR\]|RegisterAscendBinary|LaunchAscendKernel ret|fatal:|terminate|throwing|Aborted|(^|[^a-z])error([^a-z]|$)|failed|failure|aclrtBinaryLoadFromFile|rc=[0-9]+|exit_code|symbol lookup error|undefined symbol|not found|missing|No successful|invalid|cannot|Traceback|Exception'

if [[ "${RUN_DEBUG:-0}" == "1" ]]; then
    export PS4='+ ${BASH_SOURCE}:${LINENO}: '
    set -x
fi

print_error_lines() {
    local log_file="$1"
    if [[ ! -s "${log_file}" ]]; then
        echo "  phase_log: ${log_file} (empty or missing)"
        return
    fi
    local matches
    matches="$(grep -Eai "${ERROR_PATTERN}" "${log_file}" | tail -40 || true)"
    if [[ -n "${matches}" ]]; then
        echo "${matches}"
    else
        echo "  no concise error lines found"
    fi
    if grep -Eaiq '(^|[^0-9])507008([^0-9]|$)' "${log_file}"; then
        echo "  hint: 507008 = ACL_ERROR_RT_SOC_VERSION (SoC version error)."
        echo "        Check CANN/runtime path and ASCENDC_SOC_VERSION for this card."
    fi
    echo "  phase_log: ${log_file}"
}

run_quiet_phase() {
    local label="$1"
    local log_file="$2"
    shift 2
    LAST_PHASE_LOG="${log_file}"
    ERROR_ALREADY_REPORTED=0
    echo -n "${label} ... "
    set +e
    if [[ "${RUN_VERBOSE}" == "1" ]]; then
        "$@" 2>&1 | tee "${log_file}"
        local rc=${PIPESTATUS[0]}
    else
        "$@" >"${log_file}" 2>&1
        local rc=$?
    fi
    set -e
    if [[ "${rc}" -eq 0 ]]; then
        echo "ok"
        return 0
    fi
    echo "failed"
    print_error_lines "${log_file}"
    ERROR_ALREADY_REPORTED=1
    return "${rc}"
}

on_error() {
    local rc=$?
    echo
    echo "NPU run failed"
    echo "  exit_code: ${rc}"
    echo "  log:       ${RUN_LOG}"
    if [[ "${ERROR_ALREADY_REPORTED}" != "1" && -n "${LAST_PHASE_LOG}" ]]; then
        print_error_lines "${LAST_PHASE_LOG}"
    fi
    exit "${rc}"
}
trap on_error ERR

source "${ROOT}/scripts/env.sh"
cd "${ROOT}"

usage() {
    cat <<'USAGE'
Usage:
  ./run_npu.sh --mode smoke [--workloads FILE] [--output-stem STEM]
  ./run_npu.sh --mode full  [--workloads FILE] [--output-stem STEM]

Modes:
  smoke  NPU-only quick validation. One small fp16 workload, rank 1, few samples.
  full   NPU-only full run. Full workload CSV, Top-K candidates, default samples.

Environment overrides:
  DEVICE_ID, SOC_VERSION, WORKSPACE_MIB
  BEAM_WIDTH, TABU_ITERS, LNS_ROUNDS, TOP_K
  RANK_LIMIT, WARMUP, REPEAT, SAMPLES
  ASCENDC_SOC_VERSION overrides auto-detection when explicitly set
  ALLOW_NPU_SMI_FAILURE=1 allows ACL fallback when npu-smi has a driver-symbol error
  RUN_VERBOSE=1 prints full build/search/profile output to the terminal

This script never falls back to CPU smoke.
USAGE
}

MODE="${MODE:-smoke}"
WORKLOADS_CSV=""
RESULT_STEM=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --mode)
            MODE="${2:?missing value for --mode}"
            shift 2
            ;;
        --workloads)
            WORKLOADS_CSV="${2:?missing value for --workloads}"
            shift 2
            ;;
        --output-stem)
            RESULT_STEM="${2:?missing value for --output-stem}"
            shift 2
            ;;
        --help|-h)
            usage
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            usage >&2
            exit 1
            ;;
    esac
done

case "${MODE}" in
    smoke)
        WORKLOADS_CSV="${WORKLOADS_CSV:-${WORKLOADS:-config/workloads_smoke.csv}}"
        RESULT_STEM="${RESULT_STEM:-results/npu_smoke}"
        DEFAULT_BEAM_WIDTH=16
        DEFAULT_TABU_ITERS=8
        DEFAULT_LNS_ROUNDS=2
        DEFAULT_TOP_K=2
        DEFAULT_RANK_LIMIT=1
        DEFAULT_WARMUP=2
        DEFAULT_REPEAT=5
        DEFAULT_SAMPLES=3
        DEFAULT_WORKSPACE_MIB=32
        DEFAULT_SEARCH_SPLIT_K=0
        ;;
    full)
        WORKLOADS_CSV="${WORKLOADS_CSV:-${WORKLOADS:-config/workloads.csv}}"
        RESULT_STEM="${RESULT_STEM:-results/npu_full}"
        DEFAULT_BEAM_WIDTH=64
        DEFAULT_TABU_ITERS=64
        DEFAULT_LNS_ROUNDS=8
        DEFAULT_TOP_K=20
        DEFAULT_RANK_LIMIT=20
        DEFAULT_WARMUP=10
        DEFAULT_REPEAT=50
        DEFAULT_SAMPLES=15
        DEFAULT_WORKSPACE_MIB=64
        DEFAULT_SEARCH_SPLIT_K=1
        ;;
    *)
        echo "Invalid --mode: ${MODE}. Expected smoke or full." >&2
        usage >&2
        exit 1
        ;;
esac

if [[ ! -f "${WORKLOADS_CSV}" ]]; then
    echo "Workload CSV not found: ${WORKLOADS_CSV}" >&2
    exit 1
fi

mkdir -p results results/logs

echo "NPU run"
echo "  mode:      ${MODE}"
echo "  workloads: ${WORKLOADS_CSV}"
echo "  output:    ${RESULT_STEM}_*.csv"
echo "  log:       ${RUN_LOG}"
echo

SOC_ENV_FILE="${ROOT}/results/logs/detected_soc_$(date +%Y%m%d_%H%M%S).env"
SOC_DETECT_LOG="${ROOT}/results/logs/detect_soc_$(date +%Y%m%d_%H%M%S).log"
run_quiet_phase "[0/3] Detect NPU SoC" "${SOC_DETECT_LOG}" \
    "${ROOT}/scripts/detect_soc.sh" "${SOC_ENV_FILE}"

# shellcheck disable=SC1090
source "${SOC_ENV_FILE}"
export ASCENDC_SOC_VERSION SOC_VERSION DETECTED_NPU_SOC DETECTED_NPU_SOC_SOURCE DETECTED_NPU_SOC_RAW
echo "  detected_soc: ${DETECTED_NPU_SOC} (${DETECTED_NPU_SOC_SOURCE})"
echo "  ascendc_soc:  ${ASCENDC_SOC_VERSION}"

run_quiet_phase "[1/3] Build host/kernel/runner" "${ROOT}/results/logs/build_$(date +%Y%m%d_%H%M%S).log" \
    "${ROOT}/scripts/build_all.sh"

SEARCH_LOG="${ROOT}/results/logs/search_$(date +%Y%m%d_%H%M%S).log"
run_quiet_phase "[2/3] Search tiling candidates" "${SEARCH_LOG}" \
    env BEAM_WIDTH="${BEAM_WIDTH:-${DEFAULT_BEAM_WIDTH}}" \
        TABU_ITERS="${TABU_ITERS:-${DEFAULT_TABU_ITERS}}" \
        LNS_ROUNDS="${LNS_ROUNDS:-${DEFAULT_LNS_ROUNDS}}" \
        TOP_K="${TOP_K:-${DEFAULT_TOP_K}}" \
        SEARCH_SPLIT_K="${SEARCH_SPLIT_K:-${DEFAULT_SEARCH_SPLIT_K}}" \
        "${ROOT}/scripts/run_search.sh" "${WORKLOADS_CSV}"

if [[ ! -s results/candidates.csv ]]; then
    echo "Search did not produce results/candidates.csv" >&2
    echo "  phase_log: ${SEARCH_LOG}"
    exit 1
fi

echo -n "[3/3] Run NPU ACL Event profiling ... "
PROFILE_CSV="${RESULT_STEM}_profile.csv"
PROFILE_LOG="${ROOT}/results/logs/profile_$(date +%Y%m%d_%H%M%S).log"
LAST_PHASE_LOG="${PROFILE_LOG}"
ERROR_ALREADY_REPORTED=0
profile_cmd=(
    "${ROOT}/scripts/profile_npu.sh"
    results/candidates.csv
    "${RESULT_STEM}"
)
set +e
if [[ "${RUN_VERBOSE}" == "1" ]]; then
    RANK_LIMIT="${RANK_LIMIT:-${DEFAULT_RANK_LIMIT}}" \
    WARMUP="${WARMUP:-${DEFAULT_WARMUP}}" \
    REPEAT="${REPEAT:-${DEFAULT_REPEAT}}" \
    SAMPLES="${SAMPLES:-${DEFAULT_SAMPLES}}" \
    WORKSPACE_MIB="${WORKSPACE_MIB:-${DEFAULT_WORKSPACE_MIB}}" \
    DEVICE_ID="${DEVICE_ID:-0}" \
    PROFILE_VERBOSE=1 \
    "${profile_cmd[@]}" 2>&1 | tee "${PROFILE_LOG}"
    profile_rc=${PIPESTATUS[0]}
else
    RANK_LIMIT="${RANK_LIMIT:-${DEFAULT_RANK_LIMIT}}" \
    WARMUP="${WARMUP:-${DEFAULT_WARMUP}}" \
    REPEAT="${REPEAT:-${DEFAULT_REPEAT}}" \
    SAMPLES="${SAMPLES:-${DEFAULT_SAMPLES}}" \
    WORKSPACE_MIB="${WORKSPACE_MIB:-${DEFAULT_WORKSPACE_MIB}}" \
    DEVICE_ID="${DEVICE_ID:-0}" \
    "${profile_cmd[@]}" >"${PROFILE_LOG}" 2>&1
    profile_rc=$?
fi
set -e
if [[ "${profile_rc}" -ne 0 ]]; then
    echo "failed"
    print_error_lines "${PROFILE_LOG}"
    ERROR_ALREADY_REPORTED=1
    exit "${profile_rc}"
fi
echo "ok"

echo
echo "NPU run completed"
echo "  NPU profile:       ${ROOT}/${PROFILE_CSV}"
echo "  NPU ranked:        ${ROOT}/${RESULT_STEM}_ranked.csv"
echo "  NPU best:          ${ROOT}/${RESULT_STEM}_best.csv"
echo "  log:               ${RUN_LOG}"

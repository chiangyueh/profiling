#include <acl/acl.h>
#include <acl/acl_rt.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#ifndef ACL_RT_BINARY_MAGIC_ELF_CUBE_CORE
#define ACL_RT_BINARY_MAGIC_ELF_CUBE_CORE 0x41494343U
#endif

namespace {

struct Options {
    std::string kernelBinary = "build/matmul_search_kernel.o";
    std::string candidatesCsv = "results/candidates.csv";
    std::string outputCsv = "results/npu_profile.csv";
    std::string samplesCsv = "results/npu_profile_samples.csv";
    int32_t deviceId = 0;
    int32_t warmup = 10;
    int32_t repeat = 50;
    int32_t samples = 15;
    int32_t workloadLimit = -1;
    int32_t rankLimit = -1;
    int32_t onlyRank = -1;
    std::string onlyWorkload;
    int32_t workspaceMiB = 64;
};

struct CandidateRow {
    int32_t rank = 0;
    std::string workloadId;
    int64_t m = 0;
    int64_t n = 0;
    int64_t k = 0;
    std::string dtype;
    bool transA = false;
    bool transB = false;
    int32_t usedCoreNum = 0;
    int32_t hintBaseM = 0;
    int32_t hintBaseN = 0;
    int32_t hintBaseK = 0;
    int32_t officialBaseM = 0;
    int32_t officialBaseN = 0;
    int32_t officialBaseK = 0;
    double proxyTotal = 0.0;
    std::string tilingSignature;
    std::string tilingBin;
};

struct ProfileSummary {
    bool success = false;
    std::string error;
    std::vector<double> valuesMs;
    double minimum = 0.0;
    double mean = 0.0;
    double median = 0.0;
    double standardDeviation = 0.0;
    double p95 = 0.0;
    double maximum = 0.0;
    double tflops = 0.0;
};

struct DeviceBuffer {
    void *ptr = nullptr;
    size_t bytes = 0;

    DeviceBuffer() = default;
    explicit DeviceBuffer(size_t requested) { Allocate(requested); }
    DeviceBuffer(const DeviceBuffer &) = delete;
    DeviceBuffer &operator=(const DeviceBuffer &) = delete;
    DeviceBuffer(DeviceBuffer &&other) noexcept : ptr(other.ptr), bytes(other.bytes)
    {
        other.ptr = nullptr;
        other.bytes = 0;
    }
    DeviceBuffer &operator=(DeviceBuffer &&other) noexcept
    {
        if (this != &other) {
            Release();
            ptr = other.ptr;
            bytes = other.bytes;
            other.ptr = nullptr;
            other.bytes = 0;
        }
        return *this;
    }
    ~DeviceBuffer() { Release(); }

    void Allocate(size_t requested)
    {
        Release();
        bytes = std::max<size_t>(requested, 32);
        const aclError rc = aclrtMalloc(&ptr, bytes, ACL_MEM_MALLOC_HUGE_FIRST);
        if (rc != ACL_SUCCESS) {
            ptr = nullptr;
            throw std::runtime_error("aclrtMalloc failed, bytes=" + std::to_string(bytes) +
                                     ", rc=" + std::to_string(rc));
        }
    }

    void Release()
    {
        if (ptr != nullptr) {
            aclrtFree(ptr);
            ptr = nullptr;
            bytes = 0;
        }
    }
};

struct KernelArguments {
    void *a;
    void *b;
    void *c;
    void *workspace;
    void *tiling;
};

void CheckAcl(aclError rc, const std::string &operation)
{
    if (rc != ACL_SUCCESS) {
        throw std::runtime_error(operation + " failed, rc=" + std::to_string(rc));
    }
}

std::vector<std::string> SplitCsv(const std::string &line)
{
    std::vector<std::string> fields;
    std::string current;
    bool quoted = false;
    for (size_t i = 0; i < line.size(); ++i) {
        const char ch = line[i];
        if (ch == '"') {
            if (quoted && i + 1 < line.size() && line[i + 1] == '"') {
                current.push_back('"');
                ++i;
            } else {
                quoted = !quoted;
            }
        } else if (ch == ',' && !quoted) {
            fields.push_back(current);
            current.clear();
        } else {
            current.push_back(ch);
        }
    }
    fields.push_back(current);
    return fields;
}

std::string EscapeCsv(const std::string &value)
{
    if (value.find_first_of(",\"\n\r") == std::string::npos) {
        return value;
    }
    std::string out = "\"";
    for (char ch : value) {
        out += ch == '"' ? "\"\"" : std::string(1, ch);
    }
    out += '"';
    return out;
}

bool ParseBool(const std::string &value)
{
    return value == "1" || value == "true" || value == "TRUE" || value == "yes";
}

std::string GetField(const std::vector<std::string> &fields,
                     const std::unordered_map<std::string, size_t> &columns,
                     const std::string &name,
                     const std::string &fallback = "")
{
    const auto it = columns.find(name);
    if (it == columns.end() || it->second >= fields.size()) {
        return fallback;
    }
    return fields[it->second];
}

std::vector<CandidateRow> LoadCandidates(const std::string &path, const Options &options)
{
    std::ifstream input(path);
    if (!input) {
        throw std::runtime_error("cannot open candidate CSV: " + path);
    }
    std::string line;
    if (!std::getline(input, line)) {
        throw std::runtime_error("candidate CSV is empty");
    }
    const auto header = SplitCsv(line);
    std::unordered_map<std::string, size_t> columns;
    for (size_t i = 0; i < header.size(); ++i) {
        columns[header[i]] = i;
    }
    for (const char *required : {"rank", "workload_id", "m", "n", "k", "dtype", "trans_a", "trans_b",
                                 "used_core_num", "tiling_bin"}) {
        if (columns.count(required) == 0) {
            throw std::runtime_error(std::string("candidate CSV missing column: ") + required);
        }
    }

    std::map<std::string, int32_t> acceptedPerWorkload;
    std::vector<CandidateRow> rows;
    while (std::getline(input, line)) {
        if (line.empty()) {
            continue;
        }
        const auto fields = SplitCsv(line);
        CandidateRow row;
        row.rank = std::stoi(GetField(fields, columns, "rank"));
        row.workloadId = GetField(fields, columns, "workload_id");
        row.m = std::stoll(GetField(fields, columns, "m"));
        row.n = std::stoll(GetField(fields, columns, "n"));
        row.k = std::stoll(GetField(fields, columns, "k"));
        row.dtype = GetField(fields, columns, "dtype");
        row.transA = ParseBool(GetField(fields, columns, "trans_a"));
        row.transB = ParseBool(GetField(fields, columns, "trans_b"));
        row.usedCoreNum = std::stoi(GetField(fields, columns, "used_core_num"));
        row.hintBaseM = std::stoi(GetField(fields, columns, "candidate_base_m", "-1"));
        row.hintBaseN = std::stoi(GetField(fields, columns, "candidate_base_n", "-1"));
        row.hintBaseK = std::stoi(GetField(fields, columns, "candidate_base_k", "-1"));
        row.officialBaseM = std::stoi(GetField(fields, columns, "base_m", "0"));
        row.officialBaseN = std::stoi(GetField(fields, columns, "base_n", "0"));
        row.officialBaseK = std::stoi(GetField(fields, columns, "base_k", "0"));
        row.proxyTotal = std::stod(GetField(fields, columns, "proxy_total", "0"));
        row.tilingSignature = GetField(fields, columns, "tiling_signature");
        row.tilingBin = GetField(fields, columns, "tiling_bin");

        if (!options.onlyWorkload.empty() && row.workloadId != options.onlyWorkload) {
            continue;
        }
        if (options.onlyRank > 0 && row.rank != options.onlyRank) {
            continue;
        }
        if (options.rankLimit > 0 && row.rank > options.rankLimit) {
            continue;
        }
        if (row.usedCoreNum <= 0 || row.tilingBin.empty()) {
            continue;
        }
        if (options.workloadLimit > 0 && acceptedPerWorkload.count(row.workloadId) == 0 &&
            static_cast<int32_t>(acceptedPerWorkload.size()) >= options.workloadLimit) {
            continue;
        }
        ++acceptedPerWorkload[row.workloadId];
        rows.push_back(std::move(row));
    }
    if (rows.empty()) {
        throw std::runtime_error("no candidates matched the requested filters");
    }
    return rows;
}

std::vector<uint8_t> ReadBinary(const std::string &path)
{
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    if (!input) {
        throw std::runtime_error("cannot open binary: " + path);
    }
    const std::streamsize size = input.tellg();
    if (size <= 0) {
        throw std::runtime_error("binary is empty: " + path);
    }
    input.seekg(0, std::ios::beg);
    std::vector<uint8_t> data(static_cast<size_t>(size));
    if (!input.read(reinterpret_cast<char *>(data.data()), size)) {
        throw std::runtime_error("failed to read binary: " + path);
    }
    return data;
}

size_t CheckedBytes(int64_t x, int64_t y, size_t elementBytes, const char *name)
{
    if (x <= 0 || y <= 0) {
        throw std::runtime_error(std::string(name) + " has non-positive shape");
    }
    const unsigned long long product = static_cast<unsigned long long>(x) * static_cast<unsigned long long>(y);
    if (product > std::numeric_limits<size_t>::max() / elementBytes) {
        throw std::runtime_error(std::string(name) + " byte size overflow");
    }
    return static_cast<size_t>(product) * elementBytes;
}

size_t InputElementBytes(const std::string &dtype)
{
    if (dtype == "fp16" || dtype == "bf16") return 2;
    if (dtype == "fp32") return 4;
    if (dtype == "int8") return 1;
    throw std::runtime_error("unsupported dtype in NPU runner: " + dtype);
}

size_t OutputElementBytes(const std::string &dtype)
{
    return dtype == "int8" ? 4 : InputElementBytes(dtype);
}

std::string KernelName(const CandidateRow &row)
{
    std::string layoutTag;
    if (!row.transA && !row.transB) layoutTag = "nn";
    else if (row.transA && !row.transB) layoutTag = "tn";
    else if (!row.transA && row.transB) layoutTag = "nt";
    else layoutTag = "tt";
    return "matmul_search_" + row.dtype + "_" + layoutTag;
}

void ComputeStats(ProfileSummary &summary, int64_t m, int64_t n, int64_t k)
{
    if (summary.valuesMs.empty()) {
        return;
    }
    std::sort(summary.valuesMs.begin(), summary.valuesMs.end());
    summary.minimum = summary.valuesMs.front();
    summary.maximum = summary.valuesMs.back();
    summary.mean = std::accumulate(summary.valuesMs.begin(), summary.valuesMs.end(), 0.0) /
                   static_cast<double>(summary.valuesMs.size());
    const size_t count = summary.valuesMs.size();
    summary.median = count % 2 == 0
        ? 0.5 * (summary.valuesMs[count / 2 - 1] + summary.valuesMs[count / 2])
        : summary.valuesMs[count / 2];
    double variance = 0.0;
    for (double value : summary.valuesMs) {
        const double delta = value - summary.mean;
        variance += delta * delta;
    }
    summary.standardDeviation = std::sqrt(variance / static_cast<double>(count));
    const size_t p95Index = std::min(count - 1, static_cast<size_t>(std::ceil(0.95 * count) - 1));
    summary.p95 = summary.valuesMs[p95Index];
    const double operations = 2.0 * static_cast<double>(m) * static_cast<double>(n) * static_cast<double>(k);
    summary.tflops = summary.median > 0.0 ? operations / (summary.median * 1.0e9) : 0.0;
    summary.success = true;
}

ProfileSummary ProfileCandidate(const CandidateRow &row,
                                aclrtFuncHandle function,
                                aclrtStream stream,
                                const Options &options,
                                std::ofstream &samplesOutput)
{
    ProfileSummary summary;
    try {
        const size_t inputElementBytes = InputElementBytes(row.dtype);
        const size_t outputElementBytes = OutputElementBytes(row.dtype);
        const size_t aBytes = CheckedBytes(row.m, row.k, inputElementBytes, "A");
        const size_t bBytes = CheckedBytes(row.k, row.n, inputElementBytes, "B");
        const size_t cBytes = CheckedBytes(row.m, row.n, outputElementBytes, "C");
        const size_t workspaceBytes = static_cast<size_t>(std::max(1, options.workspaceMiB)) * 1024 * 1024;
        const auto tilingHost = ReadBinary(row.tilingBin);

        DeviceBuffer a(aBytes);
        DeviceBuffer b(bBytes);
        DeviceBuffer c(cBytes);
        DeviceBuffer workspace(workspaceBytes);
        DeviceBuffer tiling(tilingHost.size());
        CheckAcl(aclrtMemset(a.ptr, a.bytes, 0, a.bytes), "aclrtMemset A");
        CheckAcl(aclrtMemset(b.ptr, b.bytes, 0, b.bytes), "aclrtMemset B");
        CheckAcl(aclrtMemset(c.ptr, c.bytes, 0, c.bytes), "aclrtMemset C");
        CheckAcl(aclrtMemset(workspace.ptr, workspace.bytes, 0, workspace.bytes), "aclrtMemset workspace");
        CheckAcl(aclrtMemcpy(tiling.ptr, tiling.bytes, tilingHost.data(), tilingHost.size(),
                             ACL_MEMCPY_HOST_TO_DEVICE), "aclrtMemcpy tiling");

        KernelArguments args{a.ptr, b.ptr, c.ptr, workspace.ptr, tiling.ptr};
        for (int32_t i = 0; i < options.warmup; ++i) {
            CheckAcl(aclrtLaunchKernel(function, static_cast<uint32_t>(row.usedCoreNum),
                                       &args, sizeof(args), stream), "warmup aclrtLaunchKernel");
        }
        CheckAcl(aclrtSynchronizeStream(stream), "warmup aclrtSynchronizeStream");

        aclrtEvent start = nullptr;
        aclrtEvent end = nullptr;
        CheckAcl(aclrtCreateEvent(&start), "aclrtCreateEvent start");
        try {
            CheckAcl(aclrtCreateEvent(&end), "aclrtCreateEvent end");
            for (int32_t sample = 0; sample < options.samples; ++sample) {
                CheckAcl(aclrtRecordEvent(start, stream), "aclrtRecordEvent start");
                for (int32_t r = 0; r < options.repeat; ++r) {
                    CheckAcl(aclrtLaunchKernel(function, static_cast<uint32_t>(row.usedCoreNum),
                                               &args, sizeof(args), stream), "aclrtLaunchKernel");
                }
                CheckAcl(aclrtRecordEvent(end, stream), "aclrtRecordEvent end");
                CheckAcl(aclrtSynchronizeEvent(end), "aclrtSynchronizeEvent end");
                float batchMs = 0.0F;
                CheckAcl(aclrtEventElapsedTime(&batchMs, start, end), "aclrtEventElapsedTime");
                const double perKernelMs = static_cast<double>(batchMs) / std::max(1, options.repeat);
                summary.valuesMs.push_back(perKernelMs);
                samplesOutput << EscapeCsv(row.workloadId) << ',' << row.rank << ',' << sample << ','
                              << std::setprecision(12) << perKernelMs << '\n';
            }
            aclrtDestroyEvent(end);
            aclrtDestroyEvent(start);
        } catch (...) {
            if (end != nullptr) aclrtDestroyEvent(end);
            if (start != nullptr) aclrtDestroyEvent(start);
            throw;
        }
        ComputeStats(summary, row.m, row.n, row.k);
    } catch (const std::exception &ex) {
        summary.error = ex.what();
    }
    return summary;
}

std::unordered_map<std::string, std::string> ParseArgs(int argc, char **argv)
{
    std::unordered_map<std::string, std::string> args;
    for (int i = 1; i < argc; ++i) {
        const std::string key = argv[i];
        if (key == "--help" || key == "-h") {
            args[key] = "1";
            continue;
        }
        if (key.rfind("--", 0) != 0 || i + 1 >= argc) {
            throw std::runtime_error("invalid argument: " + key);
        }
        args[key] = argv[++i];
    }
    return args;
}

std::string Get(const std::unordered_map<std::string, std::string> &args,
                const std::string &name, const std::string &fallback)
{
    const auto it = args.find(name);
    return it == args.end() ? fallback : it->second;
}

int32_t GetInt(const std::unordered_map<std::string, std::string> &args,
               const std::string &name, int32_t fallback)
{
    const auto it = args.find(name);
    return it == args.end() ? fallback : std::stoi(it->second);
}

void PrintUsage()
{
    std::cout
        << "npu_profile_runner [options]\n"
        << "  --kernel FILE          compiled AscendC cube ELF\n"
        << "  --candidates FILE      candidate CSV generated by host search\n"
        << "  --output FILE          aggregate profiling CSV\n"
        << "  --samples-output FILE  per-sample CSV\n"
        << "  --device N             device ID\n"
        << "  --warmup N             warmup launches per candidate\n"
        << "  --repeat N             launches measured inside each event pair\n"
        << "  --samples N            independent event measurements\n"
        << "  --rank-limit N         profile ranks 1..N per workload\n"
        << "  --only-rank N          profile exactly this rank\n"
        << "  --only-workload ID     profile one workload ID\n"
        << "  --workload-limit N     profile first N workload IDs\n"
        << "  --workspace-mib N      temporary workspace allocation\n";
}

}  // namespace

int main(int argc, char **argv)
{
    try {
        const auto args = ParseArgs(argc, argv);
        if (args.count("--help") || args.count("-h")) {
            PrintUsage();
            return 0;
        }
        Options options;
        options.kernelBinary = Get(args, "--kernel", options.kernelBinary);
        options.candidatesCsv = Get(args, "--candidates", options.candidatesCsv);
        options.outputCsv = Get(args, "--output", options.outputCsv);
        options.samplesCsv = Get(args, "--samples-output", options.samplesCsv);
        options.deviceId = GetInt(args, "--device", options.deviceId);
        options.warmup = GetInt(args, "--warmup", options.warmup);
        options.repeat = GetInt(args, "--repeat", options.repeat);
        options.samples = GetInt(args, "--samples", options.samples);
        options.rankLimit = GetInt(args, "--rank-limit", options.rankLimit);
        options.onlyRank = GetInt(args, "--only-rank", options.onlyRank);
        options.onlyWorkload = Get(args, "--only-workload", options.onlyWorkload);
        options.workloadLimit = GetInt(args, "--workload-limit", options.workloadLimit);
        options.workspaceMiB = GetInt(args, "--workspace-mib", options.workspaceMiB);
        if (options.repeat <= 0 || options.samples <= 0 || options.warmup < 0) {
            throw std::runtime_error("warmup/repeat/samples values are invalid");
        }

        const auto rows = LoadCandidates(options.candidatesCsv, options);
        const auto outputParent = std::filesystem::path(options.outputCsv).parent_path();
        const auto samplesParent = std::filesystem::path(options.samplesCsv).parent_path();
        if (!outputParent.empty()) std::filesystem::create_directories(outputParent);
        if (!samplesParent.empty()) std::filesystem::create_directories(samplesParent);
        std::ofstream output(options.outputCsv);
        std::ofstream samplesOutput(options.samplesCsv);
        if (!output || !samplesOutput) {
            throw std::runtime_error("cannot create profiling CSV output");
        }
        output << "workload_id,rank,m,n,k,dtype,trans_a,trans_b,used_core_num,"
                  "hint_base_m,hint_base_n,hint_base_k,official_base_m,official_base_n,official_base_k,"
                  "proxy_total,success,error,min_ms,mean_ms,median_ms,stddev_ms,p95_ms,max_ms,tflops,"
                  "warmup,repeat,samples,tiling_signature,tiling_bin\n";
        samplesOutput << "workload_id,rank,sample,latency_ms\n";

        bool aclInitialized = false;
        bool deviceSet = false;
        aclrtContext context = nullptr;
        aclrtStream stream = nullptr;
        aclrtBinHandle binary = nullptr;
        try {
            CheckAcl(aclInit(nullptr), "aclInit");
            aclInitialized = true;
            CheckAcl(aclrtSetDevice(options.deviceId), "aclrtSetDevice");
            deviceSet = true;
            CheckAcl(aclrtCreateContext(&context, options.deviceId), "aclrtCreateContext");
            CheckAcl(aclrtCreateStream(&stream), "aclrtCreateStream");

            aclrtBinaryLoadOption loadOption{};
            loadOption.type = ACL_RT_BINARY_LOAD_OPT_LAZY_MAGIC;
            loadOption.value.magic = ACL_RT_BINARY_MAGIC_ELF_CUBE_CORE;
            aclrtBinaryLoadOptions loadOptions{&loadOption, 1};
            CheckAcl(aclrtBinaryLoadFromFile(options.kernelBinary.c_str(), &loadOptions, &binary),
                     "aclrtBinaryLoadFromFile");

            std::unordered_map<std::string, aclrtFuncHandle> functions;
            for (size_t index = 0; index < rows.size(); ++index) {
                const CandidateRow &row = rows[index];
                const std::string kernelName = KernelName(row);
                aclrtFuncHandle function = nullptr;
                const auto found = functions.find(kernelName);
                if (found == functions.end()) {
                    CheckAcl(aclrtBinaryGetFunction(binary, kernelName.c_str(), &function),
                             "aclrtBinaryGetFunction(" + kernelName + ")");
                    functions[kernelName] = function;
                } else {
                    function = found->second;
                }

                std::cout << '[' << (index + 1) << '/' << rows.size() << "] " << row.workloadId
                          << " rank=" << row.rank << " M=" << row.m << " N=" << row.n << " K=" << row.k
                          << " cores=" << row.usedCoreNum << std::endl;
                const ProfileSummary summary = ProfileCandidate(row, function, stream, options, samplesOutput);
                output << EscapeCsv(row.workloadId) << ',' << row.rank << ',' << row.m << ',' << row.n << ',' << row.k
                       << ',' << row.dtype << ',' << row.transA << ',' << row.transB << ',' << row.usedCoreNum << ','
                       << row.hintBaseM << ',' << row.hintBaseN << ',' << row.hintBaseK << ','
                       << row.officialBaseM << ',' << row.officialBaseN << ',' << row.officialBaseK << ','
                       << std::setprecision(12) << row.proxyTotal << ',' << summary.success << ','
                       << EscapeCsv(summary.error) << ',' << summary.minimum << ',' << summary.mean << ','
                       << summary.median << ',' << summary.standardDeviation << ',' << summary.p95 << ','
                       << summary.maximum << ',' << summary.tflops << ',' << options.warmup << ','
                       << options.repeat << ',' << options.samples << ',' << EscapeCsv(row.tilingSignature) << ','
                       << EscapeCsv(row.tilingBin) << '\n';
                output.flush();
                samplesOutput.flush();
            }

            CheckAcl(aclrtSynchronizeStream(stream), "final aclrtSynchronizeStream");
            if (binary != nullptr) {
                aclrtBinaryUnLoad(binary);
                binary = nullptr;
            }
            if (stream != nullptr) {
                aclrtDestroyStream(stream);
                stream = nullptr;
            }
            if (context != nullptr) {
                aclrtDestroyContext(context);
                context = nullptr;
            }
            aclrtResetDevice(options.deviceId);
            deviceSet = false;
            aclFinalize();
            aclInitialized = false;
        } catch (...) {
            if (binary != nullptr) aclrtBinaryUnLoad(binary);
            if (stream != nullptr) aclrtDestroyStream(stream);
            if (context != nullptr) aclrtDestroyContext(context);
            if (deviceSet) aclrtResetDevice(options.deviceId);
            if (aclInitialized) aclFinalize();
            throw;
        }
        std::cout << "aggregate CSV: " << options.outputCsv << '\n'
                  << "sample CSV: " << options.samplesCsv << '\n';
        return 0;
    } catch (const std::exception &ex) {
        std::cerr << "fatal: " << ex.what() << '\n';
        return 1;
    }
}

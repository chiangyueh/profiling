#!/usr/bin/env bash
set -eo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

source "$ROOT/scripts/env.sh"

ARCH="$(uname -m)"
PLATFORM_ROOT="$CANN_ROOT/${ARCH}-linux"
CANN_INCLUDE="$PLATFORM_ROOT/include"
CANN_LIB="$PLATFORM_ROOT/lib64"
HOST_TILING_INCLUDE="$CANN_INCLUDE/ascendc/host_api/tiling"
HOST_HIGHLEVEL_INCLUDE="$CANN_INCLUDE/ascendc/highlevel_api"
ASCENDC_INCLUDE="$PLATFORM_ROOT/ascendc/include"
BISHENG="${BISHENG:-$CANN_ROOT/tools/ccec_compiler/bin/bisheng}"

if [[ ! -x "$BISHENG" ]]; then
    echo "bisheng not found: $BISHENG" >&2
    exit 1
fi

COMMON_HOST=(
    -std=c++17 -O3 -DNDEBUG -Wall -Wextra -Wpedantic
    -I"$ROOT/host/include"
    -I"$ROOT/compat"
    -I"$HOST_TILING_INCLUDE"
    -I"$HOST_HIGHLEVEL_INCLUDE"
    -I"$CANN_INCLUDE"
)

HOST_SOURCES=(
    "$ROOT/host/src/search_types.cpp"
    "$ROOT/host/src/official_tiling.cpp"
    "$ROOT/host/src/proxy_model.cpp"
    "$ROOT/host/src/beam_lns_search.cpp"
    "$ROOT/host/src/csv_io.cpp"
    "$ROOT/host/src/main.cpp"
)

echo "[1/3] Building official-CANN tiling search host"
g++ "${COMMON_HOST[@]}" "${HOST_SOURCES[@]}" \
    -L"$CANN_LIB" -Wl,-rpath,"$CANN_LIB" \
    -ltiling_api -lplatform -lregister -lgraph -lgraph_base \
    -lascendcl -lascendalog -lc_sec -ldl -lpthread \
    -o "$BUILD/matmul_tiling_search" \
    >"$BUILD/host_build.log" 2>&1

echo "[2/3] Building AscendC MatMul kernels for dav-c220-cube"
"$BISHENG" -c -O2 -std=c++17 --cce-aicore-lang --cce-aicore-only --cce-aicore-arch=dav-c220-cube -DASCENDC_CUBE_ONLY \
    -I"$ASCENDC_INCLUDE/basic_api" \
    -I"$ASCENDC_INCLUDE/basic_api/interface" \
    -I"$ASCENDC_INCLUDE/basic_api/impl" \
    -I"$ASCENDC_INCLUDE/highlevel_api" \
    "$ROOT/kernel/matmul_search_kernel.cpp" \
    -o "$BUILD/matmul_search_kernel.o" \
    >"$BUILD/kernel_build.log" 2>&1

echo "[3/3] Building ACL NPU profiling runner"
g++ -std=c++17 -O3 -DNDEBUG -Wall -Wextra -Wpedantic \
    -I"$CANN_INCLUDE" \
    "$ROOT/runner/npu_profile_runner.cpp" \
    -L"$PLATFORM_ROOT/devlib" \
    -lascendcl -ldl -lpthread \
    -o "$BUILD/npu_profile_runner" \
    >"$BUILD/runner_build.log" 2>&1

file "$BUILD/matmul_tiling_search" "$BUILD/matmul_search_kernel.o" "$BUILD/npu_profile_runner"
echo "Build completed: $BUILD"

#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_ENV="${1:-${ROOT}/results/logs/detected_cann.env}"
DEVICE_ID="${DEVICE_ID:-0}"
ARCH="${CANN_ARCH:-$(uname -m)}"
PROBE_DIR="${ROOT}/build/probe"
mkdir -p "$(dirname "$OUT_ENV")" "$PROBE_DIR"

probe_src="${PROBE_DIR}/acl_runtime_probe.cpp"
cat >"$probe_src" <<'CPP'
#include <acl/acl.h>
#include <acl/acl_base.h>
#include <acl/acl_rt.h>
#include <cstdlib>
#include <iostream>

int main() {
    const char *deviceEnv = std::getenv("DEVICE_ID");
    const int deviceId = deviceEnv == nullptr ? 0 : std::atoi(deviceEnv);

    const aclError initRc = aclInit(nullptr);
    if (initRc != ACL_SUCCESS) {
        std::cerr << "aclInit failed, rc=" << initRc << std::endl;
        return 10;
    }

    const aclError setRc = aclrtSetDevice(deviceId);
    if (setRc != ACL_SUCCESS) {
        std::cerr << "aclrtSetDevice failed, rc=" << setRc << std::endl;
        aclFinalize();
        return 11;
    }

    const char *soc = aclrtGetSocName();
    if (soc == nullptr || soc[0] == '\0') {
        std::cerr << "aclrtGetSocName returned empty value" << std::endl;
        aclrtResetDevice(deviceId);
        aclFinalize();
        return 12;
    }

    std::cout << "aclrtGetSocName=" << soc << std::endl;
    aclrtResetDevice(deviceId);
    aclFinalize();
    return 0;
}
CPP

unique_append() {
    local value="$1"
    [[ -z "$value" ]] && return 0
    local existing
    for existing in "${CANDIDATES[@]}"; do
        [[ "$existing" == "$value" ]] && return 0
    done
    CANDIDATES+=("$value")
}

candidate_roots() {
    CANDIDATES=()
    unique_append "${CANN_ROOT:-}"
    unique_append "/usr/local/Ascend/ascend-toolkit/latest"

    local dir
    for dir in /usr/local/Ascend/ascend-toolkit/*; do
        [[ -d "$dir" ]] || continue
        unique_append "$dir"
    done

    for dir in "${CANDIDATES[@]}"; do
        [[ -d "$dir" ]] && echo "$dir"
    done
}

first_existing_dir() {
    local dir
    for dir in "$@"; do
        if [[ -d "$dir" ]]; then
            echo "$dir"
            return 0
        fi
    done
    return 1
}

first_existing_file_dir() {
    local path
    for path in "$@"; do
        if [[ -f "$path" ]]; then
            dirname "$path"
            return 0
        fi
    done
    return 1
}

ld_path_for_root() {
    local root="$1"
    local platform_root="$2"
    local paths=()
    local dir
    for dir in \
        "${platform_root}/lib64" \
        "${platform_root}/devlib" \
        "${root}/lib64" \
        "${root}/runtime/lib64" \
        "${root}/fwkacllib/lib64" \
        "${root}/atc/lib64" \
        "${root}/tools/aml/lib64" \
        "${root}/tools/aml/lib64/plugin" \
        "${root}/opp/built-in/op_impl/ai_core/tbe/op_tiling/lib/linux/${ARCH}" \
        /usr/local/Ascend/driver/lib64 \
        /usr/local/Ascend/driver/lib64/common \
        /usr/local/Ascend/driver/lib64/driver; do
        [[ -d "$dir" ]] && paths+=("$dir")
    done
    if [[ "${#paths[@]}" -gt 0 ]]; then
        (IFS=:; echo "${paths[*]}")
    fi
}

write_env() {
    local root="$1"
    local soc="$2"
    local source="$3"
    {
        echo "export CANN_ROOT='${root}'"
        echo "export CANN_ARCH='${ARCH}'"
        echo "export CANN_PLATFORM_ROOT='${root}/${ARCH}-linux'"
        echo "export DETECTED_CANN_ROOT='${root}'"
        echo "export DETECTED_CANN_ROOT_SOURCE='${source}'"
        echo "export DETECTED_ACL_SOC='${soc}'"
    } >"$OUT_ENV"
}

echo "Detecting working CANN runtime for device ${DEVICE_ID}"
echo "arch=${ARCH}"

last_rc=0
tested=0
for cann_root in $(candidate_roots); do
    platform_root="${cann_root}/${ARCH}-linux"
    include_dir="$(first_existing_dir \
        "${platform_root}/include" \
        "${cann_root}/runtime/include" \
        "${cann_root}/fwkacllib/include" \
        "${cann_root}/atc/include" || true)"
    lib_dir="$(first_existing_file_dir \
        "${platform_root}/lib64/libascendcl.so" \
        "${cann_root}/runtime/lib64/libascendcl.so" \
        "${cann_root}/fwkacllib/lib64/libascendcl.so" \
        "${cann_root}/atc/lib64/libascendcl.so" || true)"

    echo
    echo "candidate=${cann_root}"
    if [[ -z "$include_dir" || -z "$lib_dir" ]]; then
        echo "skip: missing ACL include or libascendcl.so"
        continue
    fi
    if [[ ! -d "$platform_root" ]]; then
        echo "skip: missing platform root ${platform_root}"
        continue
    fi

    tested=$((tested + 1))
    probe_bin="${PROBE_DIR}/acl_runtime_probe_${tested}"
    set +e
    g++ -std=c++17 -O2 "$probe_src" \
        -I"$include_dir" \
        -L"$lib_dir" -Wl,-rpath,"$lib_dir" \
        -lascendcl \
        -o "$probe_bin" 2>&1
    compile_rc=$?
    set -e
    if [[ "$compile_rc" -ne 0 ]]; then
        echo "compile failed"
        last_rc="$compile_rc"
        continue
    fi

    probe_ld="$(ld_path_for_root "$cann_root" "$platform_root")"
    set +e
    output="$(env \
        DEVICE_ID="$DEVICE_ID" \
        ASCEND_TOOLKIT_HOME="$cann_root" \
        ASCEND_HOME_PATH="$cann_root" \
        ASCEND_AICPU_PATH="$cann_root" \
        ASCEND_OPP_PATH="${cann_root}/opp" \
        TOOLCHAIN_HOME="${cann_root}/toolkit" \
        LD_LIBRARY_PATH="${probe_ld}:${LD_LIBRARY_PATH:-}" \
        "$probe_bin" 2>&1)"
    run_rc=$?
    set -e
    echo "$output"
    last_rc="$run_rc"

    if [[ "$run_rc" -eq 0 ]]; then
        soc="$(sed -n 's/^aclrtGetSocName=//p' <<<"$output" | head -1)"
        if [[ -z "$soc" ]]; then
            echo "probe succeeded but did not print aclrtGetSocName"
            last_rc=12
            continue
        fi
        write_env "$cann_root" "$soc" "acl_runtime_probe"
        echo "selected_cann_root=${cann_root}"
        echo "detected_acl_soc=${soc}"
        exit 0
    fi
done

echo
echo "fatal: no installed CANN root passed aclInit + aclrtGetSocName" >&2
echo "  tested=${tested}" >&2
echo "  last_rc=${last_rc}" >&2
echo "  output_env=${OUT_ENV}" >&2
exit 50

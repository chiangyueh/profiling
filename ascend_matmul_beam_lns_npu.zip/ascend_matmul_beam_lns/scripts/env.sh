#!/usr/bin/env bash
# CANN environment for this project.
#
# run_npu.sh auto-detects a working CANN root before sourcing this file. When
# scripts are called directly, this falls back to the standard latest path.

set -euo pipefail

export CANN_ROOT="${CANN_ROOT:-/usr/local/Ascend/ascend-toolkit/latest}"
export SOC_VERSION="${SOC_VERSION:-Ascend910B}"
export CANN_ARCH="${CANN_ARCH:-$(uname -m)}"
export CANN_PLATFORM_ROOT="${CANN_ROOT}/${CANN_ARCH}-linux"

if [[ ! -d "${CANN_ROOT}" ]]; then
    echo "CANN root not found: ${CANN_ROOT}" >&2
    exit 1
fi

if [[ ! -d "${CANN_PLATFORM_ROOT}" ]]; then
    echo "CANN platform directory not found: ${CANN_PLATFORM_ROOT}" >&2
    echo "Detected arch: ${CANN_ARCH}" >&2
    exit 1
fi

export ASCEND_TOOLKIT_HOME="${CANN_ROOT}"
export ASCEND_HOME_PATH="${CANN_ROOT}"
export ASCEND_AICPU_PATH="${CANN_ROOT}"
[[ -d "${CANN_ROOT}/opp" ]] && export ASCEND_OPP_PATH="${CANN_ROOT}/opp"
[[ -d "${CANN_ROOT}/toolkit" ]] && export TOOLCHAIN_HOME="${CANN_ROOT}/toolkit"

_cann_ld_paths=()
[[ -d "${CANN_PLATFORM_ROOT}/lib64" ]] && _cann_ld_paths+=("${CANN_PLATFORM_ROOT}/lib64")
[[ -d "${CANN_PLATFORM_ROOT}/devlib" ]] && _cann_ld_paths+=("${CANN_PLATFORM_ROOT}/devlib")
[[ -d "${CANN_ROOT}/lib64" ]] && _cann_ld_paths+=("${CANN_ROOT}/lib64")
[[ -d "${CANN_ROOT}/runtime/lib64" ]] && _cann_ld_paths+=("${CANN_ROOT}/runtime/lib64")
[[ -d "${CANN_ROOT}/fwkacllib/lib64" ]] && _cann_ld_paths+=("${CANN_ROOT}/fwkacllib/lib64")
[[ -d "${CANN_ROOT}/atc/lib64" ]] && _cann_ld_paths+=("${CANN_ROOT}/atc/lib64")
[[ -d "${CANN_ROOT}/tools/aml/lib64" ]] && _cann_ld_paths+=("${CANN_ROOT}/tools/aml/lib64")
[[ -d "${CANN_ROOT}/tools/aml/lib64/plugin" ]] && _cann_ld_paths+=("${CANN_ROOT}/tools/aml/lib64/plugin")
[[ -d "${CANN_ROOT}/opp/built-in/op_impl/ai_core/tbe/op_tiling/lib/linux/${CANN_ARCH}" ]] && \
    _cann_ld_paths+=("${CANN_ROOT}/opp/built-in/op_impl/ai_core/tbe/op_tiling/lib/linux/${CANN_ARCH}")

if [[ "${#_cann_ld_paths[@]}" -gt 0 ]]; then
    _cann_ld_path="$(IFS=:; echo "${_cann_ld_paths[*]}")"
    export LD_LIBRARY_PATH="${_cann_ld_path}:${LD_LIBRARY_PATH:-}"
    unset _cann_ld_path
fi
unset _cann_ld_paths

_cann_path_entries=()
[[ -d "${CANN_ROOT}/bin" ]] && _cann_path_entries+=("${CANN_ROOT}/bin")
[[ -d "${CANN_ROOT}/compiler/ccec_compiler/bin" ]] && _cann_path_entries+=("${CANN_ROOT}/compiler/ccec_compiler/bin")
[[ -d "${CANN_ROOT}/tools/ccec_compiler/bin" ]] && _cann_path_entries+=("${CANN_ROOT}/tools/ccec_compiler/bin")
[[ -d "${CANN_ROOT}/compiler/bishengir/bin" ]] && _cann_path_entries+=("${CANN_ROOT}/compiler/bishengir/bin")
if [[ "${#_cann_path_entries[@]}" -gt 0 ]]; then
    _cann_path="$(IFS=:; echo "${_cann_path_entries[*]}")"
    export PATH="${_cann_path}:${PATH:-}"
    unset _cann_path
fi
unset _cann_path_entries

_cann_python_paths=()
[[ -d "${CANN_ROOT}/python/site-packages" ]] && _cann_python_paths+=("${CANN_ROOT}/python/site-packages")
[[ -d "${CANN_ROOT}/opp/built-in/op_impl/ai_core/tbe" ]] && _cann_python_paths+=("${CANN_ROOT}/opp/built-in/op_impl/ai_core/tbe")
if [[ "${#_cann_python_paths[@]}" -gt 0 ]]; then
    _cann_python_path="$(IFS=:; echo "${_cann_python_paths[*]}")"
    export PYTHONPATH="${_cann_python_path}:${PYTHONPATH:-}"
    unset _cann_python_path
fi
unset _cann_python_paths

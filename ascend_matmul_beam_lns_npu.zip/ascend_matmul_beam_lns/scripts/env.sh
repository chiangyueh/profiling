#!/usr/bin/env bash
# CANN environment for this project.
#
# This file intentionally does not fall back between /opt and /usr/local.
# If this path is wrong on a target machine, edit CANN_ROOT here once.

set -euo pipefail

export CANN_ROOT="/usr/local/Ascend/ascend-toolkit/latest"
export ASCEND_SET_ENV="/usr/local/Ascend/ascend-toolkit/set_env.sh"
export SOC_VERSION="${SOC_VERSION:-Ascend910B}"
export CANN_ARCH="${CANN_ARCH:-$(uname -m)}"
export CANN_PLATFORM_ROOT="${CANN_ROOT}/${CANN_ARCH}-linux"

if [[ ! -f "${ASCEND_SET_ENV}" ]]; then
    echo "CANN set_env.sh not found: ${ASCEND_SET_ENV}" >&2
    echo "Edit scripts/env.sh and set CANN_ROOT to the installed CANN path." >&2
    exit 1
fi

# shellcheck disable=SC1090
source "${ASCEND_SET_ENV}"

if [[ "${ASCEND_HOME_PATH:-}" != "${CANN_ROOT}" ]]; then
    echo "Unexpected ASCEND_HOME_PATH after sourcing CANN env:" >&2
    echo "  expected: ${CANN_ROOT}" >&2
    echo "  actual:   ${ASCEND_HOME_PATH:-<empty>}" >&2
    exit 1
fi

if [[ ! -d "${CANN_PLATFORM_ROOT}" ]]; then
    echo "CANN platform directory not found: ${CANN_PLATFORM_ROOT}" >&2
    echo "Detected arch: ${CANN_ARCH}" >&2
    exit 1
fi

_cann_ld_paths=()
[[ -d "${CANN_PLATFORM_ROOT}/lib64" ]] && _cann_ld_paths+=("${CANN_PLATFORM_ROOT}/lib64")
[[ -d "${CANN_PLATFORM_ROOT}/devlib" ]] && _cann_ld_paths+=("${CANN_PLATFORM_ROOT}/devlib")
[[ -d "${CANN_ROOT}/lib64" ]] && _cann_ld_paths+=("${CANN_ROOT}/lib64")

if [[ "${#_cann_ld_paths[@]}" -gt 0 ]]; then
    _cann_ld_path="$(IFS=:; echo "${_cann_ld_paths[*]}")"
    export LD_LIBRARY_PATH="${_cann_ld_path}:${LD_LIBRARY_PATH:-}"
    unset _cann_ld_path
fi
unset _cann_ld_paths

#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

CANDIDATES="${1:-results/candidates.csv}"
OUT_STEM="${2:-results/npu}"
PROFILE_CSV="${OUT_STEM}_profile.csv"
SAMPLES_CSV="${OUT_STEM}_samples.csv"
RANKED_CSV="${OUT_STEM}_ranked.csv"
BEST_CSV="${OUT_STEM}_best.csv"
COMPARISON_CSV="${OUT_STEM}_proxy_comparison.csv"

echo "profile_npu"
echo "  candidates: ${CANDIDATES}"
echo "  output:     ${PROFILE_CSV}"
echo "  samples:    ${SAMPLES_CSV}"
echo "  device:     ${DEVICE_ID:-0}"
echo "  rank_limit: ${RANK_LIMIT:-20}"
echo "  warmup:     ${WARMUP:-10}"
echo "  repeat:     ${REPEAT:-50}"
echo "  samples_n:  ${SAMPLES:-15}"
echo "  workspace:  ${WORKSPACE_MIB:-64} MiB"

KERNEL_BIN="${ROOT}/build/matmul_search_kernel.o"
echo
echo "Kernel binary inspection:"
if [[ -s "${KERNEL_BIN}" ]]; then
    file "${KERNEL_BIN}" || true
    if command -v readelf >/dev/null 2>&1; then
        readelf -h "${KERNEL_BIN}" 2>/dev/null | sed -n '1,24p' || true
    fi
else
    echo "  missing or empty: ${KERNEL_BIN}"
fi
echo

runner_cmd=(
./build/npu_profile_runner
    --kernel "${KERNEL_BIN}" \
    --candidates "$CANDIDATES" \
    --output "${PROFILE_CSV}" \
    --samples-output "${SAMPLES_CSV}" \
    --device "${DEVICE_ID:-0}" \
    --warmup "${WARMUP:-10}" \
    --repeat "${REPEAT:-50}" \
    --samples "${SAMPLES:-15}" \
    --rank-limit "${RANK_LIMIT:-20}" \
    --workspace-mib "${WORKSPACE_MIB:-64}"
)

echo "+ ${runner_cmd[*]}"
set +e
"${runner_cmd[@]}"
runner_rc=$?
set -e
echo "npu_profile_runner exit_code=${runner_rc}"

if [[ -s "${PROFILE_CSV}" ]]; then
    echo "Profile CSV preview:"
    sed -n '1,20p' "${PROFILE_CSV}"
    echo "Profile CSV status summary:"
    set +e
    python3 - "$PROFILE_CSV" <<'PY'
import csv
import sys
path = sys.argv[1]
with open(path, newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
print(f"rows={len(rows)}")
success = 0
for row in rows:
    ok = row.get("success") in {"1", "true", "True"}
    success += int(ok)
    if not ok:
        print(
            "failed_row "
            f"workload={row.get('workload_id')} rank={row.get('rank')} "
            f"error={row.get('error')}"
        )
print(f"success_rows={success}")
if rows and success == 0:
    sys.exit(3)
PY
    csv_rc=$?
    set -e
else
    echo "Profile CSV was not created or is empty: ${PROFILE_CSV}"
    csv_rc=4
fi

if [[ "${runner_rc}" -ne 0 ]]; then
    echo "npu_profile_runner failed before post-processing"
    exit "${runner_rc}"
fi
if [[ "${csv_rc}" -ne 0 ]]; then
    echo "No successful NPU profiling rows; stop before ranking"
    exit "${csv_rc}"
fi

echo "+ python3 tools/rank_npu_results.py --input ${PROFILE_CSV} --output ${RANKED_CSV} --summary ${BEST_CSV}"
python3 tools/rank_npu_results.py \
    --input "${PROFILE_CSV}" \
    --output "${RANKED_CSV}" \
    --summary "${BEST_CSV}"

echo "+ python3 tools/compare_proxy_npu.py --candidates ${CANDIDATES} --npu-results ${PROFILE_CSV} --output ${COMPARISON_CSV}"
python3 tools/compare_proxy_npu.py \
    --candidates "$CANDIDATES" \
    --npu-results "${PROFILE_CSV}" \
    --output "${COMPARISON_CSV}"

echo "profile_npu completed"

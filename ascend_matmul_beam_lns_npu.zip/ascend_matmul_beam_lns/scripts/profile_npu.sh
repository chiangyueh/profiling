#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

CANDIDATES="${1:-results/candidates.csv}"
OUT_STEM="${2:-results/npu}"

./build/npu_profile_runner \
    --kernel build/matmul_search_kernel.o \
    --candidates "$CANDIDATES" \
    --output "${OUT_STEM}_profile.csv" \
    --samples-output "${OUT_STEM}_samples.csv" \
    --device "${DEVICE_ID:-0}" \
    --warmup "${WARMUP:-10}" \
    --repeat "${REPEAT:-50}" \
    --samples "${SAMPLES:-15}" \
    --rank-limit "${RANK_LIMIT:-20}" \
    --workspace-mib "${WORKSPACE_MIB:-64}"

python3 tools/rank_npu_results.py \
    --input "${OUT_STEM}_profile.csv" \
    --output "${OUT_STEM}_ranked.csv" \
    --summary "${OUT_STEM}_best.csv"

python3 tools/compare_proxy_npu.py \
    --candidates "$CANDIDATES" \
    --npu-results "${OUT_STEM}_profile.csv" \
    --output "${OUT_STEM}_proxy_comparison.csv"

#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

CANDIDATES="${1:-results/candidates.csv}"
OUT_STEM="${2:-results/npu}"
PROFILE_CSV="${OUT_STEM}_profile.csv"
SAMPLES_CSV="${OUT_STEM}_samples.csv"
RANKED_CSV="${OUT_STEM}_ranked.csv"
BEST_CSV="${OUT_STEM}_best.csv"
COMPARISON_CSV="${OUT_STEM}_proxy_comparison.csv"
PROFILE_VERBOSE="${PROFILE_VERBOSE:-0}"
LOG_DIR="${ROOT}/results/logs"
ERROR_PATTERN='\[ERROR\]|RegisterAscendBinary|LaunchAscendKernel ret|fatal:|terminate|throwing|Aborted|(^|[^a-z])error([^a-z]|$)|failed|failure|aclrtBinaryLoadFromFile|rc=[0-9]+|exit_code|symbol lookup error|undefined symbol|not found|missing|No successful|invalid|cannot|Traceback|Exception'
mkdir -p "${LOG_DIR}"
RUNNER_LOG="${LOG_DIR}/$(basename "${OUT_STEM}")_runner_$(date +%Y%m%d_%H%M%S).log"
CSV_CHECK_LOG="${LOG_DIR}/$(basename "${OUT_STEM}")_csv_check_$(date +%Y%m%d_%H%M%S).log"

print_error_lines() {
    local log_file="$1"
    if [[ ! -s "${log_file}" ]]; then
        echo "  phase_log: ${log_file} (empty or missing)"
        return
    fi
    local matches
    matches="$(grep -Eai "${ERROR_PATTERN}" "${log_file}" | tail -40 || true)"
    if [[ -n "${matches}" ]]; then
        echo "${matches}"
    else
        echo "  no concise error lines found"
    fi
    if grep -Eaiq '(^|[^0-9])507008([^0-9]|$)' "${log_file}"; then
        echo "  hint: 507008 = ACL_ERROR_RT_SOC_VERSION (SoC version error)."
        echo "        Check CANN/runtime path and ASCENDC_SOC_VERSION for this card."
    fi
    echo "  phase_log: ${log_file}"
}

print_diag_summary() {
    local diag_file="$1"
    if [[ ! -s "${diag_file}" ]]; then
        echo "  runtime_diag: ${diag_file} (empty or missing)"
        return
    fi
    echo "  runtime_diag: ${diag_file}"
    grep -Eai '^(CANN_ROOT|CANN_PLATFORM_ROOT|ASCEND_HOME_PATH|ASCEND_TOOLKIT_HOME|ASCEND_OPP_PATH|ASCENDC_SOC_VERSION|DETECTED_|arch=|device_id=|exists:|missing:|npu_profile_runner|.*libascendcl|.*not found|npu-smi_rc=|symbol lookup error|undefined symbol)' "${diag_file}" \
        | head -80 || true
}

run_tool() {
    local label="$1"
    shift
    if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
        echo "+ $*"
        "$@"
    else
        "$@" >>"${RUNNER_LOG}" 2>&1
    fi
}

if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    echo "profile_npu"
    echo "  candidates: ${CANDIDATES}"
    echo "  output:     ${PROFILE_CSV}"
    echo "  samples:    ${SAMPLES_CSV}"
    echo "  device:     ${DEVICE_ID:-0}"
    echo "  rank_limit: ${RANK_LIMIT:-20}"
    echo "  warmup:     ${WARMUP:-10}"
    echo "  repeat:     ${REPEAT:-50}"
    echo "  samples_n:  ${SAMPLES:-15}"
    echo "  workspace:  ${WORKSPACE_MIB:-64} MiB"
fi

runner_cmd=(
./build/npu_profile_runner
    --candidates "$CANDIDATES" \
    --output "${PROFILE_CSV}" \
    --samples-output "${SAMPLES_CSV}" \
    --device "${DEVICE_ID:-0}" \
    --warmup "${WARMUP:-10}" \
    --repeat "${REPEAT:-50}" \
    --samples "${SAMPLES:-15}" \
    --rank-limit "${RANK_LIMIT:-20}" \
    --workspace-mib "${WORKSPACE_MIB:-64}"
)

set +e
if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    echo "+ ${runner_cmd[*]}"
    "${runner_cmd[@]}" 2>&1 | tee "${RUNNER_LOG}"
    runner_rc=${PIPESTATUS[0]}
else
    "${runner_cmd[@]}" >"${RUNNER_LOG}" 2>&1
    runner_rc=$?
fi
set -e

if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    echo "npu_profile_runner exit_code=${runner_rc}"
fi

if [[ "${runner_rc}" -ne 0 ]]; then
    echo "npu_profile_runner failed"
    DIAG_LOG="${LOG_DIR}/$(basename "${OUT_STEM}")_runtime_diag_$(date +%Y%m%d_%H%M%S).log"
    "$ROOT/scripts/diagnose_runtime.sh" >"${DIAG_LOG}" 2>&1 || true
    print_error_lines "${RUNNER_LOG}"
    print_diag_summary "${DIAG_LOG}"
    exit "${runner_rc}"
fi

if grep -Eaiq '\\[ERROR\\]|RegisterAscendBinary|LaunchAscendKernel ret' "${RUNNER_LOG}"; then
    echo "npu_profile_runner reported AscendC launch/register error"
    print_error_lines "${RUNNER_LOG}"
    exit 5
fi

set +e
if [[ -s "${PROFILE_CSV}" ]]; then
    python3 - "$PROFILE_CSV" >"${CSV_CHECK_LOG}" 2>&1 <<'PY'
import csv
import sys
path = sys.argv[1]
with open(path, newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
print(f"rows={len(rows)}")
success = 0
for row in rows:
    ok = row.get("success") in {"1", "true", "True"}
    success += int(ok)
    if not ok:
        print(
            "failed_row "
            f"workload={row.get('workload_id')} rank={row.get('rank')} "
            f"error={row.get('error')}"
        )
print(f"success_rows={success}")
if rows and success == 0:
    sys.exit(3)
PY
    csv_rc=$?
else
    echo "Profile CSV was not created or is empty: ${PROFILE_CSV}" >"${CSV_CHECK_LOG}"
    csv_rc=4
fi
set -e

if [[ "${PROFILE_VERBOSE}" == "1" ]]; then
    cat "${CSV_CHECK_LOG}"
fi

if [[ "${csv_rc}" -ne 0 ]]; then
    echo "No successful NPU profiling rows; stop before ranking"
    print_error_lines "${CSV_CHECK_LOG}"
    exit "${csv_rc}"
fi

run_tool "rank" python3 tools/rank_npu_results.py \
    --input "${PROFILE_CSV}" \
    --output "${RANKED_CSV}" \
    --summary "${BEST_CSV}"

run_tool "compare" python3 tools/compare_proxy_npu.py \
    --candidates "$CANDIDATES" \
    --npu-results "${PROFILE_CSV}" \
    --output "${COMPARISON_CSV}"

echo "profile_npu completed: ${PROFILE_CSV}"

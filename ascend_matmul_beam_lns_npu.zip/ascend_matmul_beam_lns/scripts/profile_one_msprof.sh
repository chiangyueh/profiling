#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

WORKLOAD_ID="${1:?usage: profile_one_msprof.sh WORKLOAD_ID [RANK] [CANDIDATES] [OUTPUT_DIR]}"
RANK="${2:-1}"
CANDIDATES="${3:-results/candidates.csv}"
OUTPUT="${4:-results/msprof_${WORKLOAD_ID}_rank_${RANK}}"
if [[ "$CANDIDATES" = /* ]]; then
    CANDIDATES_ABS="$CANDIDATES"
else
    CANDIDATES_ABS="$ROOT/$CANDIDATES"
fi
APPLICATION="$ROOT/build/npu_profile_runner --kernel $ROOT/build/matmul_search_kernel.o --candidates $CANDIDATES_ABS --output $ROOT/results/msprof_${WORKLOAD_ID}_rank_${RANK}.csv --samples-output $ROOT/results/msprof_${WORKLOAD_ID}_rank_${RANK}_samples.csv --device ${DEVICE_ID:-0} --warmup 5 --repeat 10 --samples 3 --only-workload $WORKLOAD_ID --only-rank $RANK --workspace-mib ${WORKSPACE_MIB:-64}"

msprof \
    --application="$APPLICATION" \
    --output="$OUTPUT" \
    --task-time=on \
    --runtime-api=on \
    --aic-metrics=PipeUtilization

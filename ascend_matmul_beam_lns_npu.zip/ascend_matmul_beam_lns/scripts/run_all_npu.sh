#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARGS=(--mode "${MODE:-full}")
if [[ -n "${WORKLOADS:-}" ]]; then
    ARGS+=(--workloads "${WORKLOADS}")
fi
exec "$ROOT/run_npu.sh" "${ARGS[@]}"

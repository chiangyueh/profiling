#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
source "$ROOT/scripts/env.sh"
cd "$ROOT"

rm -rf results/cpu_smoke_tilings build/cpu_smoke
mkdir -p results/cpu_smoke_tilings build/cpu_smoke
./build/matmul_tiling_search \
    --id cpu_smoke --m 32 --n 32 --k 32 --dtype fp16 --cores 24 \
    --beam-width 8 --tabu-iters 4 --lns-rounds 1 --top-k 1 \
    --max-base-m 64 --max-base-n 64 --max-base-k 64 --search-split-k 0 \
    --output results/cpu_smoke_candidates.csv \
    --all-output results/cpu_smoke_all.csv \
    --tiling-dir results/cpu_smoke_tilings

TILING_BIN="$(python3 - <<'PY'
import csv
with open('results/cpu_smoke_candidates.csv', newline='') as f:
    print(next(csv.DictReader(f))['tiling_bin'])
PY
)"
BLOCK_DIM="$(python3 - <<'PY'
import csv
with open('results/cpu_smoke_candidates.csv', newline='') as f:
    print(next(csv.DictReader(f))['used_core_num'])
PY
)"

cmake -S cpu_smoke -B build/cpu_smoke -DCMAKE_BUILD_TYPE=Release > results/cpu_smoke_cmake.log 2>&1
cmake --build build/cpu_smoke -j"${CPU_SMOKE_JOBS:-1}" > results/cpu_smoke_build.log 2>&1
export LD_LIBRARY_PATH="$ASCEND_HOME_PATH/tools/tikicpulib/lib/Ascend910B1:$ASCEND_HOME_PATH/tools/tikicpulib/lib:$ASCEND_HOME_PATH/x86_64-linux/devlib:${LD_LIBRARY_PATH:-}"
./build/cpu_smoke/matmul_cpu_smoke "$TILING_BIN" "$BLOCK_DIM"

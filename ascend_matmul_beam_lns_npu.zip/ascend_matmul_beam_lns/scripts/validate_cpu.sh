#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if [[ "${SKIP_BUILD:-0}" != "1" ]]; then
    ./scripts/build_all.sh
fi
BEAM_WIDTH=32 TABU_ITERS=24 LNS_ROUNDS=4 TOP_K=8 ./scripts/run_search.sh config/workloads_validation.csv

test -x build/matmul_tiling_search
test -s build/matmul_search_kernel.o
test -x build/npu_profile_runner
test -s results/candidates.csv
test -s results/all_evaluated.csv
head -n 5 results/candidates.csv

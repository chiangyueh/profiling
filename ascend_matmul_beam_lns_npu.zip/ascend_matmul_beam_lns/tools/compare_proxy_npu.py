from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path


def rank(values: list[float]) -> list[float]:
    indexed = sorted(enumerate(values), key=lambda item: item[1])
    result = [0.0] * len(values)
    i = 0
    while i < len(indexed):
        j = i + 1
        while j < len(indexed) and indexed[j][1] == indexed[i][1]:
            j += 1
        average = 0.5 * (i + 1 + j)
        for p in range(i, j):
            result[indexed[p][0]] = average
        i = j
    return result


def correlation(x: list[float], y: list[float]) -> float:
    if len(x) < 2:
        return float("nan")
    mean_x = sum(x) / len(x)
    mean_y = sum(y) / len(y)
    numerator = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
    denominator = math.sqrt(sum((a - mean_x) ** 2 for a in x) * sum((b - mean_y) ** 2 for b in y))
    return numerator / denominator if denominator else float("nan")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", type=Path, default=Path("results/candidates.csv"))
    parser.add_argument("--npu-results", type=Path, default=Path("results/npu_profile.csv"))
    parser.add_argument("--output", type=Path, default=Path("results/proxy_npu_comparison.csv"))
    args = parser.parse_args()

    with args.candidates.open(newline="", encoding="utf-8") as source:
        candidate_rows = list(csv.DictReader(source))
    with args.npu_results.open(newline="", encoding="utf-8") as source:
        profile_rows = list(csv.DictReader(source))

    candidates = {(r["workload_id"], r["rank"]): r for r in candidate_rows}
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for profile in profile_rows:
        if profile.get("success") not in {"1", "true", "True"}:
            continue
        candidate = candidates.get((profile["workload_id"], profile["rank"]))
        if candidate is None:
            continue
        row = dict(candidate)
        row["npu_median_ms"] = profile["median_ms"]
        row["npu_tflops"] = profile["tflops"]
        grouped[profile["workload_id"]].append(row)

    output_rows: list[dict[str, str]] = []
    for workload_id, rows in sorted(grouped.items()):
        proxy = [float(r["proxy_total"]) for r in rows]
        latency = [float(r["npu_median_ms"]) for r in rows]
        spearman = correlation(rank(proxy), rank(latency))
        best_npu = min(latency)
        for row in sorted(rows, key=lambda r: float(r["npu_median_ms"])):
            row["spearman_proxy_npu"] = f"{spearman:.12g}"
            row["npu_slowdown_from_best"] = f"{float(row['npu_median_ms']) / best_npu:.12g}"
            output_rows.append(row)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if output_rows:
        with args.output.open("w", newline="", encoding="utf-8") as destination:
            writer = csv.DictWriter(destination, fieldnames=list(output_rows[0]))
            writer.writeheader()
            writer.writerows(output_rows)
    print(args.output)


if __name__ == "__main__":
    main()

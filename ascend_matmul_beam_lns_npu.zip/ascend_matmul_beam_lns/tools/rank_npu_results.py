from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


def as_float(row: dict[str, str], key: str, fallback: float = float("inf")) -> float:
    try:
        return float(row.get(key, ""))
    except (TypeError, ValueError):
        return fallback


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("results/npu_profile.csv"))
    parser.add_argument("--output", type=Path, default=Path("results/npu_ranked.csv"))
    parser.add_argument("--summary", type=Path, default=Path("results/npu_best_per_workload.csv"))
    args = parser.parse_args()

    if not args.input.exists():
        raise FileNotFoundError(args.input)

    with args.input.open(newline="", encoding="utf-8") as source:
        rows = list(csv.DictReader(source))

    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        if row.get("success") not in {"1", "true", "True"}:
            continue
        grouped[row["workload_id"]].append(row)

    ranked: list[dict[str, str]] = []
    best: list[dict[str, str]] = []
    for workload_id in sorted(grouped):
        items = sorted(grouped[workload_id], key=lambda row: as_float(row, "median_ms"))
        baseline = as_float(items[0], "median_ms") if items else float("inf")
        first_ranked: dict[str, str] | None = None
        for rank_value, row in enumerate(items, 1):
            enriched = dict(row)
            enriched["npu_rank"] = str(rank_value)
            current = as_float(row, "median_ms")
            enriched["relative_to_best"] = f"{current / baseline:.12g}" if baseline > 0 else ""
            ranked.append(enriched)
            if first_ranked is None:
                first_ranked = enriched
        if first_ranked is not None:
            best.append(first_ranked)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    if ranked:
        fieldnames = ["npu_rank", "relative_to_best"] + [
            key for key in ranked[0] if key not in {"npu_rank", "relative_to_best"}
        ]
        with args.output.open("w", newline="", encoding="utf-8") as destination:
            writer = csv.DictWriter(destination, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(ranked)
        with args.summary.open("w", newline="", encoding="utf-8") as destination:
            writer = csv.DictWriter(destination, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(best)

    print(f"ranked={args.output}")
    print(f"best={args.summary}")


if __name__ == "__main__":
    main()
